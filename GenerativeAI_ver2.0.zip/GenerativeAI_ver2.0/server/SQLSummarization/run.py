import time
import os
from Utility.common_utility import utility
from .utility import main

cwdPath = os.path.abspath(os.getcwd())
Assets_rootpath = os.path.join(cwdPath, "Assets")

def run_usecase(usecase_name, job_name, execution_id):
    log_name = usecase_name
    utility.createLOGFile(log_name)
    utility.updatelog(log_name, "***** ***** ***** ***** Started ***** ***** ***** *****", False)
    try:
        in_time = time.time()
        database_path = os.path.join(Assets_rootpath, 'UploadedData', usecase_name, job_name, 'DB')
        db_name = os.listdir(database_path)[0]
        database_uri = f"sqlite:///{os.path.join(database_path, db_name)}"

        main.main(database_uri=database_uri, execution_id=execution_id)
        fin_time = time.time()

        result_summary = {}
        result_summary['job_name'] = job_name
        result_summary['numof_files'] = 1
        result_summary['numof_prompts_executed'] = 1
        result_summary['time_taken'] = fin_time-in_time

        final_response = {}
        final_response["status"] = "success"
        final_response["msg"] = ""
        final_response["result_summary"] = result_summary
        utility.updatelog(log_name, "\nResult Summary Generated Successfully!"+"\n\n***** ***** ***** ***** Completed ***** ***** ***** *****", False)
        return final_response

    except Exception as e:
        utility.updatelog(log_name, str(e), True)
        final_response = {}
        final_response["status"] = "failed"
        final_response["msg"] = str(e)
        final_response["result_summary"] = {}
        final_response["input_file_details"] = []
        final_response["output_file_type"] = ""
        return final_response