from .sql_utils import DatabaseConnection
from .llm_util import LLM
from .agent_utils import  DatabaseAgentExecutor
from SQLSummarization.utility import prompts, profiling
from langchain.callbacks import get_openai_callback
import pandas as pd
from Utility.db_utility import db_utility


available_tools = ['list_tables_sql_db', 'query_sql_db', 'schema_sql_db', 'query_checker_sql_db', 'Python REPL', 'summarizer']
failure_responses = ['Agent stopped due to iteration limit or time limit.']


class Execution():

    def __init__(self, database_uri: str, temperature: float, max_tokens: int, verbose: bool, execution_id: int) -> None:
        self.database_uri = database_uri
        self.db_cls = self._get_db_cls()
        self.llm = self._get_llm(temperature=temperature, max_tokens=max_tokens)
        self.executor = self._get_executor(verbose=verbose)
        self.token_usage = {
            'prompt_tokens': 0,
            'completion_tokens': 0,
            'total_tokens': 0,
            'total_cost': 0,
            'total_requests': 0
        }
        self.execution_id = execution_id


    def _get_db_cls(self):
        return DatabaseConnection(self.database_uri)


    def _get_llm(self, temperature: float, max_tokens: int):
        return LLM(temperature=temperature, max_tokens=max_tokens).azure_openai()


    def _get_executor(self, verbose: bool):
        return DatabaseAgentExecutor(db=self.db_cls.get_langchain_db(), llm=self.llm, verbose=verbose, required_tools=available_tools)


    def _add_token_usage(self, token_usage: dict):
        self.token_usage['prompt_tokens'] = self.token_usage['prompt_tokens'] + token_usage['prompt_tokens']
        self.token_usage['completion_tokens'] = self.token_usage['completion_tokens'] + token_usage['completion_tokens'] 
        self.token_usage['total_tokens'] = self.token_usage['total_tokens'] + token_usage['total_tokens']
        self.token_usage['total_cost'] = self.token_usage['total_cost'] + token_usage['total_cost']
        self.token_usage['total_requests'] = self.token_usage['total_requests'] + token_usage['total_requests']


    def execute_summarization(self):
        temp_ = [{'name': table_name, 'status': False} for table_name in self.db_cls.table_list]
        status_ls = [table_['status'] for table_ in temp_]
        execution_details = []
        execution_details.append({'execution_id': self.execution_id, 'prompt': "", 'title': "Tables Summary", 'result': ""})
        while status_ls.count(False) > 0:
            temp = []
            failed_tables = [table_['name'] for table_ in temp_ if table_['status']==False]
            for table in failed_tables:
                title = "Table Name: " + table
                try:
                    df = self.db_cls.get_pandas_df_from_table(table, 3)
                    template = prompts.summary_template
                    final_query = template.format(table_name=table, row_data=df.to_string())
                    response = self.executor.run(final_query)
                    print('-'*40)
                    print(response['response'])
                    print('-'*40)
                    self._add_token_usage(response['token_usage'])
                    if response['response'] in failure_responses:
                        temp.append({'name': table, 'status': False})
                    else:
                        execution_details.append({'execution_id': self.execution_id, 'prompt': final_query, 'title': title, 'result': response['response']})
                        temp.append({'name': table, 'status': True})
                except:
                    temp.append({'name': table, 'status': False})
            temp_ = temp
            status_ls = [table_['status'] for table_ in temp_]
        self._save_execution_details(self.execution_id, execution_details)


    def execute_summarization_without_retry(self):
        execution_details = []
        execution_details.append({'execution_id': self.execution_id, 'prompt': "", 'title': "Tables Summary", 'result': ""})
        for table in self.db_cls.table_list:
            print(table)
            title = "Table Name: " + table
            try:
                df = self.db_cls.get_pandas_df_from_table(table, 1)
                template = prompts.summary_template
                final_query = template.format(table_name=table, row_data=df.to_string())
                response = self.executor.run(final_query)
                print('-'*40)
                print(response['response'])
                print('-'*40)
                self._add_token_usage(response['token_usage'])
                execution_details.append({'execution_id': self.execution_id, 'prompt': final_query, 'title': title, 'result': response['response']})
            except Exception as e:
                print("Except....", str(e))
                continue
        self._save_execution_details(self.execution_id, execution_details)


    def execute_summarization_using_llm(self):
        execution_details = []
        execution_details.append({'execution_id': self.execution_id, 'prompt': "", 'title': "Tables Summary", 'result': ""})
        for table in self.db_cls.table_list:
            title = "Table Name: " + table
            table_schema = self.db_cls.get_schema_of_table(table)
            df = self.db_cls.get_data_from_table(table_name=table, top_k=3)
            template = prompts.summary_template_using_llm
            final_query = template.format(table_schema=table_schema, row_data=str(df))
            with get_openai_callback() as cb:
                response = self.llm(final_query)
            print('-'*40)
            print(response)
            print('-'*40)
            token_usage = {
                'prompt_tokens': cb.prompt_tokens,
                'completion_tokens': cb.completion_tokens,
                'total_tokens': cb.total_tokens,
                'total_cost': cb.total_cost,
                'total_requests': cb.successful_requests
            }
            self._add_token_usage(token_usage)
            execution_details.append({'execution_id': self.execution_id, 'prompt': final_query, 'title': title, 'result': response})
        self._save_execution_details(self.execution_id, execution_details)


    def execute_profiling_with_data_using_llm(self):
        for table in self.db_cls.table_list:
            print("Table --> ", table)
            df = self.db_cls.get_pandas_df_from_table(table, 10)
            template = prompts.profiling_template_using_llm
            final_query = template.format(table_name=table,  row_data=df.to_string())
            response = self.llm(final_query)
            print('-'*40)
            print(response)
            print('-'*40)


    def execute_profiling_using_tool(self):
        data_ = """{
        'Column': column,
        'Count': count,
        'Count of Null Values': count_null_values,
        'Distinct Values': distinct_values,
        'Minimum Value': minimum_value,
        'Maximum Value': maximum_value,
        'Mean': mean,
        'Median': median,
        'Mode': mode,
        'Variance': variance,
        'Standard Deviation': std_deviation,
        '25th Percentile': q1,
        '50th Percentile': q2,
        '75th Percentile': q3
        }"""
        temp_ = [{'name': table_name, 'status': False} for table_name in self.db_cls.table_list]
        status_ls = [table_['status'] for table_ in temp_]

        while status_ls.count(False) > 0:
            temp = []
            failed_tables = [table_['name'] for table_ in temp_ if table_['status']==False]
            for table in failed_tables:
                print("Table --> ", table)
                try:
                    template = prompts.profiling_template_with_tool
                    final_query = template.format(table_name=table, data_ = data_)
                    response = self.executor.run(final_query)
                    print('-'*40)
                    print(response['response'])
                    print('-'*40)
                    if response['response'] in failure_responses:
                        temp.append({'name': table, 'status': False})
                    else:
                        temp.append({'name': table, 'status': True})
                except:
                    temp.append({'name': table, 'status': False})
            temp_ = temp
            status_ls = [table_['status'] for table_ in temp_]


    def execute_profiling_with_python_code(self):
        execution_details = []
        execution_details.append({'execution_id': self.execution_id, 'prompt': "", 'title': "Profiling Report", 'result': ""})
        for table in self.db_cls.table_list:
            title = "Table Name: " + table
            df = profiling.run_profiler(table, self.database_uri)
            template = prompts.profiling_template_using_python_code
            final_query = template.format(table_name=table, data=df.to_string())
            with get_openai_callback() as cb:
                response = self.llm(final_query)
            print('-'*40)
            print(response)
            print('-'*40)
            token_usage = {
                'prompt_tokens': cb.prompt_tokens,
                'completion_tokens': cb.completion_tokens,
                'total_tokens': cb.total_tokens,
                'total_cost': cb.total_cost,
                'total_requests': cb.successful_requests
            }
            self._add_token_usage(token_usage)
            execution_details.append({'execution_id': self.execution_id, 'prompt': final_query, 'title': title, 'result': response})
        self._save_execution_details(self.execution_id, execution_details)


    def _save_execution_details(self, execution_id: int, execution_data: list):
        df = pd.DataFrame(execution_data)
        db_utility.save_df_to_db(df, 'execution_details')
        print(df)



    def _save_execution_summary(self, execution_id: int):
        keys = {'prompt_tokens': 'Prompt Tokens', 'completion_tokens': 'Completion Tokens', 'total_tokens': 'Total Tokens', 'total_cost': 'Total Cost ($)', 'total_requests': 'Total Requests'}
        summary_data = []
        summary_data.append({'execution_id': execution_id, 'key': 'Tables Count', 'value': str(len(self.db_cls.table_list)), 'remarks': ""})
        for k in keys:
            tmp_ = {}
            tmp_['execution_id'] = execution_id
            tmp_['key'] = keys[k]
            tmp_['value'] = str(self.token_usage[k])
            tmp_['remarks'] = ""
            summary_data.append(tmp_)
        
        df = pd.DataFrame(summary_data)
        db_utility.save_df_to_db(df, 'execution_summary')
        print(df)


    def check_dimension_report(self):
        execution_details = []
        execution_details.append({'execution_id': self.execution_id, 'prompt': "", 'title': "Dimensions Report", 'result': ""})
        status = True
        while status:
            try:
                template = prompts.dimension_wise_result
                final_query = template
                response = self.executor.run(template)
                print('-'*40)
                print(response['response'])
                print('-'*40)
                self._add_token_usage(response['token_usage'])
                if response['response'] in failure_responses:
                    status = True
                else:
                    execution_details.append({'execution_id': self.execution_id, 'prompt': final_query, 'title': "", 'result': response['response']})
                    status = False
            except:
                status = True
        self._save_execution_details(self.execution_id, execution_details)


    def check_critical_data_elements(self):
        execution_details = []
        execution_details.append({'execution_id': self.execution_id, 'prompt': "", 'title': "Critical Data Element (CDEs) Report", 'result': ""})
        status = True
        count = 0
        while status and count < 3:
            try:
                template = prompts.critical_data_elements_prompt
                final_query = template.format(database_uri=self.database_uri)
                response = self.executor.run(template)
                print('-'*40)
                print(response['response'])
                print('-'*40)
                self._add_token_usage(response['token_usage'])
                if response['response'] in failure_responses:
                    count += 1
                    status = True
                else:
                    execution_details.append({'execution_id': self.execution_id, 'prompt': final_query, 'title': '', 'result': response['response']})
                    status = False
            except:
                count += 1
                status = True
        self._save_execution_details(self.execution_id, execution_details)


    def check_critical_rules_elements(self):
        execution_details = []
        execution_details.append({'execution_id': self.execution_id, 'prompt': "", 'title': "Quality Rules Report", 'result': ""})
        status = True
        count = 0
        while status and count < 3:
            try:
                template = prompts.critical_rules_prompt
                final_query = template.format(database_uri=self.database_uri)
                response = self.executor.run(template)
                print('-'*40)
                print(response['response'])
                print('-'*40)
                self._add_token_usage(response['token_usage'])
                if response['response'] in failure_responses:
                    count += 1
                    status = True
                else:
                    execution_details.append({'execution_id': self.execution_id, 'prompt': final_query, 'title': '', 'result': response['response']})
                    status = False
            except:
                count += 1
                status = True
        self._save_execution_details(self.execution_id, execution_details)


    def generate_monthly_report(self):
        execution_details = []
        execution_details.append({'execution_id': self.execution_id, 'prompt': "", 'title': "Monthly Trends Report", 'result': ""})
        status = True
        count = 0
        while status and count < 5:
            try:
                template = prompts.monthly_trend_prompt
                final_query = template.format(database_uri=self.database_uri)
                response = self.executor.run(template)
                print('-'*40)
                print(response['response'])
                print('-'*40)
                self._add_token_usage(response['token_usage'])
                if response['response'] in failure_responses:
                    count += 1
                    status = True
                else:
                    execution_details.append({'execution_id': self.execution_id, 'prompt': final_query, 'title': '', 'result': response['response']})
                    status = False
            except:
                count += 1
                status = True
        self._save_execution_details(self.execution_id, execution_details)


    def generate_sample_rules(self):
        execution_details = []
        execution_details.append({'execution_id': self.execution_id, 'prompt': "", 'title': "Generated Sample Rules", 'result': ""})
        example_rules = '''
        [
        {
        "expectation_type": "expect_column_values_to_be_of_type",
        "kwargs": {
            "alias_name": "Column values should be of given type",
            "column": "Name",
            "cost": "5",
            "dq_dimension": "accuracy",
            "mostly": 0.8,
            "rule_type": "column",
            "type_": "str"
        },
        "meta": {}
        },
        {
        "expectation_type": "expect_column_values_to_be_unique",
        "kwargs": {
            "alias_name": "Column values should be unique",
            "column": "Email Address",
            "cost": "10",
            "dq_dimension": "uniqueness",
            "mostly": 0.8,
            "rule_type": "column"
        },
        "meta": {}
        }
        ]
        '''
        template = prompts.generate_sample_rules
        final_query = template.format(example_rules=example_rules)
        with get_openai_callback() as cb:
            response = self.llm(final_query)
        token_usage = {
            'prompt_tokens': cb.prompt_tokens,
            'completion_tokens': cb.completion_tokens,
            'total_tokens': cb.total_tokens,
            'total_cost': cb.total_cost,
            'total_requests': cb.successful_requests
            }
        self._add_token_usage(token_usage)
        print('-'*40)
        print(response)
        print('-'*40)
        execution_details.append({'execution_id': self.execution_id, 'prompt': final_query, 'title': '', 'result': response})
        self._save_execution_details(self.execution_id, execution_details)


    def generate_code_to_execute(self):
        execution_details = []
        execution_details.append({'execution_id': self.execution_id, 'prompt': "", 'title': "Sample Code for Data Quality Check", 'result': ""})
        template = prompts.generate_code_to_execute_rules_without_data
        final_query = template
        with get_openai_callback() as cb:
            response = self.llm(final_query)
        token_usage = {
            'prompt_tokens': cb.prompt_tokens,
            'completion_tokens': cb.completion_tokens,
            'total_tokens': cb.total_tokens,
            'total_cost': cb.total_cost,
            'total_requests': cb.successful_requests
            }
        self._add_token_usage(token_usage)
        print('-'*40)
        print(response)
        print('-'*40)
        execution_details.append({'execution_id': self.execution_id, 'prompt': final_query, 'title': '', 'result': response})
        self._save_execution_details(self.execution_id, execution_details)


    def generate_possible_joins(self):
        execution_details = []
        execution_details.append({'execution_id': self.execution_id, 'prompt': "", 'title': "Possible JOINs", 'result': ""})
        template = prompts.possible_join_prompt
        db_schema = self.db_cls.get_schema_of_database()
        final_query = template.format(database_schema=db_schema)
        with get_openai_callback() as cb:
            response = self.llm(final_query)
        token_usage = {
            'prompt_tokens': cb.prompt_tokens,
            'completion_tokens': cb.completion_tokens,
            'total_tokens': cb.total_tokens,
            'total_cost': cb.total_cost,
            'total_requests': cb.successful_requests
            }
        self._add_token_usage(token_usage)
        print('-'*40)
        print(response)
        print('-'*40)
        execution_details.append({'execution_id': self.execution_id, 'prompt': final_query, 'title': '', 'result': response})
        self._save_execution_details(self.execution_id, execution_details)


def main(database_uri, execution_id):
    temperature = 0.7
    max_tokens = 1500
    exec_cls = Execution(database_uri=database_uri, temperature=temperature, max_tokens=max_tokens, verbose=False, execution_id=execution_id)
    exec_cls.execute_summarization_using_llm() #llm
    exec_cls.execute_profiling_with_python_code() #llm
    exec_cls.generate_possible_joins() #llm
    if database_uri.endswith("DQCCloud.db"):
        # exec_cls.check_dimension_report() #agent
        exec_cls.check_critical_data_elements() #agent
        exec_cls.check_critical_rules_elements() #agent
        # exec_cls.generate_monthly_report() #agent
        exec_cls.generate_sample_rules() #llm
        exec_cls.generate_code_to_execute() #llm
    exec_cls._save_execution_summary(execution_id)