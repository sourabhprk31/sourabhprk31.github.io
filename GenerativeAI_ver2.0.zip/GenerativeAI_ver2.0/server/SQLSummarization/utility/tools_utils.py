import os
from langchain.agents import Tool
from langchain.tools.python.tool import PythonREPLTool
from langchain.tools.sql_database.tool import InfoSQLDatabaseTool, QuerySQLCheckerTool, QuerySQLDataBaseTool, ListSQLDatabaseTool


def tool_list(db, llm, required_tools):
    python_repl_tool = PythonREPLTool()
    list_sql_tool = ListSQLDatabaseTool(db=db)
    query_sql_tool = QuerySQLDataBaseTool(db=db)
    info_sql_tool = InfoSQLDatabaseTool(db=db)
    query_check_tool = QuerySQLCheckerTool(db=db, llm=llm)
    summarizer = llm

    tools = [
        Tool(
            name="list_tables_sql_db",
            func=list_sql_tool.run,
            description="Input is an empty string, output is a comma separated list of tables in the database.",
        ),
        Tool(
            name="query_sql_db",
            func=query_sql_tool.run,
            description="""
                Input to this tool is a detailed and correct SQL query, output is a result from the database.
                If the query is not correct, an error message will be returned.
                If an error is returned, rewrite the query, check the query, and try again.
                """,
        ),
        Tool(
            name="schema_sql_db",
            func=info_sql_tool.run,
            description="""
                Input to this tool is a comma-separated list of tables, output is the schema and sample rows for those tables.
                Be sure that the tables actually exist by calling list_tables_sql_db first!

                Example Input: "table1, table2, table3"
                """,
        ),
        Tool(
            name="query_checker_sql_db",
            func=query_check_tool.run,
            description="""
                Use this tool to double check if your query is correct before executing it.
                Always use this tool before executing a query with query_sql_db!
                """,
        ),
        Tool(
            name="Python REPL",
            func=python_repl_tool.run,
            description="A Python shell. Use this to execute python commands. Input should be a valid python command. If you want to see the output of a value, you should print it out with `print(...)`.",
        ),
        Tool(
            name="summarizer",
            func=summarizer,
            description="""
                Using LLM, generate a response in the required format of given query.
                """,
        ),
    ]

    selected_tools = select_required_tools(tools, required_tools)
    
    return selected_tools


def select_required_tools(all_tools, required_tools):
    selected_tools = []
    for tool in all_tools:
        if tool.name in required_tools:
            selected_tools.append(tool)
    return selected_tools
