class DBSummarization():

    def __init__(self, tables: list,) -> None:
        self.table_list = tables