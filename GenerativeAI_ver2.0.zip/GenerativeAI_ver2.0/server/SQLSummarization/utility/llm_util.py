import os
import configparser
from langchain.llms import AzureOpenAI


class LLM():

    def __init__(self, temperature: float, max_tokens: int) -> None:
        self.config = self._get_config(temperature, max_tokens)
        for k, v in self.config.items():
            setattr(self, k, v)


    def _get_config(self, temperature: float, max_tokens: int) -> dict:
        cwdPath = os.path.abspath(os.getcwd())
        config_path = os.path.join(cwdPath, "config")
        config_parser = configparser.ConfigParser()
        config_parser.read(os.path.join(config_path, "openai_config.ini"))

        api_type = config_parser.get('dev-openai-usecases', "api_type")
        api_base = config_parser.get('dev-openai-usecases', "api_base")
        api_key = config_parser.get('dev-openai-usecases', "api_key")
        api_version = config_parser.get('dev-openai-usecases', "api_version")
        deployment_name = 'text-model-davinci03'

        model_kwargs = {
            'openai_api_base': api_base,
            'openai_api_key': api_key,
            'openai_api_version': api_version,
            'deployment_name': deployment_name,
            'temperature': temperature,
            'max_tokens': max_tokens
        }
        return model_kwargs


    def azure_openai(self):
        llm = AzureOpenAI(**self.config)
        return llm