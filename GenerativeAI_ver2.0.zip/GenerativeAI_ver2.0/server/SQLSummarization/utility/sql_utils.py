from sqlalchemy import create_engine, MetaData, Table, inspect
from langchain.sql_database import SQLDatabase
import pandas as pd
from pandas import DataFrame


class DatabaseConnection():

    def __init__(self, database_uri: str) -> None:
        try:
            self.database_uri = database_uri
            self.engine = create_engine(database_uri)
            self.metadata = self._set_metadata()
            self.table_list = self._get_table_list()
        except Exception as e:
            print(str(e))


    def _set_metadata(self) -> MetaData:
        metadata = MetaData()
        metadata.reflect(bind=self.engine)
        return metadata


    def _get_table_list(self) -> list:
        # Get a list of table names in the database
        return list(self.metadata.tables.keys())


    def get_data_from_table(self, table_name: str, top_k: int) -> None:
        # Read data from the specified table
        table = Table(table_name, self.metadata, autoload=True)

        with self.engine.connect() as conn:
            result = conn.execute(table.select()).fetchall()

        return list(result[:top_k])


    def get_pandas_df_from_table(self, table_name: str, top_k: int) -> DataFrame:
        table = Table(table_name, self.metadata, autoload=True)

        with self.engine.connect() as conn:
            result = conn.execute(table.select()).fetchall()
        df = pd.DataFrame(result, columns=table.columns.keys())
        return df.head(n=top_k)


    def get_schema_of_table(self, table_name: str):
        inspector = inspect(self.engine)
        columns = inspector.get_columns(table_name)
        schema = f"CREATE TABLE {table_name} (\n"
        for column in columns:
            schema += f"{column['name']} {column['type']} {'' if column['nullable'] else 'NOT NULL'}\n"
        schema += ")"
        return schema


    def get_schema_of_database(self):
        inspector = inspect(self.engine)
        db_schema = ""
        for table_name in self.table_list:
            columns = inspector.get_columns(table_name)
            schema = f"CREATE TABLE {table_name} (\n"
            tmp_ = []
            for column in columns:
                tmp_.append(f"\t{column['name']} {column['type']} {'' if column['nullable'] else 'NOT NULL'}")
            schema += ',\n'.join(tmp_)
            schema += ")\n\n"
            db_schema += schema

        return db_schema


    def print_data(self, data: list) -> None:
        # Display the results
        print("\nData from the database:")
        for row in data:
            print(row)


    def get_langchain_db(self):
        db = SQLDatabase.from_uri(self.database_uri)
        return db







def create_connection():
    # Get user input for the database type
    # db_type = input("Enter the database type (sqlite, mysql, or postgres): ").lower()
    db_type = 'sqlite'

    # Check if the database type is valid
    if db_type not in ['sqlite', 'mysql', 'postgres']:
        print("Unsupported database type.")
        return

    # Get user inputs based on the database type
    if db_type == 'sqlite':
        # database_name = input("Enter the SQLite database file path: ")
        database_name = 'sample.db'
        db_url = f'sqlite:///{database_name}'
    elif db_type == 'mysql':
        username = input("Enter the database username: ")
        password = input("Enter the database password: ")
        host = input("Enter the database host (e.g., localhost): ")
        port = input("Enter the database port: ")
        database_name = input("Enter the database name: ")
        db_url = f'mysql+mysqlconnector://{username}:{password}@{host}:{port}/{database_name}'
    elif db_type == 'postgres':
        username = input("Enter the database username: ")
        password = input("Enter the database password: ")
        host = input("Enter the database host (e.g., localhost): ")
        port = input("Enter the database port: ")
        database_name = input("Enter the database name: ")
        db_url = f'postgresql+psycopg2://{username}:{password}@{host}:{port}/{database_name}'


    connection = DatabaseConnection(db_url)
    table_ls = connection.get_table_list()
    print(table_ls)

    data = connection.get_data_from_table(table_ls[0], 10)
    connection.print_data(data)

