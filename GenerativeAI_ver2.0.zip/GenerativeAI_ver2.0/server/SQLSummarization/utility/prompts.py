main_template = """Answer the following questions as best you can, You have access to the following tools:

{tools}

Use the following format:

Question: the input question you must answer
Thought: you should always think about what to do
Action: the action to take, should be one of [{tool_names}] only.
Action Input: the input to the action (if it is a python code then only put the code)
Observation: the result of the action
... (this Thought/Action/Action Input/Observation can repeat N times)
Thought: I now know the final answer
Final Answer: the final answer to the original input question

Begin!

Note:
- Try not to list the data from table if you are not asked to show.
- Don't do the same mistake repetatively, try to generate different thought or observation if one is failing.
- final answer should be in markdown format only.

Question:

{input}

{agent_scratchpad}"""


summary_template = """Describe the table with name {table_name}.
Write explaination about a the table by looking into its schema and given few rows of the data only.

{row_data}

Include possible usage also by analyzing above data.

Note: 
- Don't see the data from the database, use the above given data only.
- Use only 'schema_sql_db' and 'summarizer' tool.

Final result should follow the given format:
Table Name: name of the table given for summarization/explaination
- Summary: detailed summary or explaination about the table.
- Possible Usage: list all the possible usage of the given table.
"""

summary_template_using_llm = """Write description of the given table.
Here is the schema of the table.

{table_schema}

Given few rows of the data.

{row_data}

By analyzing the above given schema and data, generate possible usage list also

Final result should strictly follow the given markdown format:

**Summary**: detailed summary or description of the table.
**Possible Usage**: 
list possible usage of the given table in bullet points.
"""


profiling_template_with_tool = """Given a table with name {table_name}.

Also given a python code to execute using Python REPL

Python Code :
```
# python code
import pandas as pd
import sqlite3


def data_profiling_rules(df):
    profiling_results = []
    for column in df.columns:
        column_data = df[column]

        count = column_data.count()
        count_null_values = column_data.isnull().sum()
        distinct_values = column_data.nunique()

        if pd.api.types.is_numeric_dtype(column_data):
            minimum_value = column_data.min()
            maximum_value = column_data.max()
            mean = column_data.mean()
            median = column_data.median()
            mode = column_data.mode().iloc[0]
            variance = column_data.var()
            std_deviation = column_data.std()
            quartiles = column_data.quantile([0.25, 0.5, 0.75])
            q1 = quartiles[0.25]
            q2 = quartiles[0.5]
            q3 = quartiles[0.75]
        else:
            minimum_value, maximum_value, mean, median, mode, variance, std_deviation, q1, q2, q3 = None, None, None, None, None, None, None, None, None, None

        profiling_results.append({data_})

    return pd.DataFrame(profiling_results)


def main():
    conn = sqlite3.connect("sample.db")
    df = pd.read_sql_query('SELECT * FROM {table_name}', conn)
    profiling_results = data_profiling_rules(df)
    return profiling_results.to_string()

if __name__ == "__main__":
    print(main())

```

Execute this code using Python REPL tool.

Note:
- Use only 'Python REPL' tool.
- Thought should be 'I need to execute the code and print the result'.
- Action should be Python REPL and the given code should be Action Input.
- print the result after execution.
- if the final answer is not the table then think again.

output is the final answer.

"""


profiling_template_using_llm = """Generate a profiling report for the table with name {table_name} as data is given below.

Data: 

{row_data}

write column wise report with heading as columns name and consider the following statistical data profiling rules for each column.
Data Type - data type of the column
Count - total count of the data
Null - count of the null values
Not Null - count of the not null values (total-null)
Mean - mean value of the column
Median - median value of the column
Mode - mode value of the column
Standard Deviation - standard deviation of the column
Variance - variance of the column
Range - range of the column
Quartile - distribution of data of the column


Final result should follow the given output format.

Overview

Table Name: name of the given table
Columns Count: total number of columns
Rows Count: total number of row available
Null Cells: count of total null cells
Not Null Cells: count of not null cells
Data Type: list of all data types available with count as follows
- Numerical: count of numerical columns
- Categorical: count of categorical columns
- Mention if any other data type is there

Summary 

Column Name: it is column name 1
- Data Type: 
- Count: 
- list all possible values of above rules

Column Name: it is column name 2
- Data Type: 
- Count: 
- List all other possible rules

"""


profiling_template_using_python_code = """Generate a report from given profiling dataframe of table with name {table_name}.

data:

{data}

output should be markdown tablular format of above data with borders .

"""

dimension_wise_result = """Calculate success and failure percentage for expectation rules executed against each data quality dimensions (6 dimensions are avaialable).

Note:
- Use dqc_report table and check its schema. It consist all the executions with status.
- To calculte success percentage, use total number of execution of that particular dimension and count executions with result status 1.
- Use Python REPL to execute the generated SQL query.

Finally list dq_dimension against the success percentage in tabular format.
"""


critical_data_elements_prompt = """Find out the critical data elements (cde) which are very critical based on the success percentage.

Note:
- use given python code.
```
import sqlite3
conn = sqlite3.connect({database_uri})
c = conn.cursor()
c.execute('SELECT cde_name, datasource_name, (CAST(SUM(CASE WHEN result_status = 1 THEN 1 ELSE 0 END) AS FLOAT) / CAST(COUNT(*) AS FLOAT)) * 100.0 AS success_percentage FROM dqc_report GROUP BY cde_name, datasource_name ORDER BY success_percentage ASC LIMIT 20')
data = c.fetchall

```

- Use Python REPL to execute the SQL query and {database_uri} database to connect using sqlite3 and that result should be the final answer.
- percentage decimal value should be upto two places. 

Finally return the output data in tabular format.
"""

critical_rules_prompt = """Find out the execution rules which are very critical based on the success percentage.

Note:
- use given python code.
```
import sqlite3
conn = sqlite3.connect({database_uri})
c = conn.cursor()
c.execute('SELECT alias_name as rule, datasource_name, (CAST(SUM(CASE WHEN result_status = 1 THEN 1 ELSE 0 END) AS FLOAT) / CAST(COUNT(*) AS FLOAT)) * 100.0 AS success_percentage FROM dqc_report GROUP BY alias_name, datasource_name ORDER BY success_percentage ASC LIMIT 20')
data = c.fetchall

```

- Use Python REPL to execute the SQL query and {database_uri} database to connect using sqlite3 and that result should be the final answer.
- percentage decimal value should be upto two places. 

Finally return the output data in tabular format.
"""

monthly_trend_prompt = """
List the average success percentage of the executed rules against each dq dimension with the monthly trend of year '2023'. 
Get the month and year from 'created_at' column by parsing

Note:
- use given python code.
```
import sqlite3
conn = sqlite3.connect({database_uri})
c = conn.cursor()
c.execute('SELECT AVG(result_status) as success_percentage, strftime('%m', created_at) AS month, dq_dimension FROM dqc_report WHERE strftime('%Y', created_at) = '2023' GROUP BY month, dq_dimension')
data = c.fetchall

```
- Use Python REPL to execute the SQL query and {database_uri} database to connect using sqlite3 and that result should be the final answer.
- put the proper month name and January, February and so on.

Ouput format should be as given.
Year, Month, Dimension, Success Percentage

Finally return the required formatted data in tabular format.
"""

generate_sample_rules = """Generate 5 sample rules based on given example rules to execute data quality checks.

Example Rules:

{example_rules}

Note: use python module 'great_expectations' to generate rules in the same format as given examples.

output should strictly follow the markdown format given below with proper numbering.

1. one line about 1st rule

```
1st rule in same format as given example
```

2. one line about 2nd rule

```
2nd rule
```

...and so on

5. one line about 5th rule

```
5th rule
```

"""

generate_code_to_execute_rules = """You are tasked with generating Python code to execute data quality rules using the 'great_expectations' Python module.

follow the given instructions.

Instructions:

- Generate a sample dataset with 5-10 rows to perform data quality checks.
- Refer to the 'great_expectations' Python module for guidance in defining the rules for data quality checks based on the generated data.

Output should be in the given markdown format.

**Sample Data:**
generated sample data presented in a tabular format.

**Code:**
```
generated python code
```
"""


generate_code_to_execute_rules_without_data = """You are tasked with generating Python code to execute data quality rules using the 'great_expectations' Python module.

follow the given instructions.

Instructions:

- Refer to the 'great_expectations' Python module for guidance in defining the rules for data quality checks.
- Add comments where needed.
- Output should be in given format.

Output Format:

```
generated python code with proper comments and should be given markdown format only.
``` 

mention one line explaining the generated code.
"""


possible_join_prompt = """Given the table schemas.

{database_schema}

Analyze the given schema and generate all possible JOINs between tables with their purpose.

Note: Avoid index column if available

Response should strictly be in given markdown format with proper numbering.

1. First JOIN (for eg. LEFT/INNER/RIGHT JOIN between table1 and table2)

- explain the JOIN with table and column names on which this is possible.
- list all the possible usage of this JOIN in bullet points.

2. Second JOIN

- explain the JOIN.
- list all the possible usage.

... and so on

n. nth JOIN
- explain the JOIN.
- list all the possible usage.

"""



summary_temp = """
Guideline for table list with summary and possible usage:
Do not include table fields name in result.
Bring table summary. Possible usage by looking into table schema and some data. Result should be like below format:
Table- table name
Summary- summary
Possible Usage- usage
"""


guidelines = """

Use the following guidelines:

- Using the above table information. Generate correct sql queries according to the input and execute it using Python REPL tool with the help of python module sqlite3 and database at path '/DQCCloud.db'.
- After executing any query, store the result in a variable to proceed further.
- If mentioned to list any data(for e.g. List top 10 records from table abc), then always list it in structured form only.
- While generating python code, generate synatctically correct code and dont repeat the error.

"""