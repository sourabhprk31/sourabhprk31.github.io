from langchain import LLMChain
from langchain.agents import (
    AgentExecutor,
    LLMSingleActionAgent,
)
from langchain.callbacks import get_openai_callback
from .custom_output_parser import output_parser 
from .custom_prompt import return_prompt
from .prompts import main_template
from .tools_utils import tool_list


class DatabaseAgentExecutor():

    def __init__(self, db, llm, verbose: bool, required_tools: list) -> None:
        self.db = db
        self.llm = llm
        self.verbose = verbose
        self.tools = self._get_tools(required_tools)
        self.main_prompt = self._get_main_prompt()
        self.output_parser = self._get_output_parser()
        self.llm_chain = self._get_llm_chain()
        self.agent = self._get_agent()
        self.agent_executor = self._get_executor()


    def _get_tools(self, required_tools):
        return tool_list(self.db, self.llm, required_tools)


    def _get_main_prompt(self):
        prompt_template = main_template
        return return_prompt(prompt_template, self.tools)


    def _get_output_parser(self):
        return output_parser()


    def _get_llm_chain(self):
        return LLMChain(llm=self.llm, prompt=self.main_prompt)


    def _get_agent(self):
        tool_names = [tool.name for tool in self.tools]
        agent = LLMSingleActionAgent(
            llm_chain=self.llm_chain, 
            output_parser=self.output_parser,
            stop=["\nObservation:"], 
            allowed_tools=tool_names
        )
        return agent


    def _get_executor(self):
        return AgentExecutor.from_agent_and_tools(agent=self.agent, tools=self.tools, verbose=self.verbose)


    def run(self, query: str):
        with get_openai_callback() as cb:
            response = self.agent_executor.run(query)
        token_usage = {
            'prompt_tokens': cb.prompt_tokens,
            'completion_tokens': cb.completion_tokens,
            'total_tokens': cb.total_tokens,
            'total_cost': cb.total_cost,
            'total_requests': cb.successful_requests
        }
        return {'response': response, 'token_usage': token_usage}
