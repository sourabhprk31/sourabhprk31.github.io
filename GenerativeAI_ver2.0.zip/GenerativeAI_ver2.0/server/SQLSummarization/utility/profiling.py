import pandas as pd
from sqlalchemy import create_engine


def data_profiling_rules(df):
    # Create a DataFrame to store profiling results
    columns=['Column', 'Count', 'Count of Null Values', 'Distinct Values', 'Minimum Value', 'Maximum Value', 'Mean', 'Median', 'Mode', 'Variance', 'Standard Deviation', '25th Percentile', '50th Percentile', '75th Percentile']
    profiling_results = []
    for column in df.columns:
        column_data = df[column]

        # Calculate profiling rules
        count = column_data.count()
        count_null_values = column_data.isnull().sum()
        distinct_values = column_data.nunique()

        if pd.api.types.is_numeric_dtype(column_data):
            minimum_value = column_data.min()
            maximum_value = column_data.max()
            mean = column_data.mean()
            median = column_data.median()
            mode = column_data.mode().iloc[0]
            variance = column_data.var()
            std_deviation = column_data.std()
            quartiles = column_data.quantile([0.25, 0.5, 0.75])

            q1 = quartiles[0.25]
            q2 = quartiles[0.5]
            q3 = quartiles[0.75]
        else:
            minimum_value, maximum_value, mean, median, mode, variance, std_deviation, q1, q2, q3 = '-', '-', '-', '-', '-', '-', '-', '-', '-', '-'

        # Append results to the profiling DataFrame
        profiling_results.append({
            'Column': column,
            'Count': count,
            'Count of Null Values': count_null_values,
            'Distinct Values': distinct_values,
            'Minimum Value': minimum_value,
            'Maximum Value': maximum_value,
            'Mean': mean,
            'Median': median,
            'Mode': mode,
            'Variance': variance,
            'Standard Deviation': std_deviation,
            '25th Percentile': q1,
            '50th Percentile': q2,
            '75th Percentile': q3
        })

    return pd.DataFrame(profiling_results)


def run_profiler(table_name, database_uri):
    engine = create_engine(database_uri)
    with engine.connect() as conn:
        df = pd.read_sql_query(f'SELECT * FROM {table_name}', conn)
    
    profiling_results = data_profiling_rules(df)
    return profiling_results
