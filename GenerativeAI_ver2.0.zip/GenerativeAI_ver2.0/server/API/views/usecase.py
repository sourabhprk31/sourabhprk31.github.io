"""
=============================================================================
COPYRIGHT NOTICE
=============================================================================
© Copyright HCL Technologies Ltd. 2021, 2022, 2023
Proprietary and confidential. All information contained herein is, and
remains the property of HCL Technologies Limited. Copying or reproducing the
contents of this file, via any medium is strictly prohibited unless prior
written permission is obtained from HCL Technologies Limited.
"""
from django.http import HttpResponse, JsonResponse, HttpResponseNotAllowed
from django.views.decorators.csrf import csrf_exempt
import json

from Utility.usecase_utility import usecase_utility as usecase_utils

@csrf_exempt
def get_menu_names(request):
    response = usecase_utils.get_menu_names(request)
    return HttpResponse(json.dumps(response), content_type="application/json")


@csrf_exempt
def get_ui_controls(request):
    response = usecase_utils.get_ui_controls(request)
    return HttpResponse(json.dumps(response), content_type="application/json")


@csrf_exempt
def run_usecase(request):
    response = usecase_utils.run_usecase(request)
    return HttpResponse(json.dumps(response), content_type="application/json")


def get_execution_preview_data(request):
    response = usecase_utils.get_execution_preview_data(request)
    return HttpResponse(json.dumps(response), content_type="application/json")


def get_execution_info_data(request):
    response = usecase_utils.get_execution_info_data(request)
    return HttpResponse(json.dumps(response), content_type="application/json")


def delete_execution_info(request):
    response = usecase_utils.delete_execution_info(request)
    return HttpResponse(json.dumps(response), content_type = "application/json")
