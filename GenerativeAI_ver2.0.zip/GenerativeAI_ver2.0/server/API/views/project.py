"""
=============================================================================
COPYRIGHT NOTICE
=============================================================================
© Copyright HCL Technologies Ltd. 2021, 2022, 2023
Proprietary and confidential. All information contained herein is, and
remains the property of HCL Technologies Limited. Copying or reproducing the
contents of this file, via any medium is strictly prohibited unless prior
written permission is obtained from HCL Technologies Limited.
"""
from django.http import HttpResponse, JsonResponse, HttpResponseNotAllowed
from django.views.decorators.csrf import csrf_exempt
import json

from Utility import project_utility as project_util

@csrf_exempt
def save_project(request):
    response = project_util.save_project(request)
    return HttpResponse(json.dumps(response), content_type="application/json")

@csrf_exempt
def get_projects(request):
    response = project_util.get_projects(request)
    return HttpResponse(json.dumps(response), content_type="application/json") 


@csrf_exempt
def save_uploadedfiles(request):
    response = project_util.save_uploadedfiles(request)
    return HttpResponse(json.dumps(response), content_type="application/json")

@csrf_exempt
def get_projectsummary(request):
    response = project_util.get_projectsummary(request)
    return HttpResponse(json.dumps(response), content_type="application/json")


@csrf_exempt
def delete_project(request):
    response = project_util.delete_project(request)
    return HttpResponse(json.dumps(response), content_type="application/json")
  

