"""
=============================================================================
COPYRIGHT NOTICE
=============================================================================
© Copyright HCL Technologies Ltd. 2021, 2022, 2023
Proprietary and confidential. All information contained herein is, and
remains the property of HCL Technologies Limited. Copying or reproducing the
contents of this file, via any medium is strictly prohibited unless prior
written permission is obtained from HCL Technologies Limited.
"""
from django.urls import path, re_path
from API.views import usecase as views

urlpatterns = [
    path('get_menu_names', views.get_menu_names, name='get_menu_names'),
    path('get_ui_controls', views.get_ui_controls, name='get_ui_controls'),
    path('run_usecase', views.run_usecase, name='run_usecase'),
    path('get_execution_preview_data', views.get_execution_preview_data, name='get_execution_preview_data'),
    path('get_execution_info_data', views.get_execution_info_data, name='get_execution_info_data'),
    path('delete_execution_info', views.delete_execution_info, name='delete_execution_info'),
]

# localhost:8000/usecase/run_usecase
