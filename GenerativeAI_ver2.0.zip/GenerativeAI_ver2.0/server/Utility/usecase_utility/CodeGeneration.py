from Utility.common_utility import utility
from Utility.usecase_utility.openai import GPTConnector

def generation(usecase_name, form_data, exec_id, job_name):
    log_name = job_name
    utility.createLOGFile(log_name)
    utility.updatelog(log_name, "***** ***** ***** ***** Started ***** ***** ***** *****", False)
     ################## GENERATE PROMPT ####################
    
    SystemRole, GeneratedPrompt = utility.GeneratePromptFromInput(usecase_name, form_data, log_name)
    execution_details = []
    try:
        prompt_tokens, total_tokens, prompt_cost = 0, 0, 0
        
        FinalPrompt = GeneratedPrompt
        
        execution_details.append({'execution_id': exec_id, 'prompt': "", 'title': "Generated Code", 'result': ""})
        ################## CALL OPENAI ####################
        generator = GPTConnector() 
        subscription_name = "dev-openai-usecases"
        deployment_name = "chat-model"
        try:
            response = generator.run(subscription_name, deployment_name, final_prompt= FinalPrompt, role_msg=SystemRole, log_name=log_name) 
            execution_details.append({'execution_id': exec_id, 'prompt': FinalPrompt, 'title': "", 'result': response['response']})
            prompt_tokens = response["cost_token_info"]["prompt_tokens"]
            total_tokens = response["cost_token_info"]["total_tokens"]
            prompt_cost = response["cost_token_info"]["prompt_cost"]
        except Exception as e:
            print("LLM's EXception :>>", str(e))

        result_summary = {}
        result_summary['job_name'] = job_name
        result_summary['numof_prompts_executed'] = 1
        result_summary['prompt_tokens'] = prompt_tokens
        result_summary['total_tokens'] = total_tokens
        result_summary['prompt_cost'] = round(prompt_cost, 4)

        utility.saveExecutionDetails(execution_details)
        utility.saveExecutionSummary(result_summary, exec_id)

        
        final_response = {}
        final_response["status"] = "success"
        final_response["msg"] = ""
        utility.updatelog(log_name, "\nResult Summary Generated Successfully!"+"\n\n***** ***** ***** ***** Completed ***** ***** ***** *****", False)

        return final_response
        
    except Exception as e:
        utility.updatelog(log_name, str(e), True)
        final_response = {}
        final_response["status"] = "failed"
        final_response["msg"] = str(e)
        return final_response

