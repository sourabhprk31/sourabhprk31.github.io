import re
from Utility.common_utility import utility
from Utility.llms.llm_client import chat_completion_client
from Utility.llms.utility import convert_dict_to_message

class GPTConnector:
    def __init__(self) -> None:
        pass

    
    def run(self,
            final_prompt= None,
            role_msg=None, 
            log_name=None):
        
        messages_json = [{"role": "system", "content": role_msg},
                         {"role": "user", "content": final_prompt}]
        
        lc_messsages = map(convert_dict_to_message, messages_json)
        chat = chat_completion_client(max_tokens = 800)

        utility.updatelog(log_name, "LLM Call Started.", True)
        response = chat.generate(messages=[lc_messsages])
        utility.updatelog(log_name, "LLM Call Ended.", True)

        output_str = response.generations[0][0].text
        token_usage = response.llm_output.get("token_usage", {"prompt_tokens": 0, "total_tokens": 0})

        prompt_tokens = token_usage.get("prompt_tokens") #response["cost_token_info"]["prompt_tokens"]
        total_tokens = token_usage.get("total_tokens") #response["cost_token_info"]["total_tokens"]
        prompt_cost = token_usage.get("total_tokens") * (0.002/1000) #response["cost_token_info"]["prompt_cost"]

        response = {
            "response": output_str,
            "cost_token_info": {
                "prompt_tokens": prompt_tokens,
                "total_tokens": total_tokens,
                "prompt_cost": prompt_cost
            },
        }
        return response

def llm_call(final_prompt= None, role_msg=None, log_name=None):
    max_retries = 3
    generator = GPTConnector()
    for i in range(max_retries):
        try:
            # print("tries:", i+1)
            result = generator.run(final_prompt=final_prompt, role_msg=role_msg, log_name=log_name)
            return result
        
        except Exception as e:
            print(f"Failed when inference: {e}")
            print(f"Retry attempt {i+1} of {max_retries}")
    return None


def run_usecase(usecase_name, form_data, uploaded_file_path, exec_id, job_name):
    log_name = job_name
    utility.createLOGFile(log_name)
    utility.createLOGFile(log_name+"_error")
    utility.updatelog(log_name, "***** ***** ***** ***** Started ***** ***** ***** *****", False)
    execution_details = []
    ################## GENERATE PROMPT ####################
    SystemRole, GeneratedPrompt = utility.GeneratePromptFromInput(usecase_name, form_data, log_name)
    if SystemRole == "":
        SystemRole = "You are a senior software developer"
    try:
        file_list = utility.read_inputdirectory(usecase_name, job_name)
        if len(file_list) != 0:
            prompt_tokens, total_tokens, prompt_cost, total_count = 0, 0, 0, 0 
            count_type = "LoC"
            file_count = len(file_list)
            input_file_details = []
            id = 0
            lang_dict = {"java": "JAVA", "py": "PYTHON"}
            execution_details.append({'execution_id': exec_id, 'prompt': "", 'title': "Code Summarization", 'result': ""})
            for idx, file_relpath in  enumerate(file_list):
                input_file = {}
                id = id+1
                file_content, file_size, file_name = utility.read_inputfile(usecase_name, job_name, file_relpath, id, file_count, log_name)
                input_file['id'] = id
                input_file['file_name'] = file_name
                input_file['file_size'] = file_size
                input_file['file_path'] = file_relpath
                input_file_details.append(input_file)
                FinalPrompt = GeneratedPrompt + "\n\n"
                FinalPrompt += "Code: \n"
                FinalPrompt += file_content
                
                print("File No: ", id, "File Name:", file_name)
                ################## CALL OPENAI ####################
                # generator = GPTConnector() 
                
                ext = file_name.split(".")[-1]
                lang = lang_dict.get(ext)

                combine_summary_prompt="""
                    Given the summaries of code chunk of a {} code. Generate the code summary by combaining the chunk summaries and it should be following format.

                    Purpose: Understand the purpose of the code and what it is supposed to accomplish.
                    Functionality: Describe the main functions of the code and how they work.
                    Input and Output: Mention the inputs the code requires and the output it produces.
                    Dependencies: Identify any external libraries or modules that the code depends on.
                    classes and Functions: list the classes and functions used in the code and their purpose
                    Algorithms and Data Structures: Explain the algorithms and data structures used in the code.
                    Exceptions and Error Handling: Mention the exceptions and error handling mechanisms used in the code.
                    Performance: Describe the performance characteristics of the code, including time and space complexity.
                    The output all titles and subtitles should be bold.
                    summaries: {}
                """
                num_tokens = utility.count_tokens(file_content)
                    
                try:
                    if num_tokens <= 3000:
                        final_response = llm_call(final_prompt=FinalPrompt, role_msg=SystemRole, log_name=log_name) 
                    else:
                        chunk_1 = ""
                        chunk_2 = ""
                        code_chunks = utility.code_splitter(file_content, lang) ## --> need to update in UI and get it from user selection
                        for chunk in code_chunks:
                            FinalPrompt = GeneratedPrompt + "\n\ncode: \n" + str(chunk)
                            response = llm_call(final_prompt= FinalPrompt, role_msg=SystemRole, log_name=log_name)
                            chunk_1 += response['response'] + "\n\n"
                            
                        num_tokens = utility.count_tokens(chunk_1)
                        if num_tokens >= 5500:
                            text_doc = utility.text_splitter(chunk_1)
                            for text in text_doc:
                                FinalPrompt = combine_summary_prompt.format(lang, text)
                                response = llm_call(final_prompt=FinalPrompt, role_msg=SystemRole, log_name=log_name)
                                chunk_2 += response['response'] + "\n\n"

                        if chunk_2 != "":
                            FinalPrompt = combine_summary_prompt.format(lang, chunk_2)
                            final_response = llm_call(final_prompt=FinalPrompt, role_msg=SystemRole, log_name=log_name)
                        else:
                            FinalPrompt = combine_summary_prompt.format(lang, chunk_1)
                            final_response = llm_call(final_prompt=FinalPrompt, role_msg=SystemRole, log_name=log_name)
                    
                    react_format = final_response['response']
                    react_format = re.sub("`", "", react_format)
                    react_format = re.sub(r"\(.*?\)", "", react_format)
                    
                    prompt_tokens += final_response["cost_token_info"]["prompt_tokens"]
                    total_tokens += final_response["cost_token_info"]["total_tokens"]
                    prompt_cost += final_response["cost_token_info"]["prompt_cost"]
                    total_count += utility.check_count(usecase_name, job_name, file_relpath, count_type)

                    execution_details.append({'execution_id': exec_id, 'prompt': FinalPrompt, 'title': file_name, 'result': react_format})
                except Exception as e :
                    print(str(e))
                    log_content = file_relpath+"\n\n"
                    log_content += str(e)+"\n"
                    log_content += "-------------------------------------------------------------------------------------------------\n" 
                    utility.updatelog(log_name+"_error", log_content, True)

                # response = generator.run(subscription_name, deployment_name, final_prompt= FinalPrompt, role_msg=SystemRole, log_name=log_name) 
                # execution_details.append({'execution_id': exec_id, 'prompt': FinalPrompt, 'title': file_name, 'result': response['response']})
                # prompt_tokens += response["cost_token_info"]["prompt_tokens"]
                # total_tokens += response["cost_token_info"]["total_tokens"]
                # prompt_cost += response["cost_token_info"]["prompt_cost"]
                # total_count += utility.check_count(usecase_name, job_name, file_relpath, count_type)

            result_summary = {}
            result_summary['job_name'] = job_name
            result_summary['numof_files'] = file_count
            result_summary[count_type] = total_count
            result_summary['numof_prompts_executed'] = file_count
            result_summary['prompt_tokens'] = prompt_tokens
            result_summary['total_tokens'] = total_tokens
            result_summary['prompt_cost'] = round(prompt_cost, 4)

            utility.saveExecutionDetails(execution_details)
            utility.saveExecutionSummary(result_summary, exec_id)

            final_response = {}
            final_response["status"] = "success"
            final_response["msg"] = ""
        
            utility.updatelog(log_name, "\nResult Summary Generated Successfully!"+"\n\n***** ***** ***** ***** Completed ***** ***** ***** *****", False)
            return final_response
        else:
            msg = "Project Not Found / Empty Project"
            utility.updatelog(log_name, msg, True)
            final_response = {}
            final_response["status"] = "failed"
            final_response["msg"] = msg
            final_response["result_summary"] = {}
            final_response["input_file_details"] = []
            final_response["output_file_type"] = ""
            
            return final_response
    except Exception as e:
        utility.updatelog(log_name, str(e), True)
        final_response = {}
        final_response["status"] = "failed"
        final_response["msg"] = str(e)
        final_response["result_summary"] = {}
        final_response["input_file_details"] = []
        final_response["output_file_type"] = ""
        return final_response

