from Utility.common_utility import utility
from Utility.llms.llm_client import chat_completion_client
from Utility.llms.utility import convert_dict_to_message
import re

class GPTConnector:
    def __init__(self) -> None:
        pass

    
    def run(self,
            final_prompt= None,
            role_msg=None, 
            log_name=None):
        
        messages_json = [{"role": "system", "content": role_msg},
                         {"role": "user", "content": final_prompt}]
        
        lc_messsages = map(convert_dict_to_message, messages_json)
        chat = chat_completion_client(max_tokens = 800)

        utility.updatelog(log_name, "LLM Call Started.", True)
        response = chat.generate(messages=[lc_messsages])
        utility.updatelog(log_name, "LLM Call Ended.", True)

        output_str = response.generations[0][0].text
        token_usage = response.llm_output.get("token_usage", {"prompt_tokens": 0, "total_tokens": 0})

        prompt_tokens = token_usage.get("prompt_tokens") #response["cost_token_info"]["prompt_tokens"]
        total_tokens = token_usage.get("total_tokens") #response["cost_token_info"]["total_tokens"]
        prompt_cost = token_usage.get("total_tokens") * (0.002/1000) #response["cost_token_info"]["prompt_cost"]

        response = {
            "response": output_str,
            "cost_token_info": {
                "prompt_tokens": prompt_tokens,
                "total_tokens": total_tokens,
                "prompt_cost": prompt_cost
            },
        }
        return response

def llm_call(final_prompt= None, role_msg=None, log_name=None):
    max_retries = 3
    generator = GPTConnector()
    for i in range(max_retries):
        try:
            result = generator.run(final_prompt=final_prompt, role_msg=role_msg, log_name=log_name)
            return result
        
        except Exception as e:
            print(f"Failed when inference: {e}")
            print(f"Retry attempt {i+1} of {max_retries}")
    return None

def run_usecase(usecase_name, form_data, exec_id, job_name):
    log_name = job_name
    utility.createLOGFile(log_name)
    utility.updatelog(log_name, "***** ***** ***** ***** Started ***** ***** ***** *****", False)
    execution_details = []
    ################## GENERATE PROMPT ####################
    Prompt_Main = """summarize the given {} code.

    output format:
    summary: Summarization the given Code along with the purpose and what it is supposed to accomplish.
    class and function: List the classes and functions defined in the code and their purpose, and the functionality of each function created.
    dependencies uses: List down in detail that various libraries and utilities used.
    Generated output should be in react markdown format, and all titles and subtitles should be bold.
    """

    SystemRole, GeneratedPrompt = utility.GeneratePromptFromInput(usecase_name, form_data, log_name)
    if SystemRole == "":
        SystemRole = "You are a Senior Software Developer with good functional and technical understanding."
    try:
        file_list = utility.read_inputdirectory(usecase_name, job_name)
        if len(file_list) != 0:
            prompt_tokens, total_tokens, prompt_cost, total_count = 0, 0, 0, 0 
            count_type = "LoC"
            file_count = len(file_list)
            input_file_details = []
            id = 0
            lang_dict = {
                "java": "JAVA",
                "py": "PYTHON",
            }
            execution_details.append({'execution_id': exec_id, 'prompt': "", 'title': "Change Impact Analysis", 'result': ""})
            for file_relpath in  file_list:
                input_file = {}
                id = id+1
                file_content, file_size, file_name = utility.read_inputfile(usecase_name, job_name, file_relpath, id, file_count, log_name)
                input_file['id'] = id
                input_file['file_name'] = file_name
                input_file['file_size'] = file_size
                input_file['file_path'] = file_relpath
                input_file_details.append(input_file)
                print("File No: ", id, "File Name:", file_name)
                ext = file_name.split(".")[-1]
                lang = lang_dict.get(ext)
                
                num_tokens = utility.count_tokens(file_content)
                MAX_TOKENS = 3000
                summary_res = f"FileName: {file_name},\nSummary: "

                if num_tokens <= MAX_TOKENS:
                    FinalFirstPrompt = Prompt_Main.format(lang) +"\n\n"
                    FinalFirstPrompt += file_content
                    ################## CALL OPENAI ####################
                    res = llm_call(FinalFirstPrompt, SystemRole, log_name) 
                    summary_res += res['response']
                    prompt_tokens += res["cost_token_info"]["prompt_tokens"]
                    total_tokens += res["cost_token_info"]["total_tokens"]
                    prompt_cost += res["cost_token_info"]["prompt_cost"]
                else:
                    chunk_summary = ""
                    code_chunks = utility.code_splitter(file_content, lang)
                    for chunk in code_chunks:
                        FinalFirstPrompt = Prompt_Main.format(lang) +"\n\n" + str(chunk)
                        res = llm_call(FinalFirstPrompt, SystemRole, log_name)
                        chunk_summary += res['response'] + "\n\n"
                        prompt_tokens += res["cost_token_info"]["prompt_tokens"]
                        total_tokens += res["cost_token_info"]["total_tokens"]
                        prompt_cost += res["cost_token_info"]["prompt_cost"]
                    summary_res += chunk_summary

                FinalPrompt = GeneratedPrompt + "\n\n"
                FinalPrompt += "file summary:"+"\n"
                FinalPrompt +=  summary_res 
                response = llm_call(FinalPrompt, SystemRole, log_name)

                react_format = response['response']
                react_format = re.sub("`", "", react_format)
                react_format = re.sub(r"\(.*?\)", "", react_format)

                execution_details.append({'execution_id': exec_id, 'prompt': FinalPrompt, 'title': file_name, 'result': react_format})
                prompt_tokens += response["cost_token_info"]["prompt_tokens"]
                total_tokens += response["cost_token_info"]["total_tokens"]
                prompt_cost += response["cost_token_info"]["prompt_cost"]
                total_count += utility.check_count(usecase_name, job_name, file_relpath, count_type)

            result_summary = {}
            result_summary['job_name'] = job_name
            result_summary['numof_files'] = file_count
            result_summary[count_type] = total_count
            result_summary['numof_prompts_executed'] = file_count * 2
            result_summary['prompt_tokens'] = prompt_tokens
            result_summary['total_tokens'] = total_tokens
            result_summary['prompt_cost'] = "{:.4f}".format(prompt_cost)

            utility.saveExecutionDetails(execution_details)
            utility.saveExecutionSummary(result_summary, exec_id)
            
            final_response = {}
            final_response["status"] = "success"
            final_response["msg"] = ""
            utility.updatelog(log_name, "\nResult Summary Generated Successfully!"+"\n\n***** ***** ***** ***** Completed ***** ***** ***** *****", False)
            return final_response
        else:
            msg = "Project Not Found / Empty Project"
            utility.updatelog(log_name, msg, True)
            final_response = {}
            final_response["status"] = "failed"
            final_response["msg"] = msg
           
            return final_response
    except Exception as e:
        utility.updatelog(log_name, str(e), True)
        final_response = {}
        final_response["status"] = "failed"
        final_response["msg"] = str(e)
        return final_response
