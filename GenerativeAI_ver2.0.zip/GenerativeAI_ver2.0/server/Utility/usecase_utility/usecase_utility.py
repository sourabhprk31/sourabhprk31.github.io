"""
=============================================================================
COPYRIGHT NOTICE
=============================================================================
© Copyright HCL Technologies Ltd. 2021, 2022, 2023
Proprietary and confidential. All information contained herein is, and
remains the property of HCL Technologies Limited. Copying or reproducing the
contents of this file, via any medium is strictly prohibited unless prior
written permission is obtained from HCL Technologies Limited.
"""

from datetime import datetime
import json
import ast
import os
import zipfile
from django.http import HttpResponse, FileResponse
from django.core.files import File

from Utility.db_utility import postgres_conn
from Utility.usecase_utility.openai import GPTConnector
from Utility.common_utility import utility
from Utility.db_utility import db_utility as db_utils

from Utility.usecase_utility import CodeGeneration, CodeSummarization, SQLGeneration, ChangeImpactAnalysis
from VulnerabilityAssessment import run as vulnerability_assessment_run
from SQLSummarization import run as sql_summarization_run
from Utility.code_clone_detection.main import run_code_clone_detection
from Utility.code_refactoring.main import run_code_refactoring


def get_menu_names(request):
    menu = []
    response = db_utils.get_menu_names()
    for row in response["data"]:
        submenu = {}
        submenu["text"] = row["usecase_name"]
        menu.append(submenu)
    print("Use Case Name List for Sub Menu :>>", menu)
    return menu


def get_ui_controls(request):
    usecase_name = request.GET["usecase_name"]
    response = db_utils.get_ui_controls(usecase_name)

    final_input_details = {}
    input_details_arr = []
    for row in response["data"]:
        final_input_details['id'] = row['id']
        final_input_details['usecase_name'] = row['usecase_name']
        final_input_details['usecase_type'] = row['usecase_type']
        final_input_details['usecase_info'] = row['usecase_info']

        temp_input_control = json.loads(
            row["input_control"].replace('\'', '\"'))
        temp_input_label = json.loads(row["input_label"].replace('\'', '\"'))
        temp_input_data = json.loads(row["input_data"].replace('\'', '\"'))
        temp_visibility = json.loads(
            row["input_visibility"].replace('\'', '\"'))

        temp_defaultvalue = json.loads(
            row["default_value"].replace('\'', '\"'))
        final_input_details['defaultValue'] = temp_defaultvalue
        for (input_id, input_control) in temp_input_control.items():
            input_details = {}
            input_details["input_id"] = input_id
            input_details["input_control"] = input_control
            input_details["input_label"] = temp_input_label[input_id] if input_id in temp_input_label else ""
            input_details["input_data"] = temp_input_data[input_id] if input_id in temp_input_data else ""
            input_details["visibility"] = temp_visibility[input_id] if input_id in temp_visibility else ""
            input_details["default_value"] = temp_defaultvalue[input_id] if input_id in temp_defaultvalue else ""
            input_details_arr.append(input_details)

        final_input_details['input_details'] = input_details_arr
    return final_input_details


def get_userinput_prompt(form_data, usecase_name):
    userinput_prompt = []
    response = db_utils.getinput_visibility_details(usecase_name)
    visibility_details = response["data"][0]
    input_visibility = json.loads(
        visibility_details["input_visibility"].replace('\'', '\"'))
    input_control = json.loads(
        visibility_details["input_control"].replace('\'', '\"'))
    for (input_id, visibility_status) in input_visibility.items():
        if visibility_status == "True":
            input_control_type = input_control[input_id]
            if input_control_type == "text_area":
                userinput_prompt.append(form_data[input_id].replace('\n','<br/>'))
    final_input_prompt = "<br/><br/>".join(userinput_prompt)
    return final_input_prompt


def run_usecase(request):
    uploaded_files = request.FILES.getlist('uploaded_files')
    usecase_name = request.POST["usecase_name"]
    form_data = json.loads(request.POST["form_data"])
    input_files_count = int(request.POST["input_files_count"])
    exec_start_time = datetime.now()

    job_name = utility.generate_jobname(exec_start_time, usecase_name)
    input_prompt = get_userinput_prompt(form_data, usecase_name)

    # Inserting the execution info
    data_obj = (usecase_name, job_name, input_prompt,
                input_files_count, exec_start_time)
    insert_response = db_utils.insert_execution_info(data_obj)
    exec_id = insert_response['exec_id']

    # Saving the uploaded folder in locally
    if insert_response['status'] == "Success" and input_files_count > 0:
        uploaded_file_path = utility.handleUploadDirectory(
            uploaded_files, usecase_name, job_name, request)

    # Call the relevant usecase code
    if usecase_name == "Code Generation":
        response = CodeGeneration.generation(
            usecase_name, form_data, exec_id, job_name)
    if usecase_name == "Vulnerability Assessment":
        vulnerability_assessment_run.delete_files()
        response = vulnerability_assessment_run.run_usecase(
            usecase_name, job_name, exec_id, uploaded_file_path)
    if usecase_name == "Code Summarization":
        response = CodeSummarization.run_usecase(
            usecase_name, form_data, uploaded_file_path, exec_id, job_name)
    if usecase_name == "Code Clone Detection":
        response = run_code_clone_detection(
            usecase_name, job_name, exec_id, uploaded_file_path)
    if usecase_name == "Code Refactoring":
        response = run_code_refactoring(
            usecase_name, job_name, exec_id, uploaded_file_path)
    if usecase_name == "SQL Generation":
        response = SQLGeneration.generation(
            usecase_name, form_data, exec_id, job_name)
    if usecase_name == "SQL Summarization":
        response = sql_summarization_run.run_usecase(
            usecase_name, job_name, exec_id)
    if usecase_name == "Change Impact Analysis":
        response = ChangeImpactAnalysis.run_usecase(usecase_name, form_data, exec_id, job_name)

    # Updating the execution info
    exec_end_time = datetime.now()

    time_between = datetime.strptime(str(exec_end_time-exec_start_time), "%H:%M:%S.%f")  
    time_taken = time_between.strftime("%H:%M:%S")  
    print(time_taken)
    utility.saveExecutionSummary({"time_taken":time_taken}, exec_id)
    status = True if response["status"] == "success" else False
    error_msg = response["msg"]
    db_utils.update_execution_info(job_name, exec_end_time, status, error_msg)
    return {"job_name": job_name, "status": status, "error_msg": error_msg, 'execution_id': exec_id}


def get_execution_preview_data(request):
    execution_id = request.GET["execution_id"]
    result = db_utils.get_execution_preview_data(execution_id)
    return result


def get_execution_info_data(request):
    usecase_name = request.GET["usecase_name"]
    result = db_utils.get_execution_info_data(usecase_name)
    return result


def delete_execution_info(request):
    req_body = request.body.decode('utf-8')
    json_req = json.loads(req_body)['params']
    execution_id = json_req['execution_id']
    result = db_utils.delete_execution_info(execution_id)
    return result
