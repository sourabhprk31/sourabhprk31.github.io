CODE_CLONE_TYPES = ("Exact clone", "Parameterized clone",
                    "Near-miss clone", "Semantic clone", "None")


SYSTEM_PROMPT = "You are a Senior Code Reviewer, good in code clone checking."


PROMPT_TEMPLATE = """Given two code snippets, check if the first code snippet is clone of second with suitable explanation.

Four types of clone:

1. Exact clone: Two code fragments similar to each other with little transformation in comments, layout, or whitespaces.
2. Parameterized clone: Changes made in names of variables, keywords, identifiers, or bypassing parameter during function call in code fragments, result in this clone.
3. Near-miss clone: Near-miss clone occurs by adding, deleting statements in code fragments of type 2 clones.
4. Semantic clone: The code snippets have different syntax but with alike functionality results in this clone.


Code Snippet 1:
```python
{code1}
```

Code Snippet 2:
```python
{code2}
```

Analyze the code snippets based on given clone types and list down your observations.
Finally decide clone type and return the answer in following format:

Observations: List of your observations.
Clone Type: (Exact clone, Parameterized clone, Near-miss clone, Semantic clone) Choose most appropriate clone type or "None".

"""


MERGE_CLONE_CODES_PROMPT = """Merge duplicate code 1 and code 2 and provide an optimised single function. 
Return merged code only, Do not add code explanation.

Code 1:
```{language}
{code1}
```

Code 2:
```{language}
{code2}
```

"""
