import concurrent.futures

from tqdm import tqdm


def thread_pool_executer(target_function, param_list: list, multi_thread = True):
    task_list = [{"task_id": i, "param": param, "result": None}
                 for i, param in enumerate(param_list)]
    
    if not multi_thread:
        result = []
        with tqdm(total=len(task_list)) as progress:
            for task in task_list:
                try:
                    result.append(target_function(task["param"]))
                except:
                    result.append(None)
                progress.update()
        return result


    with concurrent.futures.ThreadPoolExecutor() as executor:
        future_tasks = {executor.submit(
            target_function, task["param"]): task["task_id"] for task in task_list}

        with tqdm(total=len(future_tasks)) as progress:
            for future in concurrent.futures.as_completed(future_tasks):
                task_id = future_tasks[future]
                try:
                    data = future.result()
                    task_list[task_id]["result"] = data
                except Exception as exc:
                    task_list[task_id]["exception"] = str(exc)
                    print('%r generated an exception: %s' % (task_id, exc))

                progress.update()

    return [t["result"] for t in task_list]