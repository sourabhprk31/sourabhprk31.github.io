import re

import numpy as np
import pandas as pd
import tiktoken
from langchain.schema import HumanMessage, SystemMessage
from sklearn.cluster import DBSCAN
from tenacity import retry, stop_after_attempt, wait_random_exponential

from Utility.code_clone_detection.code_parser import CodeFileParser
from Utility.code_clone_detection.prompts import (CODE_CLONE_TYPES,
                                                  MERGE_CLONE_CODES_PROMPT,
                                                  PROMPT_TEMPLATE,
                                                  SYSTEM_PROMPT)
from Utility.code_clone_detection.utilts import thread_pool_executer
from Utility.llms import llm_client
from Utility.llms.llm_client import chat_completion_client

OPENAI_EMBEDDING_MODEL = "embedding"
OPENAI_CHAT_MODEL = "chat-model"
EMBEDDING_PRICING = 0.0004/1000
CHATMODEL_PRICING = 0.002/1000


def _create_prompt_messages(code1, code2):
    system_prompt = SYSTEM_PROMPT
    user_prompt = PROMPT_TEMPLATE.format(code1=code1, code2=code2)

    messages = [SystemMessage(content=system_prompt),
                HumanMessage(content=user_prompt)]
    return messages


def _parse_output(text):
    match = re.search(r"Clone Type:\s*(.*?)\s*(?:[.\n]|$)", text)

    if match:
        clone_type = match.group(1).strip()
        if clone_type in CODE_CLONE_TYPES:
            return {"clone_type": clone_type}
    else:
        print("Invalid output, skipping: \n{}".format(text))
        return None


def _make_pairs(data_list: list):
    return [(data_list[0], d) for d in data_list[1:]]


class CodeCloneDetector():
    def __init__(self, code_dir,
                 embedding_filepath="embeddings.csv",
                 cluster_result_file="clustering_result.csv",
                 result_filepath="ccd_result.json") -> None:

        self.code_dir = code_dir
        self.embedding_filepath = embedding_filepath
        self.cluster_filepath = cluster_result_file
        self.result_filepath = result_filepath

        code_parser = CodeFileParser(self.code_dir).load()
        func_df = pd.DataFrame(code_parser.all_funcs, columns=[
                               "filepath", "function_name", "code"])
        emb_encoder = tiktoken.encoding_for_model("text-embedding-ada-002")

        func_df['filepath'] = func_df['filepath'].apply(
            lambda x: x.replace(self.code_dir, "").replace("\\", "/"))
        func_df["emb_tokens_len"] = func_df["code"].apply(
            lambda c: len(emb_encoder.encode(c)))

        self.func_df = func_df
        self.code_parser = code_parser
        self.emb_client = llm_client.text_embedding_client(request_timeout=10)
        self.chat_client = chat_completion_client(
            temperature=0.3, max_tokens=1000)

    def check_code_clones_in_pairs(self, code_pairs):
        task_list = [{"code_pair": p,
                      "messages": _create_prompt_messages(p[0]["code"], p[1]["code"])} for p in code_pairs]

        # check if client is working
        res_str = self.chat_client.call_as_llm("Hi, this is test")
        print(">>>>>>>>>>>>>>>>> CCD - LLM client working fine: ", res_str)

        @retry(wait=wait_random_exponential(min=1, max=5), stop=stop_after_attempt(3))
        def generate_call(messages):
            chat_client = chat_completion_client(
                temperature=0.3, max_tokens=1000, request_timeout=60)

            return chat_client.generate(messages=messages)

        result = thread_pool_executer(
            lambda task: generate_call([task["messages"]]), task_list, multi_thread=True)

        code_clone_result = []
        for i, task in enumerate(task_list):
            response = result[i]
            if response:
                result_obj = {"code_pair": task["code_pair"],
                              "system_prompt": task["messages"][0].content,
                              "user_prompt": task["messages"][1].content,
                              "response_raw": response.generations[0][0].text,
                              "result_json": _parse_output(response.generations[0][0].text),
                              **response.llm_output.get("token_usage", {"prompt_tokens": 0, "total_tokens": 0})}

                code_clone_result.append(result_obj)

        code_clone_result = [r for r in code_clone_result if r["result_json"]]
        return code_clone_result

    @retry(wait=wait_random_exponential(min=1, max=5), stop=stop_after_attempt(3))
    def merge_clone_codes_with_retry(self, code1, code2):
        chat_client = chat_completion_client(temperature=0.3, max_tokens=1000)
        prompt = MERGE_CLONE_CODES_PROMPT.format(language="python", code1=code1, code2=code2)
        response_str = chat_client.call_as_llm(prompt)
        return response_str

    def run(self):
        df = self.func_df
        #######################
        print(">>>>>>>>>>>>>>>>> CCD - embedding startted")
        df["code_embedding"] = thread_pool_executer(
            target_function=lambda x: self.emb_client.embed_query(x),
            param_list=df.code.values
        )
        print(">>>>>>>>>>>>>>>>> CCD - embedding Completed")
        #######################
        print(">>>>>>>>>>>>>>>>> CCD - Clustering startted")
        X = np.array(list(df.code_embedding.values))
        db = DBSCAN(eps=0.2, min_samples=2).fit(X)
        labels = db.labels_
        n_clusters_ = len(set(labels)) - (1 if -1 in labels else 0)
        n_noise_ = list(labels).count(-1)
        df["cluster"] = labels
        clusters_group = df.loc[df["cluster"] >= 0].groupby("cluster")
        print(">>>>>>>>>>>>>>>>> CCD - Clustering Completed - no_clusters: {}".format(n_clusters_))
        ########################
        print(">>>>>>>>>>>>>>>>> CCD - LLM Clone check started")
        code_pairs = []
        for name, group in clusters_group:
            pair = _make_pairs(group.to_dict(orient="records"))
            code_pairs += pair

        code_clone_result = self.check_code_clones_in_pairs(code_pairs)
        code_clone_result = [r for r in code_clone_result if r["result_json"]
                             ["clone_type"] != "None"]  # drop not clone
        result_df = pd.DataFrame(code_clone_result, columns=[
                                 "prompt_tokens", "total_tokens"])
        print(">>>>>>>>>>>>>>>>> CCD - LLM Clone check Completed")
        #########################
        self.total_emb_tokens = int(self.func_df["emb_tokens_len"].sum())
        self.prompt_tokens = int(result_df["prompt_tokens"].sum())
        self.tokens_used = int(result_df["total_tokens"].sum())
        self.llm_call_cost = CHATMODEL_PRICING * self.tokens_used
        self.code_clone_result = code_clone_result
        self.emb_cost = EMBEDDING_PRICING * self.total_emb_tokens
        self.total_cost = self.llm_call_cost
        self.no_of_prompts = len(code_pairs)

        return self
