import os
import time
import random

import pandas as pd

from Utility.code_clone_detection.clone_detecter import CodeCloneDetector
from Utility.common_utility import utility

CODE_CLONE_CONTEXT = """**Four types of clone:**

1. **Exact clone:** Two code fragments similar to each other with little transformation in comments, layout, or whitespaces.
2. **Parameterized clone:** Changes made in names of variables, keywords, identifiers, or bypassing parameter during function call in code fragments, result in this clone.
3. **Near-miss clone:** Near-miss clone occurs by adding, deleting statements in code fragments of type 2 clones.
4. **Semantic clone:** The code snippets have different syntax but with alike functionality results in this clone.

"""

CLONE_RESULT_TEMPLATE = """**Code Details:**
Code 1: {file1} -> {code1}
Code 2: {file2} -> {code2}
&nbsp;
{llm_response}
"""

MERGED_CLONE_TEMPLATE = """
**Clone details**:
Code 1: {file1} -> {function1}
Code 2: {file2} -> {function2}
Clone Type: {clone_type}
&nbsp;
**Code1**:
```{language}
{code1}
```
&nbsp;
**Code2**:
```{language}
{code2}
```
&nbsp;
{llm_response}
"""


def run_code_clone_detection(usecase_name, job_name, exec_id, uploaded_file_path):
    try:
        uploaded_file_path = os.path.join(
            "Assets", "UploadedData", usecase_name, job_name)
        print(">>>>>>>>>>>>>>>> CCD started, Upload FP: {}".format(
            uploaded_file_path))
        log_name = usecase_name
        utility.createLOGFile(log_name)
        utility.updatelog(
            log_name, "***** ***** ***** ***** Started ***** ***** ***** *****", False)

        ccd = CodeCloneDetector(uploaded_file_path).run()
        code_parser = ccd.code_parser

        result_summary = {}
        result_summary['job_name'] = job_name
        result_summary['numof_files'] = code_parser.total_files
        result_summary['numof_prompts_executed'] = ccd.no_of_prompts
        result_summary['prompt_tokens'] = ccd.prompt_tokens
        result_summary['total_tokens'] = ccd.tokens_used
        result_summary['prompt_cost'] = round(ccd.total_cost, 4)

        # Result Details
        code_clone_count_by_type_table_str = pd.json_normalize(ccd.code_clone_result).groupby("result_json.clone_type", as_index=False).agg(Count=(
            'result_json.clone_type', 'count')).rename({"result_json.clone_type": "Clone Type"}, axis=1).to_markdown(index=False) if len(ccd.code_clone_result) > 0 else ""

        result_summary_str = CODE_CLONE_CONTEXT
        result_summary_str += f"**Total code clones detected:** {len(ccd.code_clone_result)}\n&nbsp;\n"

        if code_clone_count_by_type_table_str:
            result_summary_str += f"**Code clones count by type:**\n&nbsp;\n{code_clone_count_by_type_table_str}"

        execution_details = [
            {'execution_id': exec_id,
             'prompt': "",
             'title': "Code Clone Check Result Summary",
             'result': result_summary_str}]

        # Append each code clone result
        for result in ccd.code_clone_result:
            code1, code2 = result["code_pair"]
            response_bold = result["response_raw"]\
                .replace("Observations:", "**Observations**:")\
                .replace("Clone Type:", "**Clone Type**:")

            result_display = CLONE_RESULT_TEMPLATE.format(
                file1=code1["filepath"],
                file2=code2["filepath"],
                code1=code1["function_name"],
                code2=code2["function_name"],
                llm_response=response_bold
            )

            execution_details.append(
                {'execution_id': exec_id,
                 'prompt': result["user_prompt"],
                 'title': result["result_json"]["clone_type"],
                 'result': result_display})

        # Add merge clone example and code search example
        if len(ccd.code_clone_result) > 0:
            random_clone_result = random.choice(ccd.code_clone_result)

            merged_code = ccd.merge_clone_codes_with_retry(
                code1=random_clone_result["code_pair"][0]["code"],
                code2=random_clone_result["code_pair"][1]["code"]
            )

            result_str = MERGED_CLONE_TEMPLATE.format(
                language="python",
                file1=random_clone_result["code_pair"][0]["filepath"],
                file2=random_clone_result["code_pair"][1]["filepath"],
                function1=random_clone_result["code_pair"][0]["function_name"],
                function2=random_clone_result["code_pair"][1]["function_name"],
                code1=random_clone_result["code_pair"][0]["code"],
                code2=random_clone_result["code_pair"][1]["code"],
                clone_type=random_clone_result["result_json"]["clone_type"],
                llm_response=merged_code
            )

            execution_details.append(
                {'execution_id': exec_id,
                 'prompt': result["user_prompt"],
                 'title': "Merge code and create single function",
                 'result': result_str})

            execution_details.append(
                {'execution_id': exec_id,
                 'prompt': result["user_prompt"],
                 'title': "Code search examples",
                 'result': "![ccd example](http://localhost:8001/static/image/ccd_examples.PNG)"})

        utility.saveExecutionDetails(execution_details)
        utility.saveExecutionSummary(result_summary, exec_id)

        final_response = {}
        final_response["status"] = "success"
        final_response["msg"] = ""
        final_response["result_summary"] = result_summary
        final_response["input_file_details"] = []
        final_response["output_file_type"] = ".txt"
        utility.updatelog(log_name, "\nResult Summary Generated Successfully!" +
                          "\n\n***** ***** ***** ***** Completed ***** ***** ***** *****", False)
        return final_response

    except Exception as e:
        utility.updatelog(log_name, str(e), True)
        final_response = {}
        final_response["status"] = "failed"
        final_response["msg"] = str(e)
        final_response["result_summary"] = {}
        final_response["input_file_details"] = []
        final_response["output_file_type"] = ""
        return final_response
