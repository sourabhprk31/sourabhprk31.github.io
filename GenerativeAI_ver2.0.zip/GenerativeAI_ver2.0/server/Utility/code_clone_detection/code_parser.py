import os
from glob import glob

OPENAI_EMBEDDING_MODEL = "embedding"
OPENAI_CHAT_MODEL = "chat-model"
EMBEDDING_PRICING = 0.0004/1000
CHATMODEL_PRICING = 0.002/1000


class CodeFileParser():

    def __init__(self, code_dir) -> None:
        self.code_dir = code_dir

    def get_files(self):
        code_files = [y for x in os.walk(self.code_dir)
                      for y in glob(os.path.join(x[0], '*.py'))]

        return code_files

    def _get_function_name(self, code):
        """
        Extract function name from a line beginning with "def "
        """
        assert code.startswith("def ")
        return code[len("def "): code.index("(")]

    def _get_until_no_space(self, all_lines, i) -> str:
        """
        Get all lines until a line outside the function definition is found.
        """
        ret = [all_lines[i]]
        for j in range(i + 1, i + 10000):
            if j < len(all_lines):
                if len(all_lines[j]) == 0 or all_lines[j][0] in [" ", "\t", ")"]:
                    ret.append(all_lines[j])
                else:
                    break
        return "\n".join(ret)

    def get_functions_from_codefile(self, filepath):
        """
        Get all functions in a Python file.
        """
        whole_code = open(filepath).read().replace("\r", "\n")
        all_lines = whole_code.split("\n")
        for i, l in enumerate(all_lines):
            if l.startswith("def "):
                code = self._get_until_no_space(all_lines, i)
                function_name = self._get_function_name(code)
                yield {"code": code, "function_name": function_name, "filepath": filepath}

    def get_functions(self):
        code_files = self.get_files()
        all_funcs = []
        for code_file in code_files:
            funcs = list(self.get_functions_from_codefile(code_file))
            for func in funcs:
                all_funcs.append(func)

        return all_funcs

    def load(self):
        self.code_files = self.get_files()
        self.total_locs = 0

        for file in self.code_files:
            with open(file) as f:
                self.total_locs += len(f.readlines())

        self.all_funcs = self.get_functions()
        self.total_files = len(self.code_files)
        self.total_funcs = len(self.all_funcs)
        print(">>>>>>>>>>>>>>>>> CCD - Total functions: {}".format(self.total_funcs))

        return self