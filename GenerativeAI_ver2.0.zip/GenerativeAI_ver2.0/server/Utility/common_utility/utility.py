"""
=============================================================================
COPYRIGHT NOTICE
=============================================================================
© Copyright HCL Technologies Ltd. 2021, 2022, 2023
Proprietary and confidential. All information contained herein is, and
remains the property of HCL Technologies Limited. Copying or reproducing the
contents of this file, via any medium is strictly prohibited unless prior
written permission is obtained from HCL Technologies Limited.
"""
import os
import json
from pandas import DataFrame
import configparser
import shutil
import ast
import astor
import tokenize
import io
import charset_normalizer
import tiktoken
from datetime import datetime
from langchain.text_splitter import (
    RecursiveCharacterTextSplitter,
    Language,
)

from reportlab.lib.pagesizes import letter  
from reportlab.pdfgen import canvas 
import textwrap  

from Utility.db_utility import db_utility as db_utils

### Configured the ROOt Path
cwdPath = os.path.abspath(os.getcwd())

project_rootpath = os.path.join(cwdPath, "Projects")
usecase_rootpath = os.path.join(cwdPath, "UsecaseResult")
Result_rootpath = os.path.join(cwdPath, "Result")


Assets_rootpath = os.path.join(cwdPath, "Assets")
UploadData_rootpath = os.path.join(Assets_rootpath, "UploadedData")
Logs_rootpath = os.path.join(Assets_rootpath, "Logs")

config_path = os.path.join(cwdPath, "config")

### Create Directory IF NOT EXISTS
def createDirectory(create_path):
    if not os.path.exists(create_path):
        os.makedirs(create_path)
    return True


### Get the Directory Name From Path
def get_folder_path(content):
    last_index = content.rfind('/')
    if last_index != -1:  
        dir_name = content[:last_index]  
        return dir_name  

### Handle the Uploaded Directory 
def handleUploadDirectory(uploaded_files, usecase_name, job_name, request):
    upload_root_path  = os.path.join(UploadData_rootpath,usecase_name,job_name)
    createDirectory(upload_root_path)
    for file in uploaded_files:
        file_path = request.POST.get(f'path_{file.name}_{file.size}') 
        upload_form_path = get_folder_path(file_path)
        handle_uploaded_file(upload_root_path, upload_form_path, file=file)
    return upload_form_path.split('/')[0]


### Save the uploaded files into Local Folder
def handle_uploaded_file(upload_root_path, upload_form_path, file):
    try:
        save_path = os.path.join(upload_root_path,upload_form_path)
        if not os.path.exists(save_path):
            os.makedirs(save_path) 
        with open(os.path.join(save_path, file.name), 'wb+') as destination:
            for chunk in file.chunks():
                destination.write(chunk)
            return os.path.join(save_path, file.name)
    except Exception as e:
        print("Upload Exception :>>", str(e))

def generate_jobname(exec_start_time, usecase_name):
    job_postfix_name = exec_start_time.strftime("%Y%m%d%H%M%S")
    if usecase_name == "Vulnerability Assessment":
        uc = "VA"
    elif usecase_name == "Code Generation":
        uc = "CG"
    elif usecase_name == "Code Summarization":
        uc = "CS"
    elif usecase_name == "Code Clone Detection":
        uc = "CC"
    elif usecase_name == "Code Refactoring":
        uc = "CR"
    elif usecase_name == "SQL Generation":
        uc = "SG"
    elif usecase_name == "SQL Summarization":
        uc = "SS"
    elif usecase_name == "Change Impact Analysis":
        uc = "CIA"
    else:
        uc = "TEST"

    job_name = "UC_" + uc + "_"+ str(job_postfix_name)
    return job_name

   
### Create the LOG FILE IF NOT EXISTS
# DELETE the content IF EXISTS
def createLOGFile(log_name):
    logs_path = os.path.join(Logs_rootpath, log_name)
    with open(logs_path, "w") as file:  
        pass 

### Updating the LOGS
def updatelog(log_name, log_content, date_display):
    logs_path = os.path.join(Logs_rootpath, log_name)
    current_date_time = datetime.now()  
    formatted_date_time = current_date_time.strftime("%d-%m-%Y %H:%M:%S")
    if date_display == True:
        formatted_line = f"{formatted_date_time}   {log_content}"
    else:
        formatted_line = f"{log_content}"

    with open(logs_path, "r") as file:  
        content = file.read()  

    updated_content = content + formatted_line  +"\n" 
    with open(logs_path, "w") as file:  
        file.write(updated_content) 


### Generating the Dynamic Prompt
def generatePrompt(form_data, prompt_values, additional_info, input_control, input_data):
    FinalPrompt = ""
    SystemRole = ""
    for (input_id, input_type) in input_control.items():
        system_role_id = additional_info['SYSTEM_ROLE'] if "SYSTEM_ROLE" in additional_info else 0
        if system_role_id == input_id:
            selected_option = form_data[input_id]  if input_id in form_data else ""
            selected_input_data = input_data[input_id]  if input_id in input_data else ""
            indexvalue = selected_input_data.index(selected_option)
            selected_prompt_value = prompt_values[input_id]  if input_id in prompt_values else ""
            SystemRole =  selected_prompt_value[indexvalue]
        else:
            if input_type == "text_area":
                FinalPrompt += prompt_values[input_id]  if input_id in prompt_values else ""
                FinalPrompt += "\n"
                FinalPrompt += form_data[input_id]  if input_id in form_data else ""
                FinalPrompt += "\n\n"
            else:
                selected_option = form_data[input_id]  if input_id in form_data else ""
                selected_input_data = input_data[input_id]  if input_id in input_data else ""
                indexvalue = selected_input_data.index(selected_option)
                selected_prompt_value = prompt_values[input_id]  if input_id in prompt_values else ""
                FinalPrompt += selected_prompt_value[indexvalue]+" "

    print("----------START-----------")
    print("SystemRole :>>", SystemRole)
    print("FinalPrompt :>>", FinalPrompt)
    print("----------END-----------")
    return SystemRole, FinalPrompt

### Generate Prompt Main Function
def GeneratePromptFromInput(usecase_name, form_data, log_name):
    updatelog(log_name, "Prompt Generating...", True)
    response = db_utils.get_promptValue(usecase_name)
    promptValue = response["data"][0]
    prompt_values = json.loads(promptValue["prompt_value"].replace('\'','\"'))
    additional_info = json.loads(promptValue["additional_info"].replace('\'','\"'))
    input_control = json.loads(promptValue["input_control"].replace('\'','\"'))
    input_data = json.loads(promptValue["input_data"].replace('\'','\"'))

    SystemRole, FinalPrompt = generatePrompt(form_data, prompt_values, additional_info, input_control, input_data)
    updatelog(log_name, "Prompt Generated Successfully!\n", True)
    return SystemRole, FinalPrompt


### Return the List of Files from given Uploaded Directory
def read_inputdirectory(usecase_name, job_name):
    file_list = [] 
    input_dirpath = os.path.join(UploadData_rootpath, usecase_name, job_name)
    for root, _, files in os.walk(input_dirpath):  
        for file in files:
            file_path = os.path.join(root, file)  
            relative_path = os.path.relpath(file_path, input_dirpath)
            
            file_list.append(relative_path)  
    return file_list

### Read & Return the File Content using Job Name and File Name
def read_inputfile(usecase_name, job_name, file_relpath, id, file_count, log_name):
    log_content = "\n------------------------------------------------------\n"
    log_content += "***** ***** ****** "+str(id)+" Out of "+str(file_count)+" Files ****** ***** *****"
    log_content += "\n------------------------------------------------------"
    updatelog(log_name, log_content, False)
    input_file_path = os.path.join(UploadData_rootpath, usecase_name, job_name, file_relpath)
    with open(input_file_path, 'r') as file: 
        file_content = file.read() 
        file_size = os.path.getsize(input_file_path) 
        file_name = os.path.basename(input_file_path)
        updatelog(log_name, "File Read Successfully! ["+file_name+"]\n", True)
        return file_content, file_size, file_name
    
### Find the Line of Code / Number of Word from Given File
def getcount(inputfile_path, count_type):
    count = 0  
    with open(inputfile_path, 'r') as file:  
        for line in file: 
            if count_type == "LoC":  #Line of Code
                count += 1
            elif count_type == "NoW": #Number of Word
                words = line.split()  
                count += len(words) 
            elif count_type == "NoC": #Number of Character
                count += len(line)  
    return count

### Find the Line of Code/Charactor,Word and Function from Given File
def check_count(usecase_name, job_name, file_relpath, count_type):
    inputfile_path = os.path.join(UploadData_rootpath, usecase_name, job_name, file_relpath)
    count = 0
    if count_type == "LoC": #Line of Code
        count = getcount(inputfile_path, count_type)
    elif count_type == "NoW": #Number of Word
        count = getcount(inputfile_path, count_type)
    elif count_type == "NoC": #Number of Character
        count = getcount(inputfile_path, count_type)
    elif count_type == "NoF":
        count = 0

    return count


def saveExecutionSummary(result_summary, exec_id):
    try:
        config_parser = configparser.ConfigParser()
        config_parser.read(os.path.join(config_path, "result_summary.ini"))
    
        data_ = []
        for key in result_summary.keys():
            tmp_ = {}
            tmp_['execution_id'] = exec_id
            tmp_['key'] = config_parser.get("title", key)
            tmp_['value'] = str(result_summary[key])
            tmp_['remarks'] = ""
            data_.append(tmp_)

        summ_df = DataFrame(data_)
        db_utils.save_df_to_db(summ_df, 'execution_summary')
        return True
    except Exception as e:
        print(str(e))
        return False
    
def saveExecutionDetails(execution_details):
    try:
        final_df = DataFrame(execution_details)
        db_utils.save_df_to_db(final_df, 'execution_details')
        return True
    except Exception as e:
        print(str(e))
        return False
    

### Splitter
def count_tokens(filecontent, encoding_name="r50k_base"):
    encoding = tiktoken.get_encoding(encoding_name)
    num_tokens = len(encoding.encode(filecontent))
    return num_tokens

def code_splitter(filecontent, lang, chunk_size=5000, chunk_overlap=15):
    code_splitter = RecursiveCharacterTextSplitter.from_language(language=eval(f"Language.{lang}"), chunk_size=chunk_size, chunk_overlap=chunk_overlap)
    code_docs = code_splitter.create_documents([filecontent])
    return code_docs

def text_splitter(filecontent, chunk_size = 15000, chunk_overlap = 20):
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=chunk_size, chunk_overlap = chunk_overlap, length_function = len, add_start_index = True)
    text_docs = text_splitter.create_documents([filecontent])
    return text_docs

