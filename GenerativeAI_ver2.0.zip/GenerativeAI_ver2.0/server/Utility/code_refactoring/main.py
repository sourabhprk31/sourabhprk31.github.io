import os
import time

import pandas as pd

from Utility.code_refactoring.code_refactor import CodeRefactor
from Utility.common_utility import utility

CODE_REFACOTRING_RESULT_TEMPLATE = """**Input code**:
```{language}
{input_code}
```
&nbsp;
**Code violations**:
{violations_str}
&nbsp;

{llm_response}
"""


def run_code_refactoring(usecase_name, job_name, exec_id, uploaded_file_path):
    try:
        uploaded_file_path = os.path.join(
            "Assets", "UploadedData", usecase_name, job_name)
        print(">>>>>>>>>>>>>>>> CCD started")
        log_name = usecase_name
        utility.createLOGFile(log_name)
        utility.updatelog(
            log_name, "***** ***** ***** ***** Started ***** ***** ***** *****", False)

        code_refactor_agent = CodeRefactor(
            code_root=uploaded_file_path, language="python")
        code_refactor_obj = code_refactor_agent.run()

        code_refactor_result_df = pd.json_normalize(
            code_refactor_obj.code_refactor_result)

        result_summary = {}
        result_summary['job_name'] = job_name
        result_summary['numof_files'] = len(
            code_refactor_obj.code_parser.code_files)
        result_summary['numof_prompts_executed'] = len(
            code_refactor_obj.code_refactor_result)
        result_summary['prompt_tokens'] = int(
            code_refactor_result_df["result.prompt_tokens"].sum())
        result_summary['total_tokens'] = int(
            code_refactor_result_df["result.prompt_tokens"].sum())
        result_summary['prompt_cost'] = int(
            code_refactor_result_df["result.prompt_tokens"].sum()) * (0.002/1000)

        # Result Details
        execution_details = []

        for crfr in code_refactor_obj.code_refactor_result:
            violations_str = "\n".join(
                [f"{i+1}. {v}" for i, v in enumerate(crfr["code_violations"])])

            reusult_str = CODE_REFACOTRING_RESULT_TEMPLATE.format(
                language="python",
                input_code=crfr["source_code"],
                violations_str=violations_str,
                llm_response=crfr["result"]["output_str"]
            )

            execution_details.append(
                {'execution_id': exec_id,
                 'prompt': crfr["prompt_message"][1]["content"],
                 'title': os.path.relpath(crfr["filename"], uploaded_file_path) + " -> " + crfr["code_name"],
                 'result': reusult_str}
            )

        utility.saveExecutionDetails(execution_details)
        utility.saveExecutionSummary(result_summary, exec_id)

        final_response = {}
        final_response["status"] = "success"
        final_response["msg"] = ""
        final_response["result_summary"] = result_summary
        final_response["input_file_details"] = []
        final_response["output_file_type"] = ".txt"
        utility.updatelog(log_name, "\nResult Summary Generated Successfully!" +
                          "\n\n***** ***** ***** ***** Completed ***** ***** ***** *****", False)
        return final_response

    except Exception as e:
        utility.updatelog(log_name, str(e), True)
        final_response = {}
        final_response["status"] = "failed"
        final_response["msg"] = str(e)
        final_response["result_summary"] = {}
        final_response["input_file_details"] = []
        final_response["output_file_type"] = ""
        return final_response
