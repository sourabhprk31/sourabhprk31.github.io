SYSTEM_PROMPT = "You are a Senoir software engineer, having good grasp of python. You write beautiful programms with best practices, also helps peers in code refactoring."

USRER_PROMPT_TEMPATE = """You are given a Python code snippet, which is just small chunk of a complete code file.
I have identified some code violations (listed below) in the code snippet, So you need to refactor it and fix all issues.

Remember, Code refactoring should not break functionality or change external behavior of the code.
Assume all functions and modules used inside the code are already imported at the file top, So don't make additional import.

Code violations:
{code_violations_str}

Input Code:
```python
{problematic_code}
```

First, just make high level plan for code refactor changes needed to fix each code violation.
After making complete refactoring changes plan, Write and return the final refactored code.

Your response should be in following markdown format:

**Refactor changes**: List of refactoring changes needed.
**Refactored code**: Your final refactored code.

"""
