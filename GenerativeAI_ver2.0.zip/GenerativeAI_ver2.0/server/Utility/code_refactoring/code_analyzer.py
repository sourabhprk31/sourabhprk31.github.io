import abc
import json
import subprocess
from dataclasses import dataclass


class BaseCodeAnalyzer(abc.ABC):
    def __init__(self, code_root, *args, **kwargs) -> None:
        self.code_root = code_root
        self.args = args
        self.kwargs = kwargs
        self.code_analysis_report = None

    @abc.abstractmethod
    def run(self) -> "BaseCodeAnalyzer":
        pass


class PythonCodeAnalyzer(BaseCodeAnalyzer):
    def __init__(self, code_root, *args, **kwargs) -> None:
        super().__init__(code_root, *args, **kwargs)

    def run_ruff_analysis(self, ruff_config=None):
        config = ruff_config or self.kwargs.get("ruff_config")
        ruff_cmd = ["ruff", "check", "--format", "json", self.code_root]

        if config:
            ruff_cmd.insert(2, "--config")
            ruff_cmd.insert(3, config)

        p = subprocess.Popen(ruff_cmd,
                             stdout=subprocess.PIPE,
                             stderr=subprocess.PIPE,
                             text=True)

        report_json = json.loads(p.stdout.read())
        # [{
        #     "code": "D101", -> error_code
        #     "message": "Missing docstring in public class",
        #     "fix": null,
        #     "location": {
        #     "row": 14,
        #     "column": 7
        #     },
        #     "end_location": {
        #     "row": 14,
        #     "column": 23
        #     },
        #     "filename": "",
        #     "noqa_row": 14
        # },]
        return [r for r in report_json]

    def run(self):
        ruff_result_json = self.run_ruff_analysis()

        self.code_analysis_report = ruff_result_json
        return self


class JavaCodeAnalyzer(BaseCodeAnalyzer):
    def __init__(self, code_root, *args, **kwargs) -> None:
        super().__init__(code_root, *args, **kwargs)


class CodeAnalyzer:
    CODE_ANALYZER_LANGUAGE_MAP = {
        "python": PythonCodeAnalyzer,
        "java": JavaCodeAnalyzer
    }

    @classmethod
    def create(self, code_root, language) -> BaseCodeAnalyzer:
        target_class = self.CODE_ANALYZER_LANGUAGE_MAP.get(language)
        return target_class(code_root)
