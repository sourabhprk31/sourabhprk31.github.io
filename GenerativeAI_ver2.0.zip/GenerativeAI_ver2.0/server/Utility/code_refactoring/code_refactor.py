import concurrent.futures
import json
from typing import AnyStr, List

import pandas as pd
from tenacity import retry, stop_after_attempt, wait_random_exponential

from Utility.code_clone_detection.utilts import thread_pool_executer
from Utility.code_refactoring.code_analyzer import CodeAnalyzer
from Utility.code_refactoring.code_parser import CodeParser
from Utility.code_refactoring.prompts import (SYSTEM_PROMPT,
                                              USRER_PROMPT_TEMPATE)
from Utility.llms.llm_client import chat_completion_client
from Utility.llms.utility import convert_dict_to_message


def _dict_to_messages(dict_messages):
    return [convert_dict_to_message(m) for m in dict_messages]


def _prepare_refactor_prompt_message(problematic_code: AnyStr, code_violations: List[AnyStr]):

    violations_str = "\n".join(
        [f"{i+1}. {v}" for i, v in enumerate(set(code_violations))])
    user_prompt = USRER_PROMPT_TEMPATE.format(problematic_code=problematic_code,
                                              code_violations_str=violations_str)

    prompt_message = [{"role": "system", "content": SYSTEM_PROMPT},
                      {"role": "user", "content": user_prompt}]
    return prompt_message


class CodeRefactor():
    def __init__(self, code_root, language) -> None:
        self.code_root = code_root
        self.language = language

    @retry(wait=wait_random_exponential(min=1, max=5), stop=stop_after_attempt(3))
    def refactor_code_with_retry(self, refactoring_message):
        chat_client = chat_completion_client(
            temperature=0.3, max_tokens=2000, request_timeout=120)

        result = chat_client.generate(messages=[refactoring_message])
        output_str = result.generations[0][0].text
        token_usage = result.llm_output.get(
            "token_usage", {"prompt_tokens": 0, "total_tokens": 0})

        response = {
            "output_str": output_str,
            "prompt_tokens": token_usage["prompt_tokens"],
            "total_tokens": token_usage["total_tokens"]
        }
        return response

    def bulk_refatoring(self, refactoring_messages):
        result = thread_pool_executer(
            self.refactor_code_with_retry, refactoring_messages, multi_thread=False)
        return result

    def run(self):
        code_parser = CodeParser.create(
            code_root=self.code_root, language=self.language)
        print("CRF>>>>>>>>>>>>>>>>>>> Code analysis started")
        code_analyzer = CodeAnalyzer.create(
            code_root=self.code_root, language=self.language)
        code_anlysis_obj = code_analyzer.run()
        code_analysis_report = code_anlysis_obj.code_analysis_report
        print("CRF>>>>>>>>>>>>>>>>>>> Code analysis end, violations: ",
              len(code_analysis_report))

        code_violations_with_code = map(lambda x: {**x, "source_code": code_parser.get_parent_code_by_line_no(
            code_type="function_def", filename=x.get("filename"), line_no=x.get("noqa_row"))}, code_analysis_report)

        code_violations_df = pd.json_normalize(
            code_violations_with_code).dropna(axis=0, subset=["source_code.source_code"])

        code_violations_grouped = code_violations_df.groupby(
            ["filename", "source_code.type", "source_code.name", "source_code.source_code"])

        code_refactoring_tasks = []
        for name, group in code_violations_grouped:
            code_refactoring_tasks.append({
                "filename": name[0],
                "code_type": name[1],
                "code_name": name[2],
                "source_code": name[3],
                "code_violations": group["message"].tolist(),
                "prompt_message": _prepare_refactor_prompt_message(name[3], group["message"].tolist())
            })
        print(">>>>>>>>>>>>>>>>>>>> total refacoring tasks",
              len(code_refactoring_tasks))

        print(">>>>>>>>>>>>>>>>>> Code refactoring started")
        result = self.bulk_refatoring([_dict_to_messages(
            rft["prompt_message"]) for rft in code_refactoring_tasks])
        print(">>>>>>>>>>>>>>>>>> Code refactoring completed")

        code_refactoring_tasks_result = [
            {**t, "result": result[i]} for i, t in enumerate(code_refactoring_tasks)]

        self.code_refactor_result = code_refactoring_tasks_result
        self.code_parser = code_parser
        return self
