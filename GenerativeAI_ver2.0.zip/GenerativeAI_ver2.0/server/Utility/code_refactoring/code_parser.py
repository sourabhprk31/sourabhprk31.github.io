import abc
import ast
import os
from glob import glob
from typing import Literal, Union

import astor
import charset_normalizer


class BaseCodeParser(abc.ABC):
    def __init__(self, code_root) -> None:
        self.code_root = code_root


class PythonCodeParser(BaseCodeParser):

    AST_TYPE_MAP = {
        "function_def": ast.FunctionDef,
        "class_def": ast.ClassDef
    }

    @staticmethod
    def _get_files(code_root, include_pattern="*.py"):
        code_files = [y for x in os.walk(code_root)
                      for y in glob(os.path.join(x[0], include_pattern))]
        return code_files

    @staticmethod
    def _get_total_locs(code_files):
        count = 0
        for file in code_files:
            with open(file) as f:
                count += len(f.readlines())
        return count

    @staticmethod
    def _get_file_to_ast_map(code_files):
        file_to_ast_map = {
            file: astor.parse_file(file)
            for file in code_files
        }
        return file_to_ast_map

    def __init__(self, code_root) -> None:
        super().__init__(code_root)
        self.code_root = code_root
        self.code_files = self._get_files(code_root)
        self.total_locs = self._get_total_locs(self.code_files)
        self.file_ast_map = self._get_file_to_ast_map(self.code_files)

    def _get_node_details(self, node: ast.AST, filename):
        code_str = str(charset_normalizer.from_path(filename).best())
        source_code_lines = code_str.replace(
            "\r\n", "\n").replace("\r", "\n").split("\n")

        return {'name': node.name,
                # 'source_code': astor.to_source(node),
                'source_code': "\n".join(source_code_lines[node.lineno-1: node.end_lineno]),
                'lineno': node.lineno,
                'end_lineno':  node.end_lineno,
                'col_offset': node.col_offset,
                'end_col_offset': node.end_col_offset,
                'locs': (node.end_lineno - node.lineno + 1)}

    def get_all_codes_by_type(self, code_type: Literal["function_def", "class_def"]):
        result = []
        for file in self.code_files:
            tree = astor.parse_file(file)
            for node in ast.walk(tree):
                if isinstance(node, self.AST_TYPE_MAP.get(code_type)):
                    result.append(
                        {'filename': file, "type": code_type,  ** self._get_node_details(node, filename=file)})
        return result

    def get_parent_code_by_line_no(self, code_type: Literal["function_def", "class_def"], filename, line_no):
        tree = self.file_ast_map.get(filename) or astor.parse_file(filename)
        for node in ast.iter_child_nodes(tree):
            if isinstance(node, self.AST_TYPE_MAP.get(code_type)):
                if node.lineno <= line_no and node.end_lineno >= line_no:
                    return {'filename': filename, "type": code_type, ** self._get_node_details(node, filename=filename)}
        return None

    def get_class_hirarchy_family(self, class_name):
        pass


class CodeParser:

    CODE_PARSER_MODULE_MAP = {
        "python": PythonCodeParser,
    }

    @classmethod
    def create(cls, code_root, language) -> Union[BaseCodeParser, PythonCodeParser]:
        target_class = cls.CODE_PARSER_MODULE_MAP.get(language)
        return target_class(code_root=code_root)
