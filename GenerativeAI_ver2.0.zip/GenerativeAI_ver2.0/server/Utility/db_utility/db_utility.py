"""
=============================================================================
COPYRIGHT NOTICE
=============================================================================
© Copyright HCL Technologies Ltd. 2021, 2022, 2023
Proprietary and confidential. All information contained herein is, and
remains the property of HCL Technologies Limited. Copying or reproducing the
contents of this file, via any medium is strictly prohibited unless prior
written permission is obtained from HCL Technologies Limited.
"""


from Utility.db_utility import postgres_conn

def create_ui_controls_table():
    create_query = '''CREATE TABLE IF NOT EXISTS public.ui_controls
                    (
                        id serial NOT NULL PRIMARY KEY,
                        usecase_name character varying(50),
                        usecase_type character varying(25),
                        input_control json,
                        input_label json,
                        input_data json,
                        input_visibility json,
                        default_value json,
                        prompt_value json,
                        additional_info json,
                        usecase_info character varying,
                        active_status boolean
                    )'''
    postgres_conn.execute_create_query(create_query)

def create_execution_info_table():
    create_query = '''CREATE TABLE IF NOT EXISTS public.execution_info
                    (
                        execution_id serial NOT NULL PRIMARY KEY,
                        usecase_name character varying(50),
                        job_name character varying(50),
                        input_prompt text,
                        input_files_count integer,
                        exec_starttime timestamp without time zone,
                        exec_endtime timestamp without time zone,
                        status boolean,
                        isdeleted boolean,
                        error_msg text
                    )'''
    postgres_conn.execute_create_query(create_query)


def get_menu_names():
    create_ui_controls_table()
    query = '''select usecase_name from public.ui_controls order by id asc'''
    result = postgres_conn.execute_get_query(query,[])
    return result


def get_ui_controls(usecase_name):
    create_ui_controls_table()
    query = '''SELECT id, usecase_name, usecase_type, input_control, input_label, input_data, input_visibility, default_value, usecase_info from public.ui_controls where usecase_name=%s'''
    result = postgres_conn.execute_get_query(query,[usecase_name])
    return result

def insert_execution_info(data_obj):
    create_execution_info_table()
    try:
        query = '''INSERT INTO public.execution_info(usecase_name, job_name, input_prompt, input_files_count, exec_starttime) VALUES (%s, %s, %s, %s, %s);'''
        result = postgres_conn.execute_insert_query(query, data_obj)
        query_ = '''SELECT MAX(execution_id) FROM public.execution_info'''
        result_ = postgres_conn.execute_get_query(query_, [])
        exec_id = result_['data'][0]['max']
        return {'status': result, 'exec_id': exec_id}
    except Exception as e:
        print(f"Error inserting usecase details: {e}")  
        return None

def get_promptValue(usecase_name):
    query = '''SELECT id, usecase_name, input_control, input_data, prompt_value, additional_info from public.ui_controls where usecase_name=%s'''
    result = postgres_conn.execute_get_query(query, [usecase_name])
    return result

def getinput_visibility_details(usecase_name):
    query = '''SELECT input_visibility, input_control from public.ui_controls where usecase_name=%s'''
    result = postgres_conn.execute_get_query(query, [usecase_name])
    return result
# # Duplicate
# def insert_usecase_details(usecase_name, job_name, input_prompt, input_files_count, exec_starttime):  
#     try:  
#         query = 'INSERT INTO public.execution_info(usecase_name, job_name, input_prompt, input_files_count, exec_starttime, exec_endtime, status, isdeleted, error_msg) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s);'  
#         insert_data_obj = (usecase_name, job_name, input_prompt, input_files_count, exec_starttime, '', '', False, '')  
#         result = postgres_conn.execute_insert_query_get_id(query, insert_data_obj)  
#         return result  
#     except Exception as e:  
#         print(f"Error inserting usecase details: {e}")  
#         return None  
  
  
def insert_usecase_summary(execution_id, key, value, remark):  
    try:  
        query = 'INSERT INTO public.execution_summary(execution_id, key, value, remarks) VALUES (%s, %s, %s, %s);'  
        insert_data_obj = (execution_id, key, value, remark)  
        result = postgres_conn.execute_insert_query(query, insert_data_obj)  
        return result  
    except Exception as e:  
        print(f"Error inserting usecase summary: {e}")  
        return None  
  
  
# def insert_usecase_detail(execution_id, prompt, title, result):  
#     try:  
#         query = 'INSERT INTO public.execution_details(execution_id, prompt, title, result) VALUES (%s, %s, %s, %s);'  
#         insert_data_obj = (execution_id, prompt, title, result)  
#         result = postgres_conn.execute_insert_query(query, insert_data_obj)  
#         return result  
#     except Exception as e:  
#         print(f"Error inserting usecase detail: {e}")  
#         return None  
  
  
# def update_usecase_details(execution_id, exec_endtime, status, error_msg):
def update_execution_info(job_name, exec_endtime, status, error_msg):
    try:  
        query = 'UPDATE public.execution_info SET exec_endtime=%s, status=%s, error_msg=%s WHERE job_name=%s'  
        update_data_obj = (exec_endtime, status, error_msg, job_name)  
        result = postgres_conn.execute_insert_query(query, update_data_obj)  
        return result  
    except Exception as e:  
        print(f"Error updating usecase details: {e}")  
        return None  


def get_execution_preview_data(execution_id):
    try:
        execution_info_query = '''SELECT execution_id, usecase_name, job_name, input_prompt, input_files_count, exec_starttime, exec_endtime FROM public.execution_info WHERE execution_id=%s'''
        execution_summary_query = '''SELECT key, value FROM public.execution_summary WHERE execution_id=%s ORDER BY summary_id'''
        execution_detail_query = '''SELECT title, result FROM public.execution_details WHERE execution_id=%s ORDER BY execution_detail_id'''
        result = {
            "execution_info": postgres_conn.execute_query_to_get_result(execution_info_query, [execution_id]),
            "execution_summary": postgres_conn.execute_query_to_get_result(execution_summary_query, [execution_id]),
            "execution_detail": postgres_conn.execute_query_to_get_result(execution_detail_query, [execution_id])
        }
        return result
    except Exception as e:
        print(f"Error fetching usecase execution details: {e}")  
        return None  

def get_execution_info_data(usecase_name):
    try:
        query = '''SELECT ROW_NUMBER() OVER(ORDER BY execution_id desc) as serial_no, execution_id, job_name, a.usecase_name, exec_starttime, exec_endtime, input_files_count, usecase_type FROM public.execution_info a, public.ui_controls b WHERE (isdeleted='False' OR isdeleted IS NULL) and a.usecase_name =b.usecase_name and a.usecase_name=%s ORDER BY execution_id desc'''
        result = postgres_conn.execute_query_to_get_result(query, [usecase_name])
        return result
    except Exception as e:
        print(f"Error on fetching Execution Info: {e}")  
        return None


def save_df_to_db(df, table_name):
    try:
        ret = postgres_conn.save_dataframe(df, table_name)
        return ret
    except Exception as e:
        print(f"Error on saving the execution details: {e}")
        return None


def delete_execution_info(execution_id):
    try:
        query = '''UPDATE public.execution_info SET isdeleted='True' WHERE execution_id=%s'''
        result = postgres_conn.execute_insert_query(query, (execution_id))  
        return result  
    except Exception as e:
        print(f"Error on updating the execution info: {e}")
        return "Failure"