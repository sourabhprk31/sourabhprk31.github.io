"""
=============================================================================
COPYRIGHT NOTICE
=============================================================================
© Copyright HCL Technologies Ltd. 2021, 2022, 2023
Proprietary and confidential. All information contained herein is, and
remains the property of HCL Technologies Limited. Copying or reproducing the
contents of this file, via any medium is strictly prohibited unless prior
written permission is obtained from HCL Technologies Limited.
"""
import os
import configparser
import urllib.parse
import ssl
from sqlalchemy import create_engine, Integer
from os.path import exists

cwdPath = os.path.abspath(os.getcwd())
config_path = os.path.join(cwdPath, "config")
config_parser = configparser.ConfigParser()
config_parser.read(os.path.join(config_path, "database.ini"))


def connect_sql():
    host = config_parser.get("postgresql", "host")
    database = config_parser.get("postgresql", "database")
    username = config_parser.get("postgresql", "user")
    password = config_parser.get("postgresql", "password")
    port = config_parser.get("postgresql", "port")
    final_password = urllib.parse.quote_plus(password)
    driver_details = "postgresql+pg8000"
    connection_details = driver_details + "://"+username+":"+final_password+"@"+host+":"+port+"/"+database
    ssl_context = ssl.create_default_context()
    if host == "localhost":
        connection = create_engine(connection_details)
    else:
        connection = create_engine(connection_details, client_encoding='utf8', connect_args={"ssl_context": ssl_context})
    
    return connection


# DATASOURCE/SETTINGS PAGE SQL FUNCTIONS

def execute_insert_query(query, data_obj):
    engine = connect_sql()
    conn = engine.connect()
    conn.execute(query, data_obj)
    
    conn.autocommit = True
    conn.close()
    engine.dispose()
    return "Success"


def execute_get_query(query, data_obj):
    engine = connect_sql()
    conn = engine.connect()
    cursor = conn.execute(query, data_obj)
    records = cursor.fetchall()
    
    columns = []
    conn.autocommit = True
    conn.close()
    engine.dispose()
    ret = {}
    data = []

    for column in cursor.keys():
        columns.append(column)
  
    for row in records:
        temp = {}
        for i in range(len(columns)):
            temp[columns[i]] = str(row[i])
        data.append(temp)
    ret['data'] = data
    ret['message'] = "Success"
    return ret


def execute_update_query(query):
    engine = connect_sql()
    conn = engine.connect()
    conn.execute(query)
    conn.autocommit = True
    conn.close()
    engine.dispose()
    return "Success"


def execute_delete_query(query, data_obj):
    engine = connect_sql()
    conn = engine.connect()
    conn.execute(query, data_obj)
    conn.autocommit = True
    conn.close()
    engine.dispose()
    return "Success"


def execute_create_query(query):
    engine = connect_sql()
    conn = engine.connect()
    conn.execute(query)
    conn.autocommit = True
    conn.close()
    engine.dispose()
    return "Success"


def execute_delete_all_query(query):
    engine = connect_sql()
    conn = engine.connect()
    conn.execute(query)
    conn.autocommit = True
    conn.close()
    engine.dispose()
    return "Success"


def execute_many(query, data):
    engine = connect_sql()
    conn = engine.connect()
    conn.execute(query, data)
    conn.autocommit = True
    conn.close()
    engine.dispose()
    return "Success"

def execute_get_query_modellist(query, data_obj, modeltype):
    engine = connect_sql()
    conn = engine.connect()
    cursor = conn.execute(query, data_obj)
    records = cursor.fetchall()
    columns = []
    conn.autocommit = True
    conn.close()
    engine.dispose()
    for column in cursor.keys():
        columns.append(column)

    ret = {}
    data = []
    for row in records:
        temp = {}
        filename = ""
        for i in range(len(columns)):
            temp[columns[i]] = str(row[i])
            if modeltype == 'single':
                if columns[i] == ('train_file'):
                    temp['train_file_status'] = check_fileexists(SDV_Uploadpath,str(row[i]))                  
                    filename = str(row[i])
                         
                if columns[i] == ('sdv_model'):
                    temp['sdv_model_status'] = check_fileexists(SDV_Modelpath,str(row[i]))
                    temp['download_file_status'] = check_fileexists(SDV_DownloadPath, str(row[i]).replace(".pkl", "")+"_"+filename)
            elif modeltype == 'multi' :
                if columns[i] == ('meta_file'):
                    temp['meta_file_status'] = check_fileexists(SDV_Upload_Multipath,str(row[i]))
                    
                if columns[i] == ('sdv_model'):
                    temp['sdv_model_status'] = check_fileexists(SDV_Model_Multipath,str(row[i]))
                    temp['download_file_status'] = check_fileexists(SDV_Download_MultiPath,str(row[i]).replace(".pkl", ".zip"))
                
        data.append(temp)
    ret['data'] = data
    ret['message'] = "Success"
    return ret



def check_fileexists(rootpath,filename):
    file_exists = exists(os.path.join(rootpath,filename))
    return file_exists


def execute_insertmany_query(query, data_list):
    engine = connect_sql()
    conn = engine.connect()
    conn.execute(query, data_list)
  
    conn.autocommit = True
    conn.close()
    engine.dispose()
    return "Success"


def execute_insert_query_get_id(query, domain_object_obj):
    engine = connect_sql()
    conn = engine.connect()
    cursor = conn.execute(query, domain_object_obj)
    conn.autocommit = True
    result_id = cursor.fetchone()[0]
    conn.close()
    engine.dispose()
    return result_id


def execute_get_query_regexexecution(query, data_obj):
    engine = connect_sql()
    conn = engine.connect()
    cursor = conn.execute(query, data_obj)
    records = cursor.fetchall()
    columns = []
    conn.autocommit = True
    conn.close()
    engine.dispose()
    for column in cursor.keys():
        columns.append(column)

    ret = {}
    data = []
    for row in records:
        temp = {}
        for i in range(len(columns)):
            temp[columns[i]] = str(row[i])
            if columns[i] == ('filepath'):
                temp['uploadedfilestatus'] = check_fileexists(UDP_ValUploadPath,str(row[i]))
                temp['resultfilestatus'] = check_fileexists(UDP_ValResultPath,"".join(str(row[i]).split(".")[0:-1]) + ".csv")
                              
        data.append(temp)
    ret['data'] = data
    ret['message'] = "Success"
    return ret


def execute_sql_query(statement, params):
    engine = connect_sql()
    connection = engine.connect()
    cursor_result = connection.execute(statement,params)

    results = []
    try:
        result_mappings = cursor_result.mappings().all()
        results = [dict(row) for row in result_mappings]
    except:
        pass
    
    
    connection.autocommit = True
    connection.close()
    return results


def execute_query_to_get_result(query, data_obj):
    engine = connect_sql()
    conn = engine.connect()
    cursor = conn.execute(query, data_obj)
    records = cursor.fetchall()
    
    columns = []
    conn.autocommit = True
    conn.close()
    engine.dispose()
    ret = {}
    data = []

    for column in cursor.keys():
        columns.append(column)
  
    for row in records:
        temp = {}
        for i in range(len(columns)):
            temp[columns[i]] = str(row[i])
        data.append(temp)
    return data


def save_dataframe(df, table_name):
    engine = connect_sql()
    with engine.begin() as connection:
        df.to_sql(name=table_name, con=connection, if_exists='append', index=False, dtype={'execution_id': Integer})
    engine.dispose()
    return "Success"