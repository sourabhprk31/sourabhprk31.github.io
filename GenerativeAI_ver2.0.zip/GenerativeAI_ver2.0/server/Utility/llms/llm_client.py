import configparser
import os
from copy import deepcopy
from typing import AnyStr, Union

from botocore.config import Config as BotoConfig
from langchain.chat_models import AzureChatOpenAI, ChatOpenAI
from langchain.chat_models.base import BaseChatModel
from langchain.embeddings import OpenAIEmbeddings
from langchain.embeddings.base import Embeddings

from Utility.llms.sagemaker_endpoint import SagemakerEndpointLlamaChatModel

CWD = os.getcwd()
LLM_CONFIG_FILE = os.path.join(CWD, "config", "llm_config.ini")

config_parser = configparser.ConfigParser()
config_parser.read(LLM_CONFIG_FILE)

DEFAULT_EMBEDDING_MODEL = config_parser.get("DEFAULT_MODELS", "embedding_model")
DEFAULT_CHAT_MODEL = config_parser.get("DEFAULT_MODELS", "chat_model")


def chat_completion_client(llm_model: AnyStr = DEFAULT_CHAT_MODEL, **model_kwargs) -> BaseChatModel:

    config = deepcopy(config_parser[llm_model])
    service_type = config.pop("service_type", "")
    model_type = config.pop("model_type", "")
    llm_loader_class = config.pop("llm_loader_class", "")
    client_kwargs = config

    if model_type != "chat":
        raise ValueError(
            "Invalida model_type = {} for the chat_completion_client".format(model_type))

    # Extra kwargs
    temperature = model_kwargs.pop("temperature", 0.5)
    max_tokens = model_kwargs.pop("max_tokens", 300)
    max_retries = model_kwargs.pop("max_retries", 0)
    request_timeout = model_kwargs.pop("request_timeout", 120)

    # Load LLM client
    if service_type == "openai":
        llm_client = ChatOpenAI(
            temperature=temperature,
            max_tokens=max_tokens,
            max_retries=max_retries,
            request_timeout=request_timeout,
            **client_kwargs)

    elif service_type == "azure_openai":
        llm_client = AzureChatOpenAI(
            temperature=temperature,
            max_tokens=max_tokens,
            max_retries=max_retries,
            request_timeout=request_timeout,
            **client_kwargs)

    elif service_type == "sagemaker_endpoint_llama":
        llm_client = SagemakerEndpointLlamaChatModel(
            endpoint_name=client_kwargs.pop("endpoint_name"),
            client_kwargs=client_kwargs,
            model_kwargs={"temperature": temperature, "max_new_tokens": max_tokens})

    else:
        raise ValueError(
            "Invalida configuration, LLM client service_type = {} is not Implemented".format(service_type))

    return llm_client


def text_embedding_client(llm_model: AnyStr = DEFAULT_EMBEDDING_MODEL, **model_kwargs) -> Union[Embeddings, OpenAIEmbeddings]:

    config = deepcopy(config_parser[llm_model])
    service_type = config.pop("service_type", "")
    model_type = config.pop("model_type", "")
    llm_loader_class = config.pop("llm_loader_class", "")
    client_kwargs = config

    if model_type != "embedding":
        raise ValueError(
            "Invalida model_type = {} for the text_embedding_client".format(model_type))

    # Load Embedding client
    if service_type in ("openai", "azure_openai"):
        llm_client = OpenAIEmbeddings(**client_kwargs, **model_kwargs)

    else:
        raise ValueError(
            "Invalid configuration, Embedding client service_type = {} is not Implemented".format(service_type))

    return llm_client


####### FACTORY CLASS ############

class ChatCompletion:

    @classmethod
    def create(cls, *args, **kwargs) -> BaseChatModel:
        return chat_completion_client(*args, **kwargs)


class TextEmbedding:
    @classmethod
    def create(cls, *args, **kwargs) -> Embeddings:
        return text_embedding_client(*args, **kwargs)
