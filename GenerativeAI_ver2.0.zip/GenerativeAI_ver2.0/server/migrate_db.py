"""
=============================================================================
COPYRIGHT NOTICE
=============================================================================
© Copyright HCL Technologies Ltd. 2021, 2022, 2023
Proprietary and confidential. All information contained herein is, and
remains the property of HCL Technologies Limited. Copying or reproducing the
contents of this file, via any medium is strictly prohibited unless prior
written permission is obtained from HCL Technologies Limited.
"""

import sqlalchemy as sa

from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from configparser import ConfigParser
from urllib.parse import quote_plus

from Utility.postgres_conn import connect_sql

# config_parser = ConfigParser()
# config_parser.read("config/database.ini")

# host = config_parser.get("postgresql", "host")
# database = config_parser.get("postgresql", "database")
# username = config_parser.get("postgresql", "user")
# password = config_parser.get("postgresql", "password")
# port = config_parser.get("postgresql", "port")
# final_password = quote_plus(password)
# conn_protocol = "postgresql+pg8000"

# SQLALCHEMY_DATABASE_URL = f"{conn_protocol}://{username}:{final_password}@{host}:{port}/{database}"

# if(host == "locahost"):
#     engine = create_engine(SQLALCHEMY_DATABASE_URL)
# else:
#     engine = create_engine(SQLALCHEMY_DATABASE_URL, connect_args={"ssl_context": True})

engine = connect_sql()

Base = declarative_base()


class BlobStore(Base):
    __tablename__ = "blob_store"

    id = sa.Column(sa.Integer, primary_key=True)
    key = sa.Column(sa.String(255))
    blob = sa.Column(sa.LargeBinary)


Base.metadata.create_all(bind=engine)
