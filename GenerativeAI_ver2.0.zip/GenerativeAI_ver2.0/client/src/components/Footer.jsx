import React from "react";

export const Footer = (props) => {
  return (
    <footer className="footer">
      <div>
        <a target="_blank" rel="noopener noreferrer" href="https://hcl.com">
          2023 &copy; HCL Technologies Ltd.
        </a>
        <span> v0.1 </span>
      </div>
    </footer>
  );
};
