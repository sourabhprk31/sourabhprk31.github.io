import React from "react";
import { Menu } from "@progress/kendo-react-layout";
import "@progress/kendo-react-intl";
import "@progress/kendo-react-inputs";
import "@progress/kendo-react-tooltip";
import { useHistory } from "react-router-dom";
import Logo from "../assets/common_icons/logo.png";
import { Link } from "react-router-dom";

import {
  AppBar,
  AppBarSection,
  AppBarSpacer,
} from "@progress/kendo-react-layout";

import { get_menu_names_url } from "../commonUtility/api_urls";
import { httpget } from "../commonUtility/common_http";
import { Label } from "@progress/kendo-react-labels";

const menu_name = "Use cases";
const routepath = {
  "Use cases": "/usecasedetails",
};

export const Header = () => {
  const history = useHistory();

  const [menu, setmenu] = React.useState([]);
  React.useEffect(() => {
    const req_value = {
      params: {},
    };

    httpget(get_menu_names_url, req_value).then((result) => {
      console.log("Sub Menu :>>", result);
      const items = [
        {
          text: menu_name,
          items: result,
        },
      ];
      console.log("Final Menu :>>", items);
      setmenu(items);
    });
  }, [setmenu]);

  const onSelect = (event) => {
    console.log("Selected Menu :>>", event.item.text);
    if (event.item.text !== menu_name) {
      history.push(routepath[menu_name], {
        usecase_name: event.item.text,
      });
    }
  };

  const handleConfigBtn = () => {
    history.push("/llmconfiguration");
  };

  return (
    <React.Fragment>
      <AppBar className="header">
        <AppBarSection>
          <img
            src={Logo}
            alt="logo"
            style={{
              paddingLeft: "5px",
              paddingRight: "5px",
              width: "35px",
              height: "auto",
              marginLeft: "0px",
              marginTop: "1%",
            }}
          />
        </AppBarSection>
        <AppBarSection>
          <Link to="/" className="headertitlelink">
            <div>
              <Label className="headertitle zoom-link">Generative AI</Label>
            </div>
          </Link>
        </AppBarSection>
        <AppBarSection>
          <Menu items={menu} onSelect={onSelect}></Menu>
        </AppBarSection>
        <AppBarSpacer
          style={{
            width: "69%",
          }}
        />
        <AppBarSection>
          <span
            className="k-icon k-i-gear configbtn"
            onClick={handleConfigBtn}
          ></span>
        </AppBarSection>
      </AppBar>
    </React.Fragment>
  );
};
