import React from "react";
import { Button } from "@progress/kendo-react-buttons";
import { Tooltip as ReactTooltip } from "react-tooltip";

function IconButton(props) {
  return (
    <div>
      <Button
        id="iconbutton"
        className="icon_button"
        icon={props.icon}
        onClick={props.onClick}
        disabled={props.disabled ? props.disabled : false}
      ></Button>
      <ReactTooltip
        className="tooltip"
        anchorId="iconbutton"
        place="right"
        content={props.title}
      />
    </div>
  );
}

export default IconButton;
