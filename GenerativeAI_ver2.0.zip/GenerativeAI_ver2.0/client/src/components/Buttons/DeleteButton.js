import React from "react";
import { Button } from "@progress/kendo-react-buttons";
import { Tooltip as ReactTooltip } from "react-tooltip";

function DeleteButton(props) {
  return (
    <div>
      <Button
        id={props.id}
        className="deletebutton"
        icon={props.icon}
        onClick={props.onClick}
        disabled={props.disabled ? props.disabled : false}
      ></Button>
      <ReactTooltip
        className="tooltip"
        anchorId={props.id}
        place="bottom"
        content={props.title}
      />
    </div>
  );
}

export default DeleteButton;
