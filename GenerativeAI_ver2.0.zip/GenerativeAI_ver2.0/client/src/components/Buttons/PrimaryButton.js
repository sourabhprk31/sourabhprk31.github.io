import React from "react";
import { Button } from "@progress/kendo-react-buttons";
import { Tooltip as ReactTooltip } from "react-tooltip";

function PrimaryButton(props) {
  return (
    <div>
      <Button
        id={props.id}
        className="savebutton"
        icon={props.icon}
        onClick={props.onClick}
        disabled={props.disabled ? props.disabled : false}
      >
        {props.label}
      </Button>
      <ReactTooltip
        className="tooltip"
        anchorId={props.id}
        place="bottom"
        content={props.title}
      />
    </div>
  );
}

export default PrimaryButton;
