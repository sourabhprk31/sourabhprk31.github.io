import React from "react";
import { Loader } from "@progress/kendo-react-indicators";

function LazyLoader() {
  return (
    // <div className="content_center">
    //   <div style={{ padding: 200 }}>
    //     <div className="row">
    //       <p>Loading...</p>
    //     </div>
    //   </div>
    // </div>
    <div className="body_content">
      <div className="content_center card-container loaderheight">
        <div>
          <span className="loading">Loading</span>&nbsp;
          <Loader size="medium" type={"pulsing"} />
        </div>
      </div>
    </div>
  );
}
export default LazyLoader;
