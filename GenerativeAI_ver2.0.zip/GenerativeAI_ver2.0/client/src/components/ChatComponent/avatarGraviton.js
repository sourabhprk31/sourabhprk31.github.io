import * as React from "react";
import graviton_avatar from "../../assets/avatar/graviton.png";

const AvatarGraviton = () => {
  return (
    <img
      className="graviton_avatar"
      src={graviton_avatar}
      alt="graviton"
      title="Graviton"
    />
  );
};

export default AvatarGraviton;
