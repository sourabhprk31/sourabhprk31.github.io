import React from "react";
import AvatarGraviton from "./avatarGraviton";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";


const GravitonMessageBox = (props) => {
  return (
    <div
      className="graviton_message_div"
      id={props.message_id}
      onClick={props.onClick}
    >
      <AvatarGraviton />
      <div className="graviton_message_box">
        <ReactMarkdown remarkPlugins={[remarkGfm]}>{`${props.msg}`}</ReactMarkdown>
      </div>
    </div>
  );
};
export default GravitonMessageBox;
