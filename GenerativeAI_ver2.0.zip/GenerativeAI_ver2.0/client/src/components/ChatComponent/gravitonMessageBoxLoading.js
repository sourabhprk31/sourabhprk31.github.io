import React from "react";
import AvatarGraviton from "./avatarGraviton";

const GravitonMessageBoxLoading = (props) => {
  return (
    <div
      className="graviton_message_div"
      id={props.message_id}
      onClick={props.onClick}
    >
      <AvatarGraviton />
      <div className="graviton_message_box">{props.msg}</div>
    </div>
  );
};
export default GravitonMessageBoxLoading;
