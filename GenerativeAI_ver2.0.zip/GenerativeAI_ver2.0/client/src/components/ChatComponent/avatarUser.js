import * as React from "react";
import user_avatar from "../../assets/avatar/user.png";

const AvatarUser = () => {
  return (
    <img
      className="user_avatar"
      src={user_avatar}
      alt="User"
      title="User Name"
    />
  );
};

export default AvatarUser;
