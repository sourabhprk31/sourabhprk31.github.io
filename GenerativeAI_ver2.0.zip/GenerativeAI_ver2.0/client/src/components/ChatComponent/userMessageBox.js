import * as React from "react";
import AvatarUser from "./avatarUser";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";

const UserMessageBox = (props) => {
  return (
    <div className="user_message_div" id={props.message_id}>
      <div className="user_message_box">
        <ReactMarkdown remarkPlugins={[remarkGfm]}>
          {`${props.msg}`}
        </ReactMarkdown>
      </div>
      <AvatarUser />
    </div>
  );
};
export default UserMessageBox;
