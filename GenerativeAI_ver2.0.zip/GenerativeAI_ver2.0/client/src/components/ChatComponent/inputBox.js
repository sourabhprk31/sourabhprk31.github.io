// import { IconButton, TextField, TextareaAutosize } from "@mui/material";
import * as React from "react";
// import SendIcon from "@mui/icons-material/Send";

const InputBox = (props) => {
  const [text, setText] = React.useState("");
  const handleSubmit = (e) => {
    e.preventDefault();
    props.onSubmit(text);
    setText("");
  };

  return (
    <form onSubmit={handleSubmit}>
      <div className="enter_message_input_div">
        <div className="input_box">
          <textarea
            placeholder="Type a new message"
            name="entered_msg"
            value={text}
            onChange={(e) => setText(e.target.value)}
            required
            rows={1}
            style={{
              width: "100%",
              height: 50,
              fontFamily: "sans-serif",
              maxHeight: 200,
            }}
          />
        </div>
        <div className="send_icon_div">
          <i className="fa-regular fa-hand-point-right primaryColor"></i>
          {/* <IconButton color="primary" type="submit" className="send_icon">
            <SendIcon />
          </IconButton> */}
        </div>
      </div>
    </form>
  );
};

export default InputBox;
