import React from "react";

const icons = {
  Draft: "k-icon k-i-track-changes-accept",
  "In-Progress": "k-icon k-i-loading",
  Completed: "k-icon k-i-check-circle",
};

const colors = {
  Draft: "primaryColor",
  "In-Progress": "orangeColor",
  Completed: "greenColor",
};

function StatusField(props) {
  const status_value = props.item;
  return (
    <div className={colors[status_value]}>
      {status_value}&nbsp;
      <span class={icons[status_value]}></span>
    </div>
  );
}
export default StatusField;
