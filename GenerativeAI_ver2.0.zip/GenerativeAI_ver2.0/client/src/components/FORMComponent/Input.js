import * as React from "react";
import { Input } from "@progress/kendo-react-inputs";
import { Tooltip as ReactTooltip } from "react-tooltip";

function CustomInput(props) {
  return (
    <div>
      <Input
        id="input"
        className="borderall"
        value={props.value}
        onChange={props.onChange}
        placeholder={props.placeholder}
        autoComplete={props.autoComplete}
        maxLength={props.maxLength}
        onKeyDown={props.onKeyDown}
      />
      <ReactTooltip
        className="tooltip"
        anchorId="input"
        place="bottom"
        content={props.title}
      />
    </div>
  );
}
export default CustomInput;
