import { Label } from "@progress/kendo-react-labels";

function InputLabel(props) {
  return <Label className="inputlabel">{props.label}</Label>;
}
export default InputLabel;
