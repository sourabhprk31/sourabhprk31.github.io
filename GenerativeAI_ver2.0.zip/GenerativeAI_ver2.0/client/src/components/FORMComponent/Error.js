import { Error } from "@progress/kendo-react-labels";

function CustomError(props) {
  return <Error className="error">{props.msg}</Error>;
}
export default CustomError;
