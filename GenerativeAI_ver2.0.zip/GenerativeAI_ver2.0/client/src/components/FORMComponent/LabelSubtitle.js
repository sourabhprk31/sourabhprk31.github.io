import { Label } from "@progress/kendo-react-labels";

function LabelSubtitle(props) {
  return <Label className="subtitle_label">{props.label}</Label>;
}
export default LabelSubtitle;
