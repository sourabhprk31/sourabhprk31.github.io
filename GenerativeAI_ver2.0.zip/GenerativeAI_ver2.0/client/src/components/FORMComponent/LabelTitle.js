import { Label } from "@progress/kendo-react-labels";

function LabelTitle(props) {
  return <Label className="title_label">{props.label}</Label>;
}
export default LabelTitle;
