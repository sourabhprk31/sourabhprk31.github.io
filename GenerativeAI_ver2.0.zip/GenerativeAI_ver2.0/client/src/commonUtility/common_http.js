import Axios from "axios";
// import { loadProgressBar } from "axios-progress-bar";

const HOST_URL = "http://localhost:8001/";
export const API_URL = HOST_URL;
// function get_host_url() {
//   let api_url = window.location.protocol + "//" + window.location.host + "/";
//   return api_url;
// }
// const HOST_URL = get_host_url();
// export const API_URL = HOST_URL;

const headers = { headers: {} };
// localhost:8000/usecase/run_usecase
export function httpget(GET_URL, req_value) {
  // loadProgressBar();
  console.log(GET_URL);
  return new Promise((resolve) => {
    Axios.get(HOST_URL + GET_URL, req_value, headers)
      .then((response) => {
        if (response.data !== "Failure") {
          resolve(response.data);
        }
      })
      .catch((Servers) => {
        console.log(Servers);
      });
  });
}

export function httppost(POST_URL, req_value) {
  // loadProgressBar();
  return new Promise((resolve) => {
    Axios.post(HOST_URL + POST_URL, req_value, headers)
      .then((response) => {
        resolve(response);
      })
      .catch((Servers) => {
        console.log(Servers);
        window.location = "/internal_server_error";
      });
  });
}

export function httpput(PUT_URL, req_value) {
  // loadProgressBar();
  return new Promise((resolve) => {
    Axios.put(HOST_URL + PUT_URL, req_value, headers)
      .then((response) => {
        resolve(response);
      })
      .catch((Servers) => {
        console.log(Servers);
        window.location = "/internal_server_error";
      });
  });
}

export function httpdelete(DELETE_URL, req_value) {
  // loadProgressBar();
  return new Promise((resolve) => {
    Axios.delete(HOST_URL + DELETE_URL, req_value, headers)
      .then((response) => {
        resolve(response);
      })
      .catch((Servers) => {
        console.log(Servers);
        window.location = "/internal_server_error";
      });
  });
}

export function httpgetfile(GET_URL, req_value) {
  // loadProgressBar();
  return new Promise((resolve) => {
    Axios.get(HOST_URL + GET_URL, req_value, headers, {
      responseType: "blob",
    })
      .then((response) => {
        if (response.data !== "Failure") {
          resolve(response.data);
        }
      })
      .catch((Servers) => {
        console.log(Servers);
      });
  });
}

export function httpgetzipfile(GET_URL, usecase_name) {
  // loadProgressBar();
  return new Promise((resolve) => {
    Axios({
      url: HOST_URL + GET_URL + "?usecase_name=" + usecase_name,
      responseType: "blob",
      method: "GET",
    })
      .then((response) => {
        if (response.data !== "Failure") {
          resolve(response.data);
        }
      })
      .catch((Servers) => {
        console.log(Servers);
      });
  });
}
