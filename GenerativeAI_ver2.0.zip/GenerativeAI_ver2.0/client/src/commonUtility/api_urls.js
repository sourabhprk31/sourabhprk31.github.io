// Menu
export const get_menu_names_url = "usecase/get_menu_names";

// UseCase
export const get_ui_controls_url = "usecase/get_ui_controls";
export const run_usecase_url = "usecase/run_usecase";

// Use case Execution Preview
export const get_execution_preview_data = "usecase/get_execution_preview_data";
export const get_execution_info_data = "usecase/get_execution_info_data";
export const delete_execution_info = "usecase/delete_execution_info";
