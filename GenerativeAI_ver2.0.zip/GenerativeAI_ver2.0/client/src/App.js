import React, { Suspense } from "react";

import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import "./custom_theme.scss";
import "./App.scss";
import LazyLoader from "./components/LazyLoader";
// Header & Footer
import { Header } from "./components/Header";
import { Footer } from "./components/Footer.jsx";
import AppContext from "./AppContext";

// Error Pages like 404 , 500
const PageNotFound = React.lazy(() => import("./error_pages/404_Page"));
const InternalServerError = React.lazy(() => import("./error_pages/500_Page"));
const UnAuthorizedAccess = React.lazy(() => import("./error_pages/401_Page"));

// Main Page
const Welcome = React.lazy(() => import("./pages/Welcome"));
const UsecaseDetails = React.lazy(() =>
  import("./pages/usecases/UsecaseDetails")
);
const UploadData = React.lazy(() => import("./pages/usecases/UploadData"));
const UseCases = React.lazy(() => import("./pages/usecases/UseCases"));
const ExecutionPreview = React.lazy(() =>
  import("./pages/usecases/ExecutionPreview")
);

const Configuration = React.lazy(() =>
  import("./pages/configuration/Configuration")
);

const ChatWindow = React.lazy(() =>
  import("./pages/conversational_ai/ChatWindow")
);
// const InProgress = React.lazy(() => import("./pages/In-Progress"));

const App = () => {
  const hash = window.location.hash;
  const [appType, setAppType] = React.useState(hash === "#ise" ? "ISE" : "");

  return (
    <div className="App">
      <AppContext.Provider value={{ appType, setAppType }}>
        <Router>
          <Suspense fallback={<LazyLoader />}>
            {hash === "#ise" ? <div /> : <Header />}
            <Switch>
              <Route exact path="/" render={() => <Welcome />} />
              <Route
                exact
                path="/usecasedetails"
                render={() => <UsecaseDetails />}
              />
              <Route exact path="/uploaddata" render={() => <UploadData />} />
              <Route exact path="/usecases" render={() => <UseCases />} />
              <Route
                exact
                path="/llmconfiguration"
                render={() => <Configuration />}
              />
              <Route
                exact
                path="/executionpreview"
                render={() => <ExecutionPreview />}
              />
              <Route exact path="/chat" render={() => <ChatWindow />} />
              <Route
                exact
                path="/internal_server_error"
                component={InternalServerError}
              />
              <Route
                exact
                path="/unauthorizedAccess"
                component={UnAuthorizedAccess}
              />

              <Route component={PageNotFound} />
            </Switch>
            {hash === "#ise" ? <div /> : <Footer />}
          </Suspense>
        </Router>
      </AppContext.Provider>
    </div>
  );
};

export default App;
