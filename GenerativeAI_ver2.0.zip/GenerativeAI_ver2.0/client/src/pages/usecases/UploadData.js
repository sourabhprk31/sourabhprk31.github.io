import * as React from "react";
import AppContext from "../../AppContext";
import { useHistory, useLocation } from "react-router-dom";
import { DropDownList } from "@progress/kendo-react-dropdowns";

import { PrimaryButton } from "../../components/Buttons/buttons";
import { LabelTitle } from "../../components/FORMComponent/index";
import { InputLabel } from "../../components/FORMComponent/index";

import DirectoryPreview from "./DirectoryPreview";

const UploadData = (props) => {
  const { appType } = React.useContext(AppContext);
  const history = useHistory();
  const location = useLocation();

  const usecase_name = location.state.usecase_name;

  // ----------------------------------- UPLOADED FUNC -----------------------------------

  function formatBytes(bytes, decimals = 2) {
    if (!+bytes) return "0 Bytes";
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ["Bytes", "KB", "MB", "GB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return `${parseFloat((bytes / Math.pow(k, i)).toFixed(dm))} ${sizes[i]}`;
  }

  function getFolderPath(content) {
    const lastIndex = content.lastIndexOf("/");
    if (lastIndex !== -1) {
      const part1 = content.slice(0, lastIndex);
      return part1;
    }
  }

  const [uploaded_files, setuploaded_files] = React.useState([]);
  const [filtered_files, setfiltered_files] = React.useState([]);
  const [extensionlist, setextensionlist] = React.useState([]);
  const handleUpload = (event) => {
    console.log("Uploaded Folder Details :>>", event.target.files);
    setuploaded_files([]);
    event.preventDefault();
    const files = event.target.files;
    const file_list = [];
    const fileext_list = [];
    fileext_list.push("All");
    for (let i = 0; i < files.length; i++) {
      const ext_value = files[i].name.split(".")[1];
      console.log(ext_value);
      file_list.push(files[i]);
      if (!fileext_list.includes(ext_value)) {
        fileext_list.push(ext_value);
      }
    }
    generate_file_display(files);
    setextensionlist(fileext_list);
    setuploaded_files(file_list);
    setfiltered_files(file_list);
  };

  const [files_info, setfiles_info] = React.useState([]);
  const [totalsize, settotalsize] = React.useState();
  const generate_file_display = (files) => {
    setfiles_info([]);
    const fileinfo_arr = [];
    let id = 0;
    let allfilesize = 0;
    for (let i = 0; i < files.length; i++) {
      allfilesize += files[i]["size"];
      id = id + 1;
      const file_details = {};
      file_details["id"] = id;
      file_details["name"] = files[i]["name"];
      file_details["size"] = formatBytes(files[i]["size"]);
      file_details["path"] = getFolderPath(files[i]["webkitRelativePath"]);
      fileinfo_arr.push(file_details);
    }
    settotalsize(formatBytes(allfilesize));
    setfiles_info(fileinfo_arr);
  };
  // ----------------------------------- NEXT BUTTON -----------------------------------
  const handleNext = () => {
    history.push("/usecases", {
      usecase_name: usecase_name,
      uploaded_files: filtered_files,
    });
  };

  const handleDropChange = (event) => {
    console.log("Selected File Type :>>", event.target.value);
    if (event.target.value === "All") {
      generate_file_display(uploaded_files);
      setfiltered_files(uploaded_files);
    } else {
      const filteredFiles = uploaded_files.filter(
        (file) => file.name.split(".")[1] === event.target.value
      );
      generate_file_display(filteredFiles);
      setfiltered_files(filteredFiles);
    }
  };

  console.log(extensionlist);
  const handleBack = () => {
    if (appType === "ISE") {
      history.push("/usecasedetails?usecase_name=" + usecase_name + "#ise");
    } else {
      history.push("/usecasedetails", {
        usecase_name: usecase_name,
      });
    }
  };

  return (
    <div className={appType === "ISE" ? "" : "body_content"}>
      <div className="row">
        <div className="cardlefttitle">
          <div className="row">
            <span className="backbtnalign">
              <PrimaryButton
                icon={"arrow-left"}
                onClick={handleBack}
                id={"back"}
                title={"Back"}
              />
            </span>
            &nbsp;
            <LabelTitle label={usecase_name} />
          </div>
        </div>
        <div className="cardrighttitle">
          {/* <LabelTitle label={"Details"} /> */}
        </div>
      </div>

      <div className="cardleftview">
        <InputLabel label={"Upload Data:"}></InputLabel>
        <div className="inputspace"></div>
        <div>
          <div className="upload_div borderall">
            <label htmlFor="folderUpload" className="upload_button">
              Select Folder
            </label>
            <input
              className="upload_input"
              id="folderUpload"
              type={"file"}
              webkitdirectory=""
              mozdirectory=""
              onChange={handleUpload}
            ></input>
            <label htmlFor="folderUpload" className="upload_msg">
              {uploaded_files.length === 0
                ? "No Folder Selected"
                : "Uploaded folder contains " +
                  uploaded_files.length +
                  " files"}
            </label>
          </div>

          <div className="emptyrow"></div>
          {uploaded_files.length > 0 && (
            <div>
              <InputLabel label={"Select File Type:"}></InputLabel>
              <div className="inputspace"></div>
              <DropDownList
                className="lightbordercolor input_font"
                data={extensionlist}
                defaultValue="All"
                onChange={handleDropChange}
              />
            </div>
          )}
          <div className="emptyrow"></div>
          <div className="floatright">
            <PrimaryButton
              icon={"arrow-right"}
              label={"Next"}
              onClick={handleNext}
            />
          </div>
        </div>
        {files_info.length > 0 && (
          <DirectoryPreview uploaded_files={files_info} totalsize={totalsize} />
        )}
        <div className="emptyrow"></div>
      </div>
      <div className="cardrightview">{/* <DirectoryPreview /> */}</div>
    </div>
  );
};

export default UploadData;
