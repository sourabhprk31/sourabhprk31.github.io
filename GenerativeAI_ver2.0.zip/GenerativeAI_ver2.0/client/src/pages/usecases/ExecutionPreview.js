import React, { useRef, useState } from "react";
import AppContext from "../../AppContext";
import { useHistory, useLocation } from "react-router-dom";

import { PrimaryButton } from "../../components/Buttons/buttons";
import { LabelTitle } from "../../components/FORMComponent/index";
import { get_execution_preview_data } from "../../commonUtility/api_urls";
import { httpget } from "../../commonUtility/common_http";
import ReactMarkdown from "react-markdown";
import { PDFExport } from "@progress/kendo-react-pdf";
import remarkGfm from "remark-gfm";
import Loading from "./Loading";

const ExecutionPreview = (props) => {
  const { appType } = React.useContext(AppContext);
  const history = useHistory();
  const location = useLocation();
  const contentRef = useRef(null);

  const usecase_name = location.state.usecase_name;
  const execution_id = location.state.execution_id;
  const [execution_preview_data, set_execution_preview_data] = React.useState(
    []
  );
  const [grouped_execution_detail, setGroupedExecDetail] = useState([]);
  const pdfExportComponent = useRef(null);
  // let handleDownloadReport = () => {
  // const doc = new jsPDF("p", "pt", "a4");
  // // const doc = new jsPDF('l', 'mm', "a4");
  // const content = contentRef.current;
  // doc.html(content, {
  //   callback: function (pdf) {
  //     doc.save("test.pdf");
  //   }
  //   // margin: [35, 0, 35, 0],
  //   // html2canvas: {
  //   //   scale: "2%", //this was my solution, you have to adjust to your size
  //   //   width: 1000, //for some reason width does nothing
  //   // },
  // });

  // };

  React.useEffect(() => {
    const req_value = {
      params: {
        execution_id: execution_id,
      },
    };

    httpget(get_execution_preview_data, req_value).then((result) => {
      set_execution_preview_data(result);
      if (result.execution_detail.length > 0) {
        const grouped_details = result.execution_detail.reduce(
          (acc, detail) => {
            const title = detail.title;
            if (!acc[title]) {
              acc[title] = [];
            }
            acc[title].push(detail);
            return acc;
          },
          {}
        );
        console.log(grouped_details);
        setGroupedExecDetail(grouped_details);
      }
    });
  }, [set_execution_preview_data, usecase_name]);

  const handleBack = () => {
    if (appType === "ISE") {
      history.push("/usecasedetails?usecase_name=" + usecase_name + "#ise");
    } else {
      history.push("/usecasedetails", {
        usecase_name: usecase_name,
      });
    }
  };

  return (
    <div className={appType === "ISE" ? "" : "body_content"}>
      <div className="row">
        <span className="backbtnalign">
          <PrimaryButton
            icon={"arrow-left"}
            onClick={handleBack}
            id={"back"}
            title={"Back"}
          />
        </span>
        &nbsp;
        <div className="rep_hd_align" style={{ width: "80%" }}>
          <LabelTitle label={usecase_name} />
        </div>
        <div className="floatright rep_hd_align">
          <PrimaryButton
            icon={"download"}
            label={"Download Report"}
            disabled={execution_preview_data.length === 0}
            // onClick={handleDownloadReport}
            onClick={() => {
              pdfExportComponent.current.save();
            }}
          />
        </div>
      </div>

      <hr></hr>
      {execution_preview_data.length === 0 ? (
        <Loading timer_display={false} msg={"Report Loading"} />
      ) : (
        <PDFExport
          ref={pdfExportComponent}
          fileName={
            execution_preview_data.length === 0
              ? ""
              : execution_preview_data?.execution_info[0]?.job_name
          }
        >
          <div
            className="content_center card-container detail_report"
            ref={contentRef}
          >
            <div className="row detail_report_container">
              <div className="detail_report_title">
                <LabelTitle
                  label={
                    execution_preview_data.length === 0
                      ? ""
                      : "Detailed Report for " +
                        execution_preview_data?.execution_info[0]?.usecase_name
                  }
                />
              </div>
              <div className="report_type">
                {execution_preview_data.length === 0
                  ? ""
                  : "Additional Requirement Entered for " +
                    execution_preview_data?.execution_info[0]?.usecase_name}
              </div>
              <div className="report_detail">
                <div>
                  {/* <ReactMarkdown>
                    {execution_preview_data.length === 0
                      ? ""
                      : execution_preview_data?.execution_info[0]?.input_prompt}
                  </ReactMarkdown> */}
                  <p
                    dangerouslySetInnerHTML={{
                      __html:
                        execution_preview_data?.execution_info[0]?.input_prompt,
                    }}
                  >
                    {/* {execution_preview_data.length === 0
                      ? ""
                      : execution_preview_data?.execution_info[0]?.input_prompt} */}
                  </p>
                </div>
              </div>
              <div className="report_type">Summary</div>
              <div className="row detail_report_summary">
                {execution_preview_data.length === 0
                  ? ""
                  : execution_preview_data?.execution_summary?.map(
                      (summary_data, i) => {
                        return (
                          summary_data.value !== "0" &&
                          summary_data.value !== "0.0" &&
                          summary_data.value !== "0.0000" && (
                            <div className="col-md-6">
                              <h3>{summary_data.key}&nbsp;:</h3>
                              <p>{summary_data.value}</p>
                            </div>
                          )
                        );
                      }
                    )}
              </div>
              <div className="report_type">Detailed Report</div>
              <div className="report_detail">
                {execution_preview_data.length === 0
                  ? ""
                  : execution_preview_data?.execution_detail?.map(
                      (detail_data, index) => {
                        if (
                          detail_data.result == null ||
                          detail_data.result === "" ||
                          detail_data.result === "None"
                        ) {
                          return (
                            <div
                              style={{ textAlign: "center", fontSize: "20px" }}
                            >
                              <h3>{detail_data.title}</h3>
                            </div>
                          );
                        }
                        return (
                          <div className="rpt_css">
                            <h3>{detail_data.title}</h3>
                            <hr />
                            <ReactMarkdown
                              className="md_table md_image"
                              remarkPlugins={[remarkGfm]}
                            >
                              {detail_data.result}
                            </ReactMarkdown>
                            <div className="emptyrow"></div>
                            {/* <div style={{ whiteSpace: "pre-line" }}>
                        {" "}
                        {detail_data.result}{" "}
                      </div> */}
                          </div>
                        );
                      }
                    )}
              </div>
            </div>
          </div>
        </PDFExport>
      )}
    </div>
  );
};

export default ExecutionPreview;
