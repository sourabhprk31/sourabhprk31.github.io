import * as React from "react";
import { useHistory, useLocation } from "react-router-dom";
import AppContext from "../../AppContext";

import { DeleteButton, PrimaryButton } from "../../components/Buttons/buttons";
import { LabelTitle } from "../../components/FORMComponent/index";
import { httpget, httppost } from "../../commonUtility/common_http";
import {
  get_execution_info_data,
  delete_execution_info,
} from "../../commonUtility/api_urls";
import { Grid, GridColumn as Column } from "@progress/kendo-react-grid";
import swal from "sweetalert";

const initialDataState = {
  skip: 0,
  take: 10,
};

const ActionCommand = (props) => {
  console.log(props);
  return (
    <td style={{ display: "flex" }}>
      <PrimaryButton
        id={"view" + props.dataItem.serial_no}
        icon={"eye"}
        title={"View Report"}
        onClick={() => props.viewReport(props.dataItem)}
      />
      &nbsp; &nbsp;
      <DeleteButton
        id={"delete" + props.dataItem.serial_no}
        icon={"delete"}
        title={"Delete Execution"}
        onClick={() => props.deleteExecution(props.dataItem)}
      />
      &nbsp; &nbsp;
      {props.dataItem.usecase_type === "Chat" && (
        <PrimaryButton
          id={"chat" + props.dataItem.serial_no}
          icon={"comment"}
          title={"Open Chat Window"}
          onClick={() => props.viewReport(props.dataItem)}
          disabled={true}
        />
      )}
    </td>
  );
};

const UsecaseDetails = (props) => {
  const { appType } = React.useContext(AppContext);
  const history = useHistory();
  const location = useLocation();

  const queryString = window.location.search;
  const urlParams = new URLSearchParams(queryString);
  const usecase_name =
    appType === "ISE"
      ? urlParams.get("usecase_name").replaceAll("_", " ")
      : location.state.usecase_name;
  const [execution_info_data, set_execution_info_data] = React.useState([]);

  // Adding the New Job
  const handleNew = () => {
    history.push("/uploaddata", {
      usecase_name: usecase_name,
    });
  };

  // view the execution report
  const viewReport = (item) => {
    history.push("/executionpreview", {
      usecase_name: item.usecase_name,
      job_name: item.job_name,
      execution_id: item.execution_id,
    });
  };

  // Delete the job
  const deleteExecution = (item) => {
    swal({
      title: "Are you sure?",
      icon: "warning",
      buttons: {
        cancel: "No",
        confirm: {
          text: "Yes",
          value: true,
          visible: true,
          className: "",
          closeModal: true,
        },
      },
      dangerMode: true,
    }).then((willDelete) => {
      if (willDelete) {
        const req_value = {
          params: {
            execution_id: item.execution_id,
          },
        };
        httppost(delete_execution_info, req_value).then((result) => {
          if (result.data === "Success") {
            swal({
              title: "Deleted!",
              text: "Execution data has been deleted.",
              icon: "success",
              timer: 2000,
              buttons: false,
            });
            get_execution_info();
          } else {
            swal("Execution data has not been deleted!", {
              icon: "error",
            });
          }
        });
      }
    });
  };

  const ActionCommandCell = (props) => (
    <ActionCommand
      {...props}
      viewReport={viewReport}
      deleteExecution={deleteExecution}
    />
  );

  // Get the execution info from database
  let get_execution_info = () => {
    const req_value = {
      params: {
        usecase_name: usecase_name,
      },
    };
    httpget(get_execution_info_data, req_value).then((result) => {
      console.log("Execution Info Data :>>", result);
      set_execution_info_data(result);
    });
  };

  React.useEffect(() => {
    get_execution_info();
  }, [set_execution_info_data, usecase_name]);

  const [page, setPage] = React.useState(initialDataState);
  const [pageSizeValue, setPageSizeValue] = React.useState();
  const pageChange = (event) => {
    const targetEvent = event.targetEvent;
    const take = targetEvent.value === "All" ? 77 : event.page.take;
    if (targetEvent.value) {
      setPageSizeValue(targetEvent.value);
    }
    setPage({
      ...event.page,
      take,
    });
  };

  return (
    <div className={appType === "ISE" ? "" : "body_content"}>
      <LabelTitle label={usecase_name} />
      <div className="floatright" style={{ marginRight: "1%" }}>
        <PrimaryButton
          icon={"plus-circle"}
          label={"New Job"}
          onClick={handleNew}
        />
      </div>
      <div className="content_center card-container">
        <Grid
          style={{
            height: "80vh",
          }}
          // data={execution_info_data}
          data={execution_info_data.slice(page.skip, page.take + page.skip)}
          skip={page.skip}
          take={page.take}
          total={execution_info_data.length}
          pageable={{
            buttonCount: 5,
            pageSizes: [5, 10, 20, 50, "All"],
            pageSizeValue: pageSizeValue,
          }}
          onPageChange={pageChange}
        >
          <Column field="job_name" title="Job Name" />
          <Column field="exec_starttime" title="Job Execution Start Time" />
          <Column field="exec_endtime" title="Job Execution End Time" />
          <Column field="input_files_count" title="Number of Input Files" />
          <Column field="Action" cell={ActionCommandCell} />
        </Grid>
        <div className="emptyrow"></div>
      </div>
    </div>
  );
};

export default UsecaseDetails;
