import * as React from "react";
import { Loader } from "@progress/kendo-react-indicators";

const Loading = (props) => {
  const timer_display = props.timer_display;
  const msg = props.msg;

  const [elapsedTime, setElapsedTime] = React.useState(0);

  React.useEffect(() => {
    const interval = setInterval(() => {
      setElapsedTime((prevElapsedTime) => prevElapsedTime + 1000);
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const formatTime = (time) => {
    const hours = Math.floor(time / 3600000);
    const minutes = Math.floor((time % 3600000) / 60000);
    const seconds = Math.floor((time % 60000) / 1000);
    return `${hours.toString().padStart(2, "0")}:${minutes
      .toString()
      .padStart(2, "0")}:${seconds.toString().padStart(2, "0")}`;
  };

  return (
    <div className="body_content">
      <div className="content_center card-container loaderheight">
        {timer_display === true ? (
          <div>
            <div className="row">
              <span className="k-icon k-i-clock primaryColor timerloader"></span>
            </div>
            <div className="row">
              <div className="primaryColor">{formatTime(elapsedTime)}</div>
            </div>
          </div>
        ) : (
          <div></div>
        )}
        <div>
          <span className="loading">{msg}</span>&nbsp;
          <Loader size="medium" type={"pulsing"} />
        </div>
        <br></br>
      </div>
    </div>
  );
};

export default Loading;
