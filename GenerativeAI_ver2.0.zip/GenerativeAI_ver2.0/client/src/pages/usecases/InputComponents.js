import React from "react";

import { InputLabel } from "../../components/FORMComponent/index";

import { Field } from "@progress/kendo-react-form";
import { RadioGroup, TextArea } from "@progress/kendo-react-inputs";
import { DropDownList } from "@progress/kendo-react-dropdowns";

const InputComponents = (props) => {
  const input_details = props.input_details;

  const handleFieldChange = (name, value) => {
    props.handlechange(name, value);
  };

  const createFormFields = () => {
    return input_details.map((field) => {
      if (field.visibility === "True") {
        switch (field.input_control) {
          case "text_area":
            return (
              <div key={field.input_id}>
                <InputLabel label={field.input_label}></InputLabel>
                <div className="inputspace"></div>
                <Field
                  key={field.input_id}
                  name={field.input_id}
                  component={TextArea}
                  rows={4}
                  autoSize={true}
                  className="bordercolor input_font"
                  onChange={(e) =>
                    handleFieldChange(field.input_id, e.target.value)
                  }
                />
                <div className="inputspace"></div>
              </div>
            );
          case "radio":
            return (
              <div key={field.input_id}>
                <InputLabel label={field.input_label}></InputLabel>
                <div className="inputspace"></div>
                <Field
                  className="input_font"
                  name={field.input_id}
                  component={RadioGroup}
                  data={field.input_data.map((value) => {
                    return { label: value, value: value };
                  })}
                  layout="horizontal"
                  onChange={(e) =>
                    handleFieldChange(field.input_id, e.target.value)
                  }
                />
                <div className="inputspace"></div>
              </div>
            );

          case "dropdown":
            return (
              <div key={field.input_id}>
                <InputLabel label={field.input_label}></InputLabel>
                <div className="inputspace"></div>
                <Field
                  className="bordercolor input_font"
                  name={field.input_id}
                  component={DropDownList}
                  data={field.input_data}
                  onChange={(e) =>
                    handleFieldChange(field.input_id, e.target.value)
                  }
                />
                <div className="inputspace"></div>
              </div>
            );
          default:
            return null;
        }
      }
    });
  };

  const [fields, setFields] = React.useState();
  React.useEffect(() => {
    setFields(createFormFields());
  }, []);

  return <div>{fields}</div>;
};
export default InputComponents;
