import * as React from "react";

import { Grid, GridColumn as Column } from "@progress/kendo-react-grid";

import { LabelSubtitle } from "../../components/FORMComponent/index";

const columns = [
  {
    field: "id",
    title: "S.No",
    minWidth: 60,
  },
  {
    field: "path",
    title: "Directory Name",
    minWidth: "auto",
  },
  {
    field: "name",
    title: "File Name",
    minWidth: "auto",
  },
  {
    field: "size",
    title: "Size",
    minWidth: 100,
  },
];

const DirectoryPreview = (props) => {
  const uploaded_files = props.uploaded_files;
  const totalsize = props.totalsize;
  const label = "Uploaded Files: " + uploaded_files.length;
  const total_size = "Total Size:" + totalsize;

  return (
    <div>
      <div className="emptyrow"></div>
      <LabelSubtitle label={label} />
      <div className="floatright">
        <LabelSubtitle label={total_size} />
      </div>

      <div className="emptyrow"></div>
      <div>
        <Grid data={uploaded_files}>
          {columns.map((column) => {
            return (
              <Column
                field={column.field}
                title={column.title}
                width={column.minWidth}
              />
            );
          })}
        </Grid>
      </div>
    </div>
  );
};

export default DirectoryPreview;
