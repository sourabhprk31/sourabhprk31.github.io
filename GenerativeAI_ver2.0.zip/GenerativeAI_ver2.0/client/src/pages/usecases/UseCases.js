import * as React from "react";
import AppContext from "../../AppContext";
import { useHistory, useLocation } from "react-router-dom";

import { PrimaryButton } from "../../components/Buttons/buttons";
import { LabelTitle } from "../../components/FORMComponent/index";

import { Label } from "@progress/kendo-react-labels";
import { Form } from "@progress/kendo-react-form";
import {
  ExpansionPanel,
  ExpansionPanelContent,
} from "@progress/kendo-react-layout";
import { Reveal } from "@progress/kendo-react-animation";

import {
  get_ui_controls_url,
  run_usecase_url,
} from "../../commonUtility/api_urls";
import { httpget, httppost } from "../../commonUtility/common_http";
import Loading from "./Loading";
import InputComponents from "./InputComponents";

const UseCases = (props) => {
  const { appType } = React.useContext(AppContext);
  const history = useHistory();
  const location = useLocation();

  const usecase_name = location.state.usecase_name;
  const uploaded_files = location.state.uploaded_files;

  // ----------------------------------- UI CONTROLS -----------------------------------
  const [ui_controls, setui_controls] = React.useState([]);
  const [usecase_info, setusecase_info] = React.useState([]);
  const [formValues, setFormValues] = React.useState();
  React.useEffect(() => {
    const req_value = {
      params: {
        usecase_name: usecase_name,
      },
    };

    httpget(get_ui_controls_url, req_value).then((result) => {
      console.log("UI Control Details :>>", result);
      setFormValues(result["defaultValue"]);
      setui_controls(result);
      setusecase_info(JSON.parse(result["usecase_info"]));
    });
  }, [setui_controls, usecase_name]);

  const handlechange = (name, value) => {
    setFormValues((formValues) => ({ ...formValues, [name]: value }));
  };

  // ----------------------------------- RUN BUTTON -----------------------------------
  const [showloader, setshowloader] = React.useState(false);
  const [error_msg, seterror_msg] = React.useState("");
  const handleRunBtn = () => {
    handleSubmit(formValues);
  };

  const handleSubmit = (data) => {
    setshowloader(true);
    console.log("Form data:", data);

    const req_value = new FormData();
    for (let i = 0; i < uploaded_files.length; i++) {
      const file = uploaded_files[i];
      req_value.append("uploaded_files", file);
      req_value.append(
        `path_${file.name}_${file.size}`,
        file.webkitRelativePath
      );
    }
    req_value.append("usecase_name", usecase_name);
    req_value.append("form_data", JSON.stringify(data));
    req_value.append("input_files_count", uploaded_files.length);

    httppost(run_usecase_url, req_value).then((result) => {
      console.log(result["data"]);
      const result_final = result["data"];

      if (result_final["status"] === true) {
        history.push("/executionpreview", {
          usecase_name: usecase_name,
          job_name: result_final["job_name"],
          execution_id: result_final["execution_id"],
        });
      } else {
        setshowloader(false);
        seterror_msg(result_final["error_msg"]);
      }
    });
  };

  const [expanded, setExpanded] = React.useState(false);

  const handleBack = () => {
    if (appType === "ISE") {
      history.push("/usecasedetails?usecase_name=" + usecase_name + "#ise");
    } else {
      history.push("/usecasedetails", {
        usecase_name: usecase_name,
      });
    }
  };

  return (
    <div className={appType === "ISE" ? "" : "body_content"}>
      <div className="row">
        <div className="cardlefttitle ">
          <div className="row">
            <span className="backbtnalign">
              <PrimaryButton
                icon={"arrow-left"}
                onClick={handleBack}
                id={"back"}
                title={"Back"}
              />
            </span>
            &nbsp;
            <div style={{ width: "85%" }}>
              <LabelTitle label={usecase_name} />
            </div>
            <div className="floatright btnalign">
              <PrimaryButton
                icon={"gears"}
                label={"Run"}
                onClick={handleRunBtn}
                disabled={showloader}
              />
            </div>
          </div>
        </div>
        <div className="cardrighttitle">
          <LabelTitle label={"Details"} />
        </div>
      </div>
      <div className="row">
        <div className="cardleftview">
          {ui_controls.length === 0 ? (
            <Loading timer_display={false} msg={"UI Loading"} />
          ) : (
            <div>
              {showloader === true ? (
                <Loading timer_display={true} msg={"Running"} />
              ) : error_msg === "" ? (
                <Form
                  initialValues={ui_controls.defaultValue}
                  onSubmit={handleSubmit}
                  render={(formRenderProps) => (
                    <form onSubmit={formRenderProps.onSubmit}>
                      <InputComponents
                        input_details={ui_controls.input_details}
                        handlechange={handlechange}
                      />
                    </form>
                  )}
                />
              ) : (
                <ExpansionPanel
                  title={"Status: Failed"}
                  expanded={expanded}
                  tabIndex={0}
                  onAction={(event) => {
                    setExpanded(!expanded);
                  }}
                >
                  <Reveal>
                    {expanded === true && (
                      <ExpansionPanelContent>
                        <div className="content">{error_msg}</div>
                        <div className="emptyrow"></div>
                        <div className="emptyrow"></div>
                      </ExpansionPanelContent>
                    )}
                  </Reveal>
                </ExpansionPanel>
              )}
              <div style={{ height: "3%" }}></div>
            </div>
          )}
        </div>

        <div className="cardrightview">
          {usecase_info.map((info) => (
            <div className="details_content">
              <i className="fa-regular fa-hand-point-right primaryColor"></i>
              &nbsp;
              <Label className="multiline-label">{info}</Label>
              <br />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default UseCases;
