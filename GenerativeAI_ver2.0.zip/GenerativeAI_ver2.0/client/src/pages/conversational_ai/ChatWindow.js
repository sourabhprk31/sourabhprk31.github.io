import * as React from "react";
import GravitonMessageBox from "../../components/ChatComponent/gravitonMessageBox";
import GravitonMessageBoxLoading from "../../components/ChatComponent/gravitonMessageBoxLoading";
import InputBox from "../../components/ChatComponent/inputBox";
import UserMessageBox from "../../components/ChatComponent/userMessageBox";
// import { httpget } from "../../commonUtility/httpClient";
// import { get_response } from "../../commonUtility/apiUrls";

const Chat = () => {
  const bottomRef = React.useRef(null);
  const [query, setQuery] = React.useState(null);
  const [messages, setMessages] = React.useState([
    {
      role: "assistant",
      content: "Hello! How can I assist you today?",
      other: "",
    },
  ]);
  const [loading, setLoading] = React.useState(false);
  const [suggestions, setSuggestions] = React.useState([]);

  const onEntersend = (value) => {
    setSuggestions([]);
    getQueryAnswer(value);
  };

  const getQueryAnswer = (query) => {};
  // const getQueryAnswer = (query) => {
  //   setLoading(true);
  //   setQuery(query);
  //   const req_value = {
  //     params: {
  //       query: query,
  //     },
  //   };
  //   httpget(get_response, req_value).then((result) => {
  //     console.log(result);
  //     setMessages([
  //       ...messages,
  //       { role: "user", content: query, other: "" },
  //       { role: "assistant", content: result.content, other: "" },
  //     ]);
  //     setQuery(null);
  //     setLoading(false);
  //     setSuggestions(result.suggestions);
  //   });
  // };

  React.useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, suggestions]);

  return (
    <div>
      <div className="chat_box">
        {messages.map((item, index) => (
          <div key={"msg_" + index}>
            {item.role === "assistant" ? (
              <GravitonMessageBox msg={item.content} other={item.other} />
            ) : (
              <UserMessageBox msg={item.content} other={item.other} />
            )}
          </div>
        ))}
        {loading && query !== null && <UserMessageBox msg={query} />}
        {loading && (
          <GravitonMessageBoxLoading
            msg={
              <div className="ticontainer">
                <div className="tiblock">
                  <div className="tidot" key="1"></div>
                  <div className="tidot" key="2"></div>
                  <div className="tidot" key="3"></div>
                  <div className="tidot" key="4"></div>
                </div>
              </div>
            }
          />
        )}
        <div className="suggestion_box_parent">
          {suggestions.map((item, index) => (
            <div
              className="suggestion_box"
              key={"suggestion_" + index}
              onClick={() => onEntersend(item)}
            >
              {item}
            </div>
          ))}
        </div>
        <div ref={bottomRef} />
      </div>
      <div className="parent_input_box">
        <InputBox onSubmit={onEntersend} />
      </div>
    </div>
  );
};

export default Chat;
