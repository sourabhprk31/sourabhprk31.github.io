import * as React from "react";
import AppContext from "../../AppContext";

import { LabelTitle } from "../../components/FORMComponent/index";
import { InputLabel } from "../../components/FORMComponent/index";
import { PrimaryButton } from "../../components/Buttons/buttons";
import InputValues from "./InputValues.json";

import { DropDownList } from "@progress/kendo-react-dropdowns";
import { NumericTextBox } from "@progress/kendo-react-inputs";
import { Label } from "@progress/kendo-react-labels";

const Configuration = (props) => {
  const { appType } = React.useContext(AppContext);

  const details = InputValues["details"];
  const default_llm_model = InputValues["llm_models"][0];
  const [llm_model, setllm_model] = React.useState(default_llm_model);

  const handle_llm_model = (event) => {
    console.log("Selected LLM Model :>>", event.target.value);
    setllm_model(event.target.value);
  };

  return (
    <div className={appType === "ISE" ? "" : "body_content"}>
      <div className="row">
        <div className="cardlefttitle">
          <LabelTitle label={"LLM Configuration"} />
        </div>
        <div className="cardrighttitle">
          <LabelTitle label={"Details"} />
        </div>
      </div>
      <div className="row">
        <div className="cardleftview">
          <div>
            <InputLabel label={"Select LLM Model:"}></InputLabel>
            <div className="inputspace"></div>
            <DropDownList
              className="bordercolor input_font"
              data={InputValues["llm_models"]}
              value={llm_model}
              onChange={handle_llm_model}
            />
          </div>
          <div className="emptyrow"></div>
          <div>
            <InputLabel label={"Temperature:"}></InputLabel>
            <div className="inputspace"></div>
            <NumericTextBox
              className="bordercolor input_font"
              placeholder="Please Enter Temperature"
              defaultValue={0.2}
              min={0}
              max={1}
              step={0.1}
            />
          </div>
          <div className="emptyrow"></div>
          <div>
            <InputLabel label={"Token Length:"}></InputLabel>
            <div className="inputspace"></div>
            <NumericTextBox
              className="bordercolor input_font"
              placeholder="Please Enter Token Length"
              defaultValue={2048}
              min={0}
              max={32000}
              step={100}
            />
          </div>
          <div className="emptyrow"></div>
          <div>
            <div className="floatright">
              <PrimaryButton icon={"save"} label={"Save"} />
            </div>
          </div>
        </div>
        <div className="cardrightview">
          {details.map((info) => (
            <div className="details_content">
              <i className="fa-regular fa-hand-point-right primaryColor"></i>
              &nbsp;
              <Label className="multiline-label">{info}</Label>
              <br />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Configuration;
