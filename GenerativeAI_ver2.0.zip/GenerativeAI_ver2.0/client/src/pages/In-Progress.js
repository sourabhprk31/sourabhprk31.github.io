const HomePage = (props) => {
  return (
    <div className="body_content">
      <div className="content_center card-container">
        <div className="row">
          <p>In-Progress</p>
        </div>
        <br></br>
      </div>
    </div>
  );
};

export default HomePage;
