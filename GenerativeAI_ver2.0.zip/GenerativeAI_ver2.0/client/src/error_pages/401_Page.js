import React from "react";
import UnauthorizedImage from "./../assets/error_images/401.png";
import { useHistory } from "react-router-dom";
import { Button } from "@progress/kendo-react-buttons";

function UnAuthorizedAccess() {
  const history = useHistory();
  const submitForm = (e) => {
    e.preventDefault();
    history.push("/login");
  };

  return (
    <div className="content_center card-container">
      <div className="row">
        <img
          src={UnauthorizedImage}
          alt="UnauthorizedImage"
          style={{
            width: "50vw",
            height: "35vh",
          }}
        />
      </div>
      <br></br>
      <div className="row">
        <p>Authorization Not Found!</p>
      </div>
      <div className="rowspace"></div>
      {/* <div className="row">
        <span
          style={{ color: "#713595", fontWeight: "bold", fontSize: "24pt" }}
        >
          Please Sign Up before login again.
        </span>
      </div> */}
      <div className="rowspace"></div>
      <div className="rowspace"></div>
      <div className="row">
        <span style={{ color: "black", fontWeight: "bold", fontSize: "12pt" }}>
          Click below button for redirect to login page.
        </span>
      </div>
      <br></br>
      <div className="row">
        <Button className="savebutton" onClick={submitForm}>
          RETURN LOGIN PAGE
        </Button>
      </div>
    </div>
  );
}
export default UnAuthorizedAccess;
