import React from "react";
import InternalServerImage from "./../assets/error_images/500.png";

function Servers() {
  return (
    <div className="content_center card-container" style={{ marginTop: "8%" }}>
      <div className="row">
        <img
          src={InternalServerImage}
          alt="InternalServerImage"
          style={{
            width: "20vw",
            height: "35vh",
          }}
        />
      </div>
      <br></br>
      <div className="row">
        <p>Internal Server Error!</p>
      </div>
      <br></br>
    </div>
  );
}
export default Servers;
