import React from "react";
import PageNotFoundImage from "./../assets/error_images/404.png";

function UnAuthorizedAccess() {
  return (
    <div className="content_center card-container" style={{ marginTop: "8%" }}>
      <div className="row">
        <img
          src={PageNotFoundImage}
          alt="PageNotFoundImage"
          style={{
            width: "20vw",
            height: "35vh",
          }}
        />
      </div>
      <br></br>
      <div className="row">
        <p>Page Not Found!</p>
      </div>
      <br></br>
    </div>
  );
}
export default UnAuthorizedAccess;
