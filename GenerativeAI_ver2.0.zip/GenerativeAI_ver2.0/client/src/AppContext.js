import { createContext } from "react";

const AppContext = createContext({
  appType: null,
  setAppType: () => {},
});

export default AppContext;
