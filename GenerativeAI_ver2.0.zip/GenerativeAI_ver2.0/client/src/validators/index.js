const emailRegex = new RegExp(/^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/);

export const emailValidator = (value) =>
  emailRegex.test(value) ? true : false;

export const requiredValidator = (value) =>
  value && value.length >= 3 ? "" : "Please enter valid details.";

export const Min3Validator = (value) =>
  value && value.length >= 3 ? true : false;

export const Max32Validator = (value) =>
  value && value.length <= 32 ? true : false;

export const projectNameValidator = (project_name) => {
  let validation_error = "";

  const validation_status =
    project_name !== "" &&
    Min3Validator(project_name) &&
    Max32Validator(project_name);

  if (!validation_status) {
    validation_error = "Enter valid Project Name";
  }

  const validation_response = {
    validation_status: validation_status,
    validation_error: validation_error,
  };
  console.log(
    "projectNameValidator Response:>>",
    JSON.stringify(validation_response)
  );
  return validation_response;
};
