import { createContext } from "react";

const HeaderContext = createContext({
  shouldReload: false,
  setShouldReload: () => {},
});

export default HeaderContext;
