import os
import openai
import logging
import configparser

from Utility import utility

token_cost_dict = {
    'text-model-davinci03': 0.00002,
    'codemodel-davinci': 0.001,
    'chat-model': 0.000002
}

cwdPath = os.path.abspath(os.getcwd())
config_path = os.path.join(cwdPath, "config")
config_parser = configparser.ConfigParser()
config_parser.read(os.path.join(config_path, "openai_config.ini"))


def get_prompt_cost(token_length, engine):
    dollar_rate = 82.48
    print("Prompt Cost in Dollars :>>", token_length * token_cost_dict[engine])
    return (token_length * token_cost_dict[engine]) * dollar_rate


class GPTConnector:

    def set_openai_config(self, subscription):
        self.logger = logging.getLogger(__name__)
        openai.api_type = config_parser.get(subscription, "api_type")
        openai.api_base = config_parser.get(subscription, "api_base")
        openai.api_key = config_parser.get(subscription, "api_key")
        openai.api_version = config_parser.get(subscription, "api_version")

        self.session_total_cost = 0
        self.history = []

        self.max_tokens = 3500
        self.temperature = 0
        self.curr_response = ""

    def run_for_script(self, subscription, deployment_name, messages, role_msg: str, prompt, log_name):
        utility.updatelog(log_name, "OpenAI Running...", True)
        self.set_openai_config(subscription)
        final_response = self._generate_for_script(deployment_name, messages, role_msg, prompt)
        utility.updatelog(log_name, "OpenAI Completed Successfully!\n", True)
        return final_response

    def _generate_for_script(self, deployment_name, messages, role_msg: str, prompt):
        self.set_sys_role(role_msg)
        messages.append(
            {"role": "user", "content": prompt},
        )
        final_response = self.get_completion(deployment_name, messages=messages, temperature=0.1)
        return final_response

    def get_completion_for_script(self, deployment_name, messages, role_content=None, max_tokens=None, temperature=None,
                                  display_response=True):

        response = openai.ChatCompletion.create(
            engine=deployment_name,
            messages=messages,
            temperature=temperature if temperature is not None else self.temperature,
            max_tokens=max_tokens if max_tokens is not None else self.max_tokens,
            top_p=0.95,
            frequency_penalty=0.01,
            presence_penalty=0,
            stop=None
        )

        # print(response)
        res = response['choices'][0]['message']
        prompt_tokens = response['usage']['prompt_tokens']
        total_tokens = response['usage']['total_tokens']
        prompt_cost = total_tokens * token_cost_dict[deployment_name]

        cost_token_info = {}
        cost_token_info['prompt_tokens'] = prompt_tokens
        cost_token_info['total_tokens'] = total_tokens
        cost_token_info['prompt_cost'] = prompt_cost
        final_response = {}
        final_response['response'] = res['content']
        final_response['cost_token_info'] = cost_token_info
        return final_response


