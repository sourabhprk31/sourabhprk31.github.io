"""
=============================================================================
COPYRIGHT NOTICE
=============================================================================
© Copyright HCL Technologies Ltd. 2021, 2022, 2023
Proprietary and confidential. All information contained herein is, and
remains the property of HCL Technologies Limited. Copying or reproducing the
contents of this file, via any medium is strictly prohibited unless prior
written permission is obtained from HCL Technologies Limited.
"""

from datetime import datetime
import json
import ast
import os
import zipfile  
from django.http import HttpResponse, FileResponse
from django.core.files import File

from Utility import postgres_conn as postgres_connection
from Utility import CodeGeneration
from Utility import CodeSummarization
from Utility import utility
from Utility import TestScriptGeneration


def create_usecase_table():
    create_query = '''CREATE TABLE IF NOT EXISTS public.usecases
        (
            usecase_id serial NOT NULL PRIMARY KEY,
            usecase_name character varying(50) NOT NULL,
            usecase_type character varying,
            input_control json,
            input_label json,
            input_data json,
            input_visibility json,
            default_value json,
            output_control character varying,
            prompt_value json,
            additional_info json,
            usecase_info character varying,
            active_status boolean
        )'''
    postgres_connection.execute_create_query(create_query)


def get_usecase_names(request):
    create_usecase_table()
    query = '''select usecase_name from public.usecases order by usecase_id asc'''
    res = postgres_connection.execute_get_query(query,[])
    result = []
    for row in res["data"]:
        submenu = {}
        submenu["text"] = row["usecase_name"]
        result.append(submenu)
    print("Use Case Name List for Sub Menu :>>", result)
    return result

def get_usecase_type(request):
    usecase_type= ""
    usecase_name = request.GET["usecase_name"]
    select_query = 'SELECT usecase_type from public.usecases where usecase_name=%s'
    res = postgres_connection.execute_get_query(select_query, [usecase_name])
    for row in res["data"]:
        usecase_type = row["usecase_type"]
    print("Use Case Type :>>", usecase_type)
    return usecase_type


def get_usecase_info(request):
    create_usecase_table()
    usecase_name = request.GET["usecase_name"]
    select_query = 'SELECT usecase_id, usecase_name, usecase_type, input_control, input_label, input_data, input_visibility, default_value, output_control, usecase_info from public.usecases where usecase_name=%s'
    res = postgres_connection.execute_get_query(select_query, [usecase_name])
    final_input_details = {}
    input_details_arr = []
    for row in res["data"]:
        final_input_details['usecase_id'] = row['usecase_id']
        final_input_details['usecase_name'] = row['usecase_name']
        final_input_details['usecase_type'] = row['usecase_type']
        final_input_details['usecase_info'] = row['usecase_info']
        final_input_details['output_control'] = row['output_control']
       
        temp_input_control = json.loads(row["input_control"].replace('\'','\"'))
        temp_input_label = json.loads(row["input_label"].replace('\'','\"'))
        temp_input_data = json.loads(row["input_data"].replace('\'','\"'))
        temp_visibility = json.loads(row["input_visibility"].replace('\'','\"'))
        temp_defaultvalue = json.loads(row["default_value"].replace('\'','\"'))
        final_input_details['defaultValue'] = temp_defaultvalue
        for (input_id, input_control) in temp_input_control.items():
            input_details = {}
            input_details["input_id"] = input_id
            input_details["input_control"] = input_control
            input_details["input_label"] = temp_input_label[input_id]  if input_id in temp_input_label else ""
            input_details["input_data"] = temp_input_data[input_id]  if input_id in temp_input_data else ""
            input_details["visibility"] = temp_visibility[input_id]  if input_id in temp_visibility else ""
            input_details["default_value"] = temp_defaultvalue[input_id]  if input_id in temp_defaultvalue else ""
            input_details_arr.append(input_details)
      
        final_input_details['input_details'] = input_details_arr
        print("Use Case Details :>>", final_input_details)
    return final_input_details


def run_usecase(request):
    usecase_name = request.GET["usecase_name"]
    project_name = request.GET["project_name"]
    form_data = json.loads(request.GET["form_data"])

    if usecase_name == "Code Summarization":
        response = CodeSummarization.summarization(usecase_name, project_name, form_data)
    elif usecase_name == "Code Generation":
        response = CodeGeneration.generation(usecase_name, project_name, form_data)
    elif usecase_name == "Code TestScript Generation":
        response = TestScriptGeneration.generation(usecase_name, project_name, form_data)
    # elif usecase_name == "Code TestCase Generation":
    #     response = CodeGeneration.generation(usecase_name, project_name, form_data)

    return response


def get_detailed_result(request):
    usecase_name = request.GET["usecase_name"]
    project_name = request.GET["project_name"]
    input_file_name = request.GET["input_file_name"]
    output_file_type = request.GET["output_file_type"]
    file_name = input_file_name.split(".")[0]+output_file_type
    response = utility.read_file(usecase_name, file_name, "output")
    return response


def downloadResult(request):
    usecase_name = request.GET["usecase_name"]
    zip_path = utility.check_create_directory(usecase_name, "zip")
    zip_filepath = os.path.join(zip_path, usecase_name.replace(" ", "_")+".zip")
    dir_path = utility.get_directory_path(usecase_name, "output")

    utility.make_archive(dir_path,zip_filepath)
    
    
    # Serve the zip file
    downloadfile_content = open(zip_filepath, 'rb')
    
    downloadfile = File(downloadfile_content)
    response = HttpResponse(downloadfile.read())
    response['Content-Disposition'] = 'attachment'
    return response  
