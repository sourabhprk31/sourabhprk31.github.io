from Utility import utility
from Utility import utility_test_script_case
from Utility.openai import GPTConnector


def generation(usecase_name, project_name, form_data):
    log_name = usecase_name
    utility.createLOGFile(log_name)
    utility.updatelog(log_name, "***** ***** ***** ***** Started ***** ***** ***** *****", False)
    ################## GENERATE PROMPT ####################

    requirement, api_file, prerequisite, usertype, language = utility_test_script_case.GetUiData(usecase_name, form_data)

    try:
        prompt_tokens, total_tokens, prompt_cost, total_count = 0, 0, 0, 0
        count_type = "LoC"
        file_type = ""
        instruction = "Generate testscript in "
        if language == "python":
            file_type = ".py"
            instruction = instruction + language
        elif language == "java":
            file_type = ".java"
            instruction = instruction + language
        elif language == "powershell":
            file_type = ".ps1"
            instruction = instruction + language

        file_name = "testScript"+file_type
        messages = [
            {"role": "user", "content": requirement},
            {"role": "user", "content": api_file},
            {"role": "user", "content": prerequisite}

        ]

        ################## CALL OPENAI ####################
        generator = GPTConnector()
        subscription_name = "dev-openai-usecases"
        deployment_name = "chat-model"
        response = generator.run_for_script(subscription_name, deployment_name, messages,
                                            role_msg="user", instruction=instruction, log_name=log_name)

        use_project_file = True
        # utility.save_response(use_project_file, outputroot_path, file_relpath, response, file_type, log_name)
        prompt_tokens += response["cost_token_info"]["prompt_tokens"]
        total_tokens += response["cost_token_info"]["total_tokens"]
        prompt_cost += response["cost_token_info"]["prompt_cost"]
        # total_count += utility.check_count(project_name, file_relpath, count_type)

        result_summary = {}
        result_summary['project_name'] = project_name
        result_summary['numof_files'] = 0
        result_summary[count_type] = total_count
        result_summary['numof_prompts_executed'] = 0
        result_summary['prompt_tokens'] = prompt_tokens
        result_summary['total_tokens'] = total_tokens
        result_summary['prompt_cost'] = prompt_cost
        result_summary['time_taken'] = 5

        final_response = {}
        final_response["status"] = "success"
        final_response["msg"] = ""
        final_response["result_summary"] = result_summary
        final_response["input_file_details"] = file_name
        final_response["output_file_type"] = file_type
        utility.updatelog(log_name,
                          "\nResult Summary Generated Successfully!" + "\n\n***** ***** ***** ***** Completed ***** ***** ***** *****",
                          False)
        return final_response



    except Exception as e:
        utility.updatelog(log_name, str(e), True)
        final_response = {}
        final_response["status"] = "failed"
        final_response["msg"] = str(e)
        final_response["result_summary"] = {}
        final_response["input_file_details"] = []
        final_response["output_file_type"] = ""
        return final_response
