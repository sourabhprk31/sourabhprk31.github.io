import os
from datetime import datetime
### Configured the ROOt Path
cwdPath = os.path.abspath(os.getcwd())

Logs_rootpath = os.path.join(cwdPath, "Logs")

### Updating the LOGS
def updatelog(log_name, log_content, date_display):
    log_name = log_name.replace(" ", "_")
    logs_path = os.path.join(Logs_rootpath, log_name)
    current_date_time = datetime.now()

    formatted_date_time = current_date_time.strftime("%d-%m-%Y %H:%M:%S")

    if date_display == True:
        formatted_line = f"{formatted_date_time}   {log_content}"
    else:
        formatted_line = f"{log_content}"

    with open(logs_path, "r") as file:
        content = file.read()

    updated_content = content + formatted_line + "\n"
    with open(logs_path, "w") as file:
        file.write(updated_content)


def GetUiData(usecase_name, form_data):
    updatelog(usecase_name, "TestScript UI data ...", True)
    usertype = form_data[1]
    language = form_data[2]
    requirement = form_data[3]
    api_file = form_data[4]
    prerequisite = form_data[5]
    updatelog(usecase_name, "TestScript UI Data Getting Successfully!\n", True)
    return requirement, api_file, prerequisite, usertype, language