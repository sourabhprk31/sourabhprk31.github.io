# Define the data for the table (Replace with respective modules to get data)
$tableData = @(
    @{
        SerialNo        = 1
        TestSeriesID    = "TS1"
        TestCaseID      = "TC1"
        TestCase        = "Login"
        ExpectedBehavior = "Successful login"
        ObservedBehavior = "Successful login"
        TestCaseResult   = "Pass"
    }
    # Add more test cases as needed
)

# Create a new Word application
$wordApp = New-Object -ComObject Word.Application
$wordApp.Visible = $true

# Create a new document
$doc = $wordApp.Documents.Add()

# Add a table with a title row and data rows
$numberOfRows = $tableData.Count + 1
$numberOfColumns = 7
$range = $doc.Range()
$table = $doc.Tables.Add($range, $numberOfRows, $numberOfColumns)

# Fill in the title row
$titleRow = @("Serial No.", "Test Series ID", "Test Case ID", "Test Case", "Expected Behavior", "Observed Behavior", "Test Case Pass/Fail")
for ($i = 0; $i -lt $numberOfColumns; $i++) {
    $table.Cell(1, $i + 1).Range.Text = $titleRow[$i]
}

# Fill in the data rows
for ($i = 0; $i -lt $tableData.Count; $i++) {
    $rowData = $tableData[$i]
    $table.Cell($i + 2, 1).Range.Text = $rowData.SerialNo
    $table.Cell($i + 2, 2).Range.Text = $rowData.TestSeriesID
    $table.Cell($i + 2, 3).Range.Text = $rowData.TestCaseID
    $table.Cell($i + 2, 4).Range.Text = $rowData.TestCase
    $table.Cell($i + 2, 5).Range.Text = $rowData.ExpectedBehavior
    $table.Cell($i + 2, 6).Range.Text = $rowData.ObservedBehavior
    $table.Cell($i + 2, 7).Range.Text = $rowData.TestCaseResult
}

# Save the document
$doc.SaveAs([ref]"C:\Path\To\Your\Report.docx")
$doc.Close()

# Quit Word
$wordApp.Quit()