# Powershell script to test Quiet Boot Enabled requirement

# Import required modules or libraries
# Add required imports here

# Start the device
StartDevice

# Variables
$bootMenuArrowPresses = 4
$imageSavePath = "captured_screen.png"
$quietBootLocation = "your_location_here" # Replace this with the location of the Quiet Boot text on the screen

# Navigate to boot menu
for ($i = 0; $i -lt $bootMenuArrowPresses; $i++) {
    SendKB_SpecialKeyEvent "RightArrow"
    Start-Sleep -Milliseconds 500
}

# Capture the screen and save the image
CaptureImage $imageSavePath

# Extract Quiet Boot text from the captured screen
$capturedScreen = Get-Content $imageSavePath
$extractedText = Extract_Screen_OCR $capturedScreen $quietBootLocation

# Verify Quiet Boot Enabled requirement
$testResult = $false
if ($extractedText -eq "Quiet Boot: Enabled") {
    $testResult = $true
}

# Generate test report
GenerateTestReport $capturedScreen $testResult

# Output test result
if ($testResult) {
    Write-Host "Test Passed: Quiet Boot is Enabled"
} else {
    Write-Host "Test Failed: Quiet Boot is not Enabled"
}