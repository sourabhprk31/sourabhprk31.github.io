# Python Script to test the requirement and generate a test report

# Import required modules
# Assuming the APIs are part of a custom module named device_testing
import device_testing

# Start the device
device_testing.start_device()

# Capture the screen and save the image
image_save_path = "path/to/image/folder/boot_menu.png"
device_testing.capture_image(image_save_path)

# Define location to extract "Main" text
main_text_location = {
    "x": 900,
    "y": 20,
    "width": 50,
    "height": 20
}

# Extract "Main" text from the screen
with open(image_save_path, 'r') as f:
    captured_screen = f.read()

main_text_status = device_testing.extract_screen_ocr(captured_screen, main_text_location)

# Check if "Main" text is displayed
if main_text_status == "Main":
    main_text_result = "PASS"
else:
    main_text_result = "FAIL"

# Press right arrow key four times to reach the boot menu
for _ in range(4):
    device_testing.sendkb_specialkey_event("RightArrow")

# Define location to extract Quiet Boot status
quiet_boot_location = {
    "x": 100,
    "y": 100,
    "width": 150,
    "height": 50
}

# Extract Quiet Boot status from the screen
quiet_boot_status = device_testing.extract_screen_ocr(captured_screen, quiet_boot_location)

# Check if Quiet Boot is enabled
if quiet_boot_status == "Enabled":
    quiet_boot_result = "PASS"
else:
    quiet_boot_result = "FAIL"

# Generate a test report
test_result = {
    "MainText": main_text_result,
    "QuietBoot": quiet_boot_result
}

device_testing.generate_test_report(captured_screen, test_result)

print(f"Main text result: {test_result['MainText']}")
print(f"Quiet Boot result: {test_result['QuietBoot']}")