import React from 'react';
import ReactDOM from 'react-dom';

class ExpenseTracker extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      expenses: [],
      total: 0
    };
  }

  addExpense(name, amount, date) {
    const expenses = this.state.expenses.slice();
    expenses.push({ name, amount, date });
    this.setState({ expenses });
  }

  calculateTotal() {
    let total = 0;
    for (let i = 0; i < this.state.expenses.length; i++) {
      total += this.state.expenses[i].amount;
    }
    this.setState({ total });
  }

  handleSubmit(event) {
    event.preventDefault();
    const name = this.refs.name.value;
    const amount = parseFloat(this.refs.amount.value);
    const date = this.refs.date.value;
    this.addExpense(name, amount, date);
    this.calculateTotal();
    this.refs.form.reset();
  }

  render() {
    return (
      <div>
        <h1>Expense Tracker</h1>
        <form ref="form" onSubmit={this.handleSubmit.bind(this)}>
          <label>
            Expense Name:
            <input type="text" ref="name" />
          </label>
          <label>
            Expense Amount:
            <input type="number" ref="amount" />
          </label>
          <label>
            Expense Date:
            <input type="date" ref="date" />
          </label>
          <input type="submit" value="Submit" />
        </form>
        <h2>Expenses:</h2>
        <ul>
          {this.state.expenses.map((expense, index) =>
            <li key={index}>{expense.name}: ${expense.amount} on {expense.date}</li>
          )}
        </ul>
        <h3>Total: ${this.state.total}</h3>
      </div>
    );
  }
}