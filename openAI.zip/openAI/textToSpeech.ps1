function GetAudioFromText {
    param (
        [Parameter(Mandatory = $true)]
        [string]$InputTextFile,
        [Parameter(Mandatory = $true)]
        [string]$OutputAudioFile
    )
    # Create a Word.Application COM object
    $wordApp = New-Object -ComObject Word.Application
    try {
        # Hide the Word window
        $wordApp.Visible = $true

        # Open the input text document
        $inputDocument = $wordApp.Documents.Open($InputTextFile)

        # Access the text-to-speech feature
        $speech = $wordApp.Speech

        # Speak the text and save it to a .wav file
        $speech.Speak([string]::Join(" ", $inputDocument.Content.Text), 3, $OutputAudioFile)

        # Close the input document
        $inputDocument.Close([Microsoft.Office.Interop.Word.WdSaveOptions]::wdDoNotSaveChanges)
        Write-Host "Text-to-speech synthesis completed. The audio has been saved to $OutputAudioFile." -ForegroundColor Green
    }
    catch {
        Write-Host "An error occurred: $_" -ForegroundColor Red
    }
    finally {
        # Quit the Word application
        $wordApp.Quit()
    }
}
# Example usage
GetAudioFromText -InputTextFile "C:\Files\testaud.txt" -OutputAudioFile "C:\Files\audio.wav"