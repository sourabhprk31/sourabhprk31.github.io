function Play-Audio {
    param (
        [Parameter(Mandatory = $true)]
        [string]$AudioFilePath
    )
    try {
        # Create a SoundPlayer object
        $soundPlayer = New-Object -TypeName System.Media.SoundPlayer

        # Load the audio file
        $soundPlayer.SoundLocation = $AudioFilePath
        $soundPlayer.Load()

        # Play the audio
        $soundPlayer.PlaySync()
        Write-Host "Audio playback completed." -ForegroundColor Green
    }
    catch {
        Write-Host "An error occurred: $_" -ForegroundColor Red
    }
}
# Example usage
Play-Audio -AudioFilePath "C:\Files\audio.wav"