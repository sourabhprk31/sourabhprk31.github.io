import numpy as np
import scipy.io.wavfile as wav

def test_alarm(audio_file):
    # Load the audio file
    sample_rate, audio_data = wav.read(audio_file)
    # Set the parameters for the beep detection algorithm
    beep_freq = 1000 # Frequency of the beep
    beep_duration = 0.1 # Duration of the beep (in seconds)
    beep_threshold = 0.5 # Amplitude threshold for detecting the beep
    # Generate a template for the beep signal
    template = np.sin(2 * np.pi * beep_freq * np.linspace(0, beep_duration, int(beep_duration * sample_rate)))
    # Calculate the cross-correlation between the audio data and the beep template
    corr = signal.correlate(audio_data[:,0], template, mode='same')
    # Find the peaks in the cross-correlation
    peaks, _ = signal.find_peaks(corr, height=beep_threshold)
    # Count the number of peaks (i.e. the number of beeps)
    num_beeps = len(peaks)
    if num_beeps == 5:
        print("Test passed: The software produced 5 beeps")
    else:
        print(f"Test failed: The software produced {num_beeps} beeps instead of 5")
# Run the test on an audio file
test_alarm("audio_file.wav")