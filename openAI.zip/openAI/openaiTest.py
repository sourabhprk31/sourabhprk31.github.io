import os
os.environ["OPENAI_API_KEY"] = "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"


import openai
openai.organization = "org-gHHhcvD9EgxZf98tlm7bTf7k"
openai.api_key = os.getenv("OPENAI_API_KEY")
# openai.api_key = "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"
# openai.Model.list()

# openai.Completion.create(
#   model="gpt-3.5-turbo",
#   messages=[
#         {"role": "system", "content": "You are a helpful assistant."},
#         {"role": "user", "content": "Who won the world series in 2020?"},
#         {"role": "assistant", "content": "The Los Angeles Dodgers won the World Series in 2020."},
#         {"role": "user", "content": "Where was it played?"}
#     ]
# )

response = openai.Completion.create(
    engine="davinci-codex",
    prompt="Translate the following English text to French: 'Hello, how are you?'",
    max_tokens=1024,
    n=1,
    stop=None,
    temperature=1,
)

generated_text = response.choices[0].text.strip()
print(generated_text)
