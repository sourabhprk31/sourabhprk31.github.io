# Install-Package -Name NAudio -Scope CurrentUser
Add-Type -Path 'C:\Users\<username>\.nuget\packages\naudio\1.10.0\lib\net35\NAudio.dll'
function Start-SpeakerRecording {
    param (
        [Parameter(Mandatory = $true)]
        [string]$OutputAudioFile,
        [int]$RecordingDurationSeconds = 10
    )
    try {
        $capture = New-Object NAudio.Wave.WasapiLoopbackCapture
        $waveFileWriter = New-Object NAudio.Wave.WaveFileWriter($OutputAudioFile, $capture.WaveFormat)
        $stopwatch = [System.Diagnostics.Stopwatch]::StartNew()

        $capture.DataAvailable += {
            param($sender, $e)
            if ($stopwatch.Elapsed.TotalSeconds -lt $RecordingDurationSeconds) {
                $waveFileWriter.Write($e.Buffer, 0, $e.BytesRecorded)
            }
            else {
                $capture.StopRecording()
            }
        }
        $capture.RecordingStopped += {
            param($sender, $e)

            $waveFileWriter.Dispose()
            $waveFileWriter = $null
            $capture.Dispose()
            Write-Host "Recording completed. The audio has been saved to $OutputAudioFile." -ForegroundColor Green
        }
        $capture.StartRecording()
        Write-Host "Recording in progress... Press Ctrl+C to stop early." -ForegroundColor Yellow
    }
    catch {
        Write-Host "An error occurred: $_" -ForegroundColor Red
    }
}
# Example usage
Start-SpeakerRecording -OutputAudioFile "C:\Files\audio_out.wav" -RecordingDurationSeconds 10 