# Install-Package -Name System.Speech
function GetAudioFromText {
    param (
        [Parameter(Mandatory = $true)]
        [string]$InputTextFile,
        [Parameter(Mandatory = $true)]
        [string]$OutputAudioFile
    )
    # Load the System.Speech assembly
    Add-Type -AssemblyName System.Speech

    # Create a System.Speech.Synthesis.SpeechSynthesizer object
    $synthesizer = New-Object System.Speech.Synthesis.SpeechSynthesizer

    try {
        # Read the input text file
        $text = Get-Content -Path $InputTextFile -Raw

        # Set the output format to 16kHz 16-bit Mono PCM
        $format = New-Object System.Speech.AudioFormat.SpeechAudioFormatInfo(16000, 
        [System.Speech.AudioFormat.AudioBitsPerSample]::Sixteen, [System.Speech.AudioFormat.AudioChannel]::Mono)

        # Speak the text and save it to a .wav file
        $synthesizer.SetOutputToWaveFile($OutputAudioFile, $format)
        $synthesizer.Speak($text)
        $synthesizer.SetOutputToNull()

        Write-Host "Text-to-speech synthesis completed. The audio has been saved to $OutputAudioFile." -ForegroundColor Green
    }
    catch {
        Write-Host "An error occurred: $_" -ForegroundColor Red
    }
}
# Example usage
GetAudioFromText -InputTextFile "C:\Files\testaud.txt" -OutputAudioFile "C:\Files\audio.wav"