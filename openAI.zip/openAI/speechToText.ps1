function GetTextFromAudio {
    param (
        [Parameter(Mandatory = $true)]
        [string]$InputAudioFile,
        [Parameter(Mandatory = $true)]
        [string]$OutputTextFile
    )
    # Ensure the Microsoft Dictate utility is installed
    $dictatePath = "C:\Program Files\Microsoft Dictate"
    if (-not (Test-Path $dictatePath)) {
        Write-Host "Microsoft Dictate not found. Please install it before running this script." -ForegroundColor Red
        return
    }
    # Load the Dictate utility
    Add-Type -Path "$dictatePath\Microsoft.Dictate.dll"
    try {
        # Initialize the Dictate utility
        $dictate = New-Object Microsoft.Dictate.Dictate

        # Convert audio to text
        $transcription = $dictate.Transcribe($InputAudioFile)

        # Save the transcription to the output text file
        $transcription | Set-Content $OutputTextFile

        Write-Host "Audio transcription completed. The text has been saved to $OutputTextFile." -ForegroundColor Green
    }
    catch {
        Write-Host "An error occurred: $_" -ForegroundColor Red
    }
    finally {
        # Dispose of the Dictate object
        if ($null -ne $dictate) {
            $dictate.Dispose()
        }
    }
}
# Example usage
GetTextFromAudio -InputAudioFile "C:\Files\audio.wav" -OutputTextFile "C:\Files\output.txt"