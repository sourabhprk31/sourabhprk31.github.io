import json
import openai
import subprocess
import xlrd

from gpt import GPT
from gpt import Example
# from openpyxl import load_workbook
from xlutils.copy import copy

with open('GPT_SECRET_KEY.json') as f:
    data = json.load(f)

openai.api_key = data["API_KEY"]

gptExpression = GPT(engine="davinci",
        temperature=0.5,
        max_tokens=150)

gptVariable = GPT(engine="davinci",
        temperature=0.5,
        max_tokens=150)

gpt = GPT(engine="davinci",
        temperature=0.5,
        max_tokens=150)

gpt.add_example(Example("The Operational Software shall set AWD_Dispensor_Pump to true, if AW_Overflow_Status equals to false "
                        "or AW_Water_Cup_Present_Status equals to true",
                "set('AW_Overflow_Status' , False)\nset('AW_Water_Cup_Present_Status' , True)\n"
                "Result = get(AWD_Dispensor_Pump)\n "
                "if(Result == True):\n\t"
                "print('TestCase Pass')\nelse:\n\tprint('TestCase Fail')"))


"""TRAINING FOR MCDC TOOL EXPRESSION"""
gptExpression.add_example(Example("The Operational Software shall set AWD_Dispensor_Pump to true, if AW_Overflow_Status equals to false "
                        "or AW_Water_Cup_Present_Status equals to true",
                '( AW_Overflow_Status || AW_Water_Cup_Present_Status )'))

"""Training to get variable"""
gptVariable.add_example(Example("The Operational Software shall set AWD_Dispensor_Pump to ON, if AW_Overflow_Status equals to NO OVERFLOW "
                        "or AW_Water_Cup_Present_Status equals to PRESENT",
                'AWD_Dispensor_Pump,AW_Overflow_Status,AW_Water_Cup_Present_Status'))

gptVariable.add_example(Example("The Operational Software shall set AWD_Dispensor_Pump to ON, if AW_Overflow_Status equals to NO OVERFLOW "
                        "or AW_Water_Cup_Present_Status equals to PRESENT",
                'AWD_Dispensor_Pump,AW_Overflow_Status,AW_Water_Cup_Present_Status'))

#Requirement in natural language
prompt = "The Operational Software shall set AWD_Dispensor_Pump_var_1 to true, "\
    "if AW_Overflow_Status_var_2 equals to false or AW_Water_Cup_Present_Status_var_3 equals to true"


gptoutput = gpt.submit_request(prompt)
print(gptoutput.choices[0].text)
outputExpression = gptExpression.submit_request(prompt)

print('------------MCDC EXPRESSION-------------')
print(outputExpression.choices[0].text.replace('output: ',''))

outputVariable = gptVariable.submit_request(prompt)

# print('------------VARIABLE-------------')
escapes = ''.join([chr(char) for char in range(1, 32)])
translator = str.maketrans('', '', escapes)

t = outputVariable.choices[0].text.translate(translator)
variableArr = t.replace('output: ','').split(",")

print('VARIABLE ARRAY ::: ',variableArr)

############################ Update Input XLS file ################################

# 1. Update Expression
# ------------------------

workbook = xlrd.open_workbook("C:/Users/Practice PC i7/Desktop/openAI/MCDC/MCDC/InputTemplate_updated.xls")

wb = copy(workbook)

w_sheet = wb.get_sheet(1)

w_sheet.write(2, 1, outputExpression.choices[0].text.replace('output: ',''))

w_sheet = wb.get_sheet(2)

start_row = 2
result_var = ''

update_sheet_by_blank = workbook.sheet_by_index(2)

for x in range(2, update_sheet_by_blank.nrows):
    for y in range(1, update_sheet_by_blank.ncols):
        w_sheet.write(x, y, '')


for val in variableArr:
    w_sheet.write(start_row, 1, val)
    w_sheet.write(start_row, 2, 'Boolean')
    start_row +=1
    if outputExpression.choices[0].text.find(val) == -1:
        result_var = val

wb.save("C:/Users/Practice PC i7/Desktop/openAI/MCDC/MCDC/InputTemplate_updated.xls")
print('Result_var ', result_var)

################################### Call MCDC Tool ###################################
subprocess.call(['java', '-jar', 'C:/Users/Practice PC i7/Desktop/openAI/MCDC/MCDC/MCDCAutomationGUI.jar'])


################################## Take the Output excel file data and generate TestScript ##########################

workbook1 = xlrd.open_workbook("Output.xls")

w_sheet = workbook1.sheet_by_index(3)

prompt_list = list()

variable_list = list()
for y in range(5, w_sheet.ncols):
        variable_list.append(w_sheet.cell_value(2,y))

# print("VAR_LIST ",variable_list)
# testscript template
temp_str = ''
set_string = 'set(variable , value)\n'
result_string = 'Result = get(variable)\n'
pass_fail_string = 'if(Result == value):\n\tprint("TestCase Pass")\nelse:\n\tprint("TestCase Fail")\n\n'
for x in range(3, w_sheet.nrows):
    temp_str = ''
    i = 0
    for y in range(5, w_sheet.ncols):
        temp_str += set_string.replace('variable',variable_list.__getitem__(i)).replace('value',w_sheet.cell_value(x, y))
        i = i+1

    temp_str += result_string.replace('variable', result_var)
    temp_str += pass_fail_string.replace('value', w_sheet.cell_value(x, 4))
    prompt_list.append('\n'+temp_str)

print('------------MC DC-------------')
index = 1
for i in prompt_list:
    print('\n')
    print(i)
    file = open("Automation_Script.py", "a")
    file.write('\n#Testscript '+str(index)+'\n'+i)
    file.close()
    index = index + 1