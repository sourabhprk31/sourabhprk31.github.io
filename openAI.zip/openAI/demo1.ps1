# PowerShell Script to test the requirement and generate a test report

# Import required modules
# Assuming the APIs are part of a custom module named "DeviceTesting"
Import-Module DeviceTesting

# Start the device
StartDevice

# Press right arrow key four times to reach the boot menu
for ($i = 0; $i -lt 4; $i++) {
    SendKB_SpecialKeyEvent "RightArrow"
}

# Capture the screen and save the image
$image_save_path = "C:\path\to\image\folder\boot_menu.png"
CaptureImage $image_save_path

# Define location to extract Quiet Boot status
$quiet_boot_location = @{
    X = 100
    Y = 100
    Width = 150
    Height = 50
}

# Extract Quiet Boot status from the screen
$captured_screen = Get-Content $image_save_path
$quiet_boot_status = Extract_Screen_OCR $captured_screen $quiet_boot_location

# Check if Quiet Boot is enabled
if ($quiet_boot_status -eq "Enabled") {
    $test_result = "PASS"
} else {
    $test_result = "FAIL"
}

# Generate a test report
GenerateTestReport $captured_screen $test_result

Write-Host "Test result: $test_result"