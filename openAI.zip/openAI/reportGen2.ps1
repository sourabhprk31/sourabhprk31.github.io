Import-Module PowerShell-Word
function Update-TestReport {
    param (
        [int]$SerialNo,
        [string]$TestSeriesID,
        [string]$TestCaseID,
        [string]$TestCase,
        [string]$ExpectedBehavior,
        [string]$ObservedBehavior,
        [string]$TestCaseResult
    )
    $filePath = "path\to\your\report.docx"
    # Open the Word document
    $wordDocument = Open-WordDocument -Path $filePath
    # Find the table by its title row
    $table = $wordDocument.Tables | Where-Object {
        $_.Rows.First.Cells | ForEach-Object { $_.Range.Text } -join '' -match "Serial No\.Test Series IDTest Case ID"
    }
    if ($null -eq $table) {
        Write-Host "Table not found in the document" -ForegroundColor Red
        return
    }
    # Add a new row to the table
    $newRow = $table.Rows.Add()
    # Fill in the new row with the provided data
    $newRow.Cells[0].Range.Text = $SerialNo
    $newRow.Cells[1].Range.Text = $TestSeriesID
    $newRow.Cells[2].Range.Text = $TestCaseID
    $newRow.Cells[3].Range.Text = $TestCase
    $newRow.Cells[4].Range.Text = $ExpectedBehavior
    $newRow.Cells[5].Range.Text = $ObservedBehavior
    $newRow.Cells[6].Range.Text = $TestCaseResult
    # Save and close the Word document
    Save-WordDocument -WordDocument $wordDocument
    Close-WordDocument -WordDocument $wordDocument

    Write-Host "Test report updated successfully" -ForegroundColor Green
}