import json
import openai
import subprocess
import xlrd
import xlwt

from gpt import GPT
from gpt import Example
# from openpyxl import load_workbook
from xlutils.copy import copy

with open('GPT_SECRET_KEY.json') as f:
    data = json.load(f)

openai.api_key = data["API_KEY"]

gpt = GPT(engine="davinci",
        temperature=0.5,
        max_tokens=150)

gptExpression = GPT(engine="davinci",
        temperature=0.5,
        max_tokens=150)

gptVariable = GPT(engine="davinci",
        temperature=0.5,
        max_tokens=150)

"""TRAINING FOR TEST SCRIPT"""
gpt.add_example(Example("The Operational Software shall set AWD_Dispensor_Pump to ON, if AW_Overflow_Status equals to NO OVERFLOW "
                        "or AW_Water_Cup_Present_Status equals to PRESENT",
                "set('AW_Overflow_Status' , 'NO OVERFLOW')\nset('AW_Water_Cup_Present_Status' , 'PRESENT')\n"
                "Result = get(AWD_Dispensor_Pump)\n "
                "if(Result == 'ON'):\n\t"
                "print('TestCase Pass')\nelse:\n\tprint('TestCase Fail')"))

# gpt.add_example(Example("The Operational Software shall set AWD_Dispensor_Pump to ON, if AW_Overflow_Status equals to NO OVERFLOW "
#                         "or AW_Water_Cup_Present_Status equals to PRESENT",
#                 "set('AW_Overflow_Status' , 'NO OVERFLOW')\nset('AW_Water_Cup_Present_Status' , 'PRESENT')\n"
#                 "Result = get(AWD_Dispensor_Pump)\n "
#                 "if(Result == 'ON'):\n\t"
#                 "print('TestCase Pass')\nelse:\n\tprint('TestCase Fail')"))

# gpt.add_example(Example("The Operational Software shall set AWD_Dispensor_Pump to OFF, if AW_Overflow_Status equals to OVERFLOW "
#                         "or AW_Water_Cup_Present_Status equals to ABSENT",
#                 "set('AW_Overflow_Status' , 'OVERFLOW')\nset('AW_Water_Cup_Present_Status' , 'ABSENT')\n"
#                 "Result = get(AWD_Dispensor_Pump)\n "
#                 "if(Result == 'ON'):\n\t"
#                 "print('TestCase Pass')\nelse:\n\tprint('TestCase Fail')"))

"""TRAINING FOR MCDC TOOL EXPRESSION"""
gptExpression.add_example(Example("The Operational Software shall set AWD_Dispensor_Pump to ON, if AW_Overflow_Status equals to NO OVERFLOW "
                        "or AW_Water_Cup_Present_Status equals to PRESENT",
                '( AW_Overflow_Status || AW_Water_Cup_Present_Status )'))


"""Training to get variable"""
gptVariable.add_example(Example("The Operational Software shall set AWD_Dispensor_Pump to ON, if AW_Overflow_Status equals to NO OVERFLOW "
                        "or AW_Water_Cup_Present_Status equals to PRESENT",
                'AWD_Dispensor_Pump=ON,AW_Overflow_Status=NO OVERFLOW,AW_Water_Cup_Present_Status=PRESENT'))
"""PASSING THE NLP TO GENERATE THE AUTOMATION SCRIPT AND EXPRESSION"""
#NLP  1
# prompt = "if AW_Overflow_Status equals to NO OVERFLOW or AW_Water_Cup_Present_Status equals to PRESENT," \
#          " Then Operational Software shall set AWD_Dispensor_Pump to ON"

#NLP  2
prompt ="The Operational Software shall set AWD_Dispensor_Pump to OFF, if " \
        "AW_Overflow_Status equals to NO OVERFLOW or AW_Water_Cup_Present_Status equals to ABSENT"

#NLP  3
# prompt = "The Operational Software shall set AWD_Dispensor_Pump_val to on, if " \
#          "AW_Overflow_Status_val equals to NO OVERFLOW or AW_Water_Cup_Present_Status_val equals to PRESENT"

output = gpt.submit_request(prompt)

file1 = open("C:\\PycharmProjects\\Automation_Script.py", "a")
file1.write(output.choices[0].text.replace('output: ',''))
file1.close()

print('------------TESTSCRIPT-------------')
print(output.choices[0].text.replace('output: ',''))

outputExpression = gptExpression.submit_request(prompt)

print('------------MCDC EXPRESSION-------------')
print(outputExpression.choices[0].text.replace('output: ',''))

outputVariable = gptVariable.submit_request(prompt)

print('------------VARIABLE-------------')
variableArr = outputVariable.choices[0].text.replace('output: ','').split(",")
print(variableArr)

############################ Update Input XLS file ################################

# 1. Update Expression
# ------------------------
# load excel file
workbook = xlrd.open_workbook("C:/Users/sujeet.kumar/Downloads/MCDC/MCDC/InputTemplate_updated.xls")

wb = copy(workbook)

w_sheet = wb.get_sheet(1)

w_sheet.write(2, 1, outputExpression.choices[0].text.replace('output: ',''))

# wb.save("C:/Users/sujeet.kumar/Downloads/MCDC/MCDC/InputTemplate_updated.xls")

# 2. Update Data Dictionary

# workbook = xlrd.open_workbook("C:/Users/sujeet.kumar/Downloads/MCDC/MCDC/InputTemplate_updated.xls")
#
# wb = copy(workbook)

w_sheet = wb.get_sheet(2)

start_row = 2

for val in variableArr:
    w_sheet.write(start_row, 1, val.split("=")[0])
    var_type = val.split("=")[1]
    if isinstance(var_type,str):
        var_type = 'String'
    elif isinstance(var_type,int):
        var_type = 'Integer'
    elif isinstance(var_type,float):
        var_type = 'Float'
    elif isinstance(var_type,bool):
        var_type = 'Boolean'

    w_sheet.write(start_row, 2, var_type)
    # print(type(1))
    start_row +=1

wb.save("C:/Users/sujeet.kumar/Downloads/MCDC/MCDC/InputTemplate_updated.xls")


################################### Call MCDC Tool ###################################
subprocess.call(['java', '-jar', 'C:/Users/sujeet.kumar/Downloads/MCDC/MCDC/MCDCAutomationGUI.jar'])


################################## Take the Output excel file data and generate TestScript ##########################

workbook1 = xlrd.open_workbook("C:\PycharmProjects\TestScript_Automation\Output.xls")

w_sheet = workbook1.sheet_by_index(3)

condition1_dict = {"true" : "ON", "false" : "OFF"}
condition2_dict = {"true" : "OVERFLOW", "false" : "NO OVERFLOW"}
condition3_dict = {"true" : "PRESENT", "false" : "ABSENT"}

prompt_list = list()
# print(w_sheet.nrows)
# print(w_sheet.ncols)
temp_str = ''
for x in range(3, w_sheet.nrows):
    temp_str = ''
    for y in range(4, w_sheet.ncols):
        # print(w_sheet.cell_value(x,y))
        if(y == 4):
            temp_str +="The Operational Software shall set AWD_Dispensor_Pump to "+condition1_dict.get(w_sheet.cell_value(x,y))+", if "
        elif(y == 5):
            temp_str += "AW_Overflow_Status equals to "+condition2_dict.get(w_sheet.cell_value(x,y))+" or "
        elif(y == 6):
            temp_str += "AW_Water_Cup_Present_Status equals to "+condition3_dict.get(w_sheet.cell_value(x,y))

    prompt_list.append(temp_str)

print('------------MC DC-------------')
for i in prompt_list:
    print(i)
    print("-----------------------TESTSCRIPT-----------------")
    output = gpt.submit_request(i)
    print(output.choices[0].text.replace('output: ', ''))

