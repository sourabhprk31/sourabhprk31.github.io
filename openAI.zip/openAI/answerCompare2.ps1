function Compare-Statements {
    param (
        [string]$Statement1,
        [string]$Statement2
    )

    function Process-Statement([string]$Statement) {
        $Statement = $Statement.ToLower()
        $Words = $Statement -split "\s+"
        return $Words
    }

    function Calculate-Jaccard-Similarity([string[]]$Set1, [string[]]$Set2) {
        $Intersection = (Compare-Object -ReferenceObject $Set1 -DifferenceObject $Set2 -ExcludeDifferent -IncludeEqual).Count
        $Union = ($Set1 + $Set2 | Sort-Object -Unique).Count
        return $Intersection / $Union
    }

    $ProcessedStatement1 = Process-Statement $Statement1
    $ProcessedStatement2 = Process-Statement $Statement2

    $JaccardSimilarity = Calculate-Jaccard-Similarity -Set1 $ProcessedStatement1 -Set2 $ProcessedStatement2

    if ($JaccardSimilarity -ge 0.8) {
        return "PASS"
    } else {
        return "FAIL"
    }
}

$Input1 = "The capital city of India is New Delhi"
$Input2 = "New Delhi is the capital city of India"

$Result = Compare-Statements -Statement1 $Input1 -Statement2 $Input2
Write-Host $Result