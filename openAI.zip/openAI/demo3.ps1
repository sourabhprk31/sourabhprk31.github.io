# PowerShell Script to test the requirement and generate a test report

# Import required modules
# Assuming the APIs are part of a custom module named "DeviceTesting"
Import-Module DeviceTesting

# Start the device
StartDevice

# Capture the screen and save the image
$image_save_path = "C:\path\to\image\folder\boot_menu.png"
CaptureImage $image_save_path

# Define location to extract "Main" text
$main_text_location = @{
    X = 900
    Y = 20
    Width = 50
    Height = 20
}

# Extract "Main" text from the screen
$captured_screen = Get-Content $image_save_path
$main_text_status = Extract_Screen_OCR $captured_screen $main_text_location

# Check if "Main" text is displayed
if ($main_text_status -eq "Main") {
    $main_text_result = "PASS"
} else {
    $main_text_result = "FAIL"
}

# Press right arrow key four times to reach the boot menu
for ($i = 0; $i -lt 4; $i++) {
    SendKB_SpecialKeyEvent "RightArrow"
}

# Define location to extract Quiet Boot status
$quiet_boot_location = @{
    X = 100
    Y = 100
    Width = 150
    Height = 50
}

# Extract Quiet Boot status from the screen
$quiet_boot_status = Extract_Screen_OCR $captured_screen $quiet_boot_location

# Check if Quiet Boot is enabled
if ($quiet_boot_status -eq "Enabled") {
    $quiet_boot_result = "PASS"
} else {
    $quiet_boot_result = "FAIL"
}

# Generate a test report
$test_result = @{
    MainText = $main_text_result
    QuietBoot = $quiet_boot_result
}

GenerateTestReport $captured_screen $test_result

Write-Host "Main text result: $($test_result.MainText)"
Write-Host "Quiet Boot result: $($test_result.QuietBoot)"