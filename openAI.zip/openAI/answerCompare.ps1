function Compare-Statements {
    param (
        [string]$Statement1,
        [string]$Statement2
    )

    function Process-Statement([string]$Statement) {
        $Statement = $Statement.ToLower()
        $Words = $Statement -split "\s+"
        return $Words
    }

    $ProcessedStatement1 = Process-Statement $Statement1
    $ProcessedStatement2 = Process-Statement $Statement2

    $Words1Count = $ProcessedStatement1.Count
    $Words2Count = $ProcessedStatement2.Count

    if ($Words1Count -ne $Words2Count) {
        return "FAIL"
    }

    $CommonWords = (Compare-Object $ProcessedStatement1 $ProcessedStatement2 -IncludeEqual | Measure-Object).Count

    if ($CommonWords -eq $Words1Count) {
        return "PASS"
    } else {
        return "FAIL"
    }
}

$Input1 = "The capital city of India is New Delhi"
$Input2 = "New Delhi is the capital city of India"

$Result = Compare-Statements -Statement1 $Input1 -Statement2 $Input2
Write-Host $Result