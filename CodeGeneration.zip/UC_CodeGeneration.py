import os
import openai
import logging
from dotenv import load_dotenv
import configparser
import streamlit as st

token_cost_dict = {
    'text-model-davinci03': 0.00002,
    'codemodel-davinci':    0.001,
    'chat-model': 0.000002
}

cwdPath = os.path.abspath(os.getcwd())
config_path = os.path.join(cwdPath, "config")
config_parser = configparser.ConfigParser()
config_parser.read(os.path.join(config_path, "openai_config.ini"))

def get_prompt_cost(token_length, engine):
        dollar_rate = 82.48
        print("Prompt Cost in Dollars :>>",token_length*token_cost_dict[engine])
        return (token_length*token_cost_dict[engine])*dollar_rate

class GPTConnector:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        load_dotenv()
        openai.api_type = config_parser.get("code_generation", "api_type")
        openai.api_base = config_parser.get("code_generation", "api_base")
        openai.api_key = os.getenv("OPENAI_API_KEY")
        openai.api_version = config_parser.get("code_generation", "api_version")

        self.token_cost_dict = {
            'text-model-davinci03': 0.00002,
            'codemodel-davinci':    0.001,
            'chat-model': 0.000002}

        self.session_total_cost = 0
        self.history = []

        self.max_tokens = 3500
        self.temperature = 0
        self.curr_response = ""


    def convert_to_usd_cents(self, cost):
        dollars = int(cost)
        cents = (cost - dollars) * 100
        return dollars, cents
    

    def set_sys_role(self, content):
        sys_role = {'role': 'system', 'content': content}
        self.history.append(sys_role)


    def refine_prompt(self, prompt):
        prompt = 'Evaluate and improve the prompt enclosed within angular brackets:\n<'+prompt+'>'
        self.get_completion(prompt, display_response=False)
        return self.curr_response
    

    def clear_history(self, steps=None):
        if steps is not None:
            if steps > len(self.history):
                self.logger.error(
                    f'Context history has only {len(self.history)} contexts, cannot remove {steps} contexts')
                return
            if steps < 0:
                self.history = self.history[steps:]
            elif steps > 0:
                self.history = self.history[:-steps]
            else:
                self.history = []

   

    def get_completion(self, prompt, role_content=None, max_tokens=None, temperature=None, display_response=True):
        if self.history != []:
            curr_msg = {'role': 'user', 'content': prompt}
            messages = self.history.copy()
            messages.append(curr_msg)
            response = openai.ChatCompletion.create(
            engine="chat-model",
            messages=messages,
            temperature=temperature if temperature is not None else self.temperature,
            max_tokens=max_tokens if max_tokens is not None else self.max_tokens,
            top_p=0.95,
            frequency_penalty=0.01,
            presence_penalty=0,
            stop=None
        )

        res = response['choices'][0]['message']
        prompt_token_length = response['usage']['prompt_tokens']
        total_token_length = response['usage']['total_tokens']
        prompt_cost = get_prompt_cost(total_token_length, "chat-model")
        print("Prompt Cost in Rupees :>>",prompt_cost)

        if res != None and res != []:
            self.history.append(res)
            self.history.append(curr_msg)
            self.history.append(
                {'role': res['role'], 'content': res['content']})
           
        return res['content'], prompt_token_length, total_token_length, prompt_cost
    




#####################################################################################
##################### CODE COMPLETION API - CHAT MODEL ###########################################
#####################################################################################
SOFTWARE_ENG_SYS_MSG = """You are a software engineer specializing in Time Series Analysis."""
DEFAULT_CODING_GUIDELINES = """-Include complete sentence single line comments within all methods of class
-In each line of code, the character limit is 79 characters
-Wildcard imports (from import *) should be avoided
-Follow specific naming conventions:
    *Function name - Lower case and underscore(_) in between the words
    *Class name - Camel case
    *Object name - Lower case and very short name"""
CODE_GENERATION_TEMPLATE = """Coding Guidelines:
{coding_guidelines}
Remember to follow the coding guidelines and Use {programming_language} Programming Language. 
{code_prompt}. Return only the code
Code:"""
TEST_SCRIPT_GENERATION_PROMPT = """Implement a unittest based test script to validate the above code.
-The test script should cover the class methods and edge case scenarios.
-Avoid hardcoded output values and substantiate target values using input data
-Ensure correct behavior without relying on specific output values
-Give only the script. Remember to follow the coding guidelines mentioned before
"""


class CodeCompletionAPI(GPTConnector):

    def __init__(self):
        super().__init__()


    def _generate_code(self, code_prompt: str, role_msg:str):
        self.set_sys_role(role_msg)
        code, prompt_token_length, total_token_length, prompt_cost = self.get_completion(prompt=code_prompt, temperature=0.1)
        return code, prompt_token_length, total_token_length, prompt_cost
    

    def _generate_unit_test_cases_script(self, code: str):
        test_script = self.get_completion(
            prompt=TEST_SCRIPT_GENERATION_PROMPT, temperature=0.1)
        return test_script
    

    def run(self, final_prompt: str, role_msg:str):
        code, prompt_token_length, total_token_length, prompt_cost  = self._generate_code(final_prompt, role_msg)
        return {"code": code, "prompt_token_length": prompt_token_length, "total_token_length":total_token_length, "prompt_cost":prompt_cost}
    

if __name__ == "__main__":
    code_generator = CodeCompletionAPI()
    code_prompt = """Main Task:
Unsupervised Univariate Time Series Anomaly Detection
Task description:
Given a CSV file containing time series data, your task is to identify anomalies using an appropriate machine learning technique. Import the functions in the 'Utilities' section for preprocessing. Follow the steps provided in the 'Steps' section. Do not define empty functions.
Utilities:      
To use these functions, import from utils:
- utils.detect_datetime_column(df) -> identifies the date time column in the data and returns the date time column name
- utils.fill_missing_values(df, time_col) -> takes in the date time column name and fills missing values
Steps:
1. Read the CSV file
2. Preprocess the data using the provided utility functions   
3. Select an overfitting-resistant algorithm suitable for the dataset 
4. Mark the anomalies as True
5. Create an interactive plot highlighting the anomalies in red
Provide only the Python class and main function implementing the above steps.
"""
    code = code_generator.run(code_prompt=code_prompt, programming_language="Python", generate_unit_test_cases=True)
    print(code["code"])
    print(code["unit_test_cases_script"])