"""
=============================================================================
COPYRIGHT NOTICE
=============================================================================
© Copyright HCL Technologies Ltd. 2021, 2022, 2023
Proprietary and confidential. All information contained herein is, and
remains the property of HCL Technologies Limited. Copying or reproducing the
contents of this file, via any medium is strictly prohibited unless prior
written permission is obtained from HCL Technologies Limited.
"""
import os
import json
import shutil
from datetime import datetime

from reportlab.lib.pagesizes import letter  
from reportlab.pdfgen import canvas 
import textwrap  

from Utility import postgres_conn as postgres_connection

### Configured the ROOt Path
cwdPath = os.path.abspath(os.getcwd())

project_rootpath = os.path.join(cwdPath, "Projects")
usecase_rootpath = os.path.join(cwdPath, "UsecaseResult")
Result_rootpath = os.path.join(cwdPath, "Result")
Logs_rootpath = os.path.join(cwdPath, "Logs")

# project_rootpath = os.path.join(cwdPath, os.path.join("server","Projects"))
# usecase_rootpath =  os.path.join(cwdPath, os.path.join("server","UsecaseResult"))

### Based on Directory Type get the PATH 
# Directory Name String
# Directory Type should either one "input", "output", "zip"
def get_directory_path(directory_name, directory_type):
    # directory_name = directory_name.replace(" ","_")
    if directory_type == "input":
        directory_path = os.path.join(project_rootpath,directory_name)
    elif directory_type == "output":
        directory_path = os.path.join(usecase_rootpath,directory_name)
    elif directory_type == "zip":
        directory_path = os.path.join(Result_rootpath,directory_name)
   
    return directory_path

### Return the List of Files from given Project Directory
# Type should either one "input", "output"
def read_directory(dir_name, type):
    file_list = [] 
    directory_path = get_directory_path(dir_name, type)
    for root, _, files in os.walk(directory_path):  
        for file in files:
            file_path = os.path.join(root, file)  
            relative_path = os.path.relpath(file_path, directory_path)  
            file_list.append(relative_path)  
    
    return file_list


### Return the File Content From given Project and File name
def read_file(dir_name, file_relpath, type, id, file_count, log_name):
    log_content = "\n------------------------------------------------------\n"
    log_content += "***** ***** ****** "+str(id)+" Out of "+str(file_count)+" Files ****** ***** *****"
    log_content += "\n------------------------------------------------------"
    updatelog(log_name, log_content, False)
    final_file_path = get_directory_path(os.path.join(dir_name,file_relpath), type)
    with open(final_file_path, 'r') as file: 
        file_content = file.read() 
        updatelog(log_name, "File Read Successfully!\n", True)
        file_size = os.path.getsize(final_file_path) 
        file_name = os.path.basename(final_file_path)
        return file_content, file_size, file_name
    
### Create the Output Directory IF NOT EXISTS
def check_create_directory(dir_name, type):
    directory_path = get_directory_path(dir_name, type)
    if os.path.exists(directory_path):
        delete_directory(dir_name, type)
    else:   
        os.makedirs(directory_path)
    if type == "output":
        updatelog(dir_name, "Output Folder Created Successfully!\n", True)
    return directory_path

### Help to get the File Name from Path
def get_file_name(content):  
    last_index = content.rfind('/')  
    if last_index != -1:  
        file_name = content[last_index + 1:];  
        return file_name  

### Saving the content into PDF
def save_content_as_pdf(content, file_path, title):  
    c = canvas.Canvas(file_path, pagesize=letter)  
    c.setTitle(title)
    c.setFont("Helvetica", 12)  

    # Set the starting coordinates, line height, and text width  
    x = 50  
    y = 750  
    line_height = 14  
    text_width = 95
    bottom_margin = 50  
  
    # Split the content into lines  
    lines = content.split("\n")  
  
    # Write each line to the PDF with automatic line wrapping  
    for line in lines:  
        # Wrap the line if it exceeds the text_width  
        wrapped_lines = textwrap.wrap(line, width=text_width)  
  
        for wrapped_line in wrapped_lines:  
            if y < bottom_margin:  
                c.showPage()  
                y = 750  
  
            c.drawString(x, y, wrapped_line)  
            y -= line_height   
  
        # Add a blank line to separate paragraphs  
        y -= line_height
    c.showPage()  
    c.save()  

### Saving the OPEN AI Response as a Document Format
def save_response( use_project_file, outputroot_path, file_relpath, response, file_type, log_name):

    if use_project_file == False:
        if not os.path.exists(outputroot_path):
            os.makedirs(outputroot_path)
        response_content = response['response']
        outputfile_name = file_relpath.split(".")[0]+file_type
        with open(os.path.join(outputroot_path, outputfile_name), 'w') as file:  
            file.write(response_content)
        file.close()
    else:
        print(file_relpath)
        file_relpath = file_relpath.replace("\\","/")
        response_content = response['response']
        file_directory = get_folder_path(file_relpath.replace("\\","/"))
        output_path = os.path.join(outputroot_path,file_directory)
        if not os.path.exists(output_path):
            os.makedirs(output_path) 
        outputfile_name = get_file_name(file_relpath).split(".")[0]+file_type
        final_path = os.path.join(output_path, outputfile_name)
        if file_type == ".pdf":
            save_content_as_pdf(response_content,final_path, outputfile_name)
        else:
            with open(final_path, 'w') as file:  
                file.write(response_content)
            file.close()
    updatelog(log_name, "Response Saved Successfully!" ,True)

### Find the Line of Code / Number of Word from Given File
def getcount(directory_path, file_name, count_type):
    count = 0  
    with open(os.path.join(directory_path,file_name), 'r') as file:  
        for line in file: 
            if count_type == "LoC":  #Line of Code
                count += 1
            elif count_type == "NoW": #Number of Word
                words = line.split()  
                count += len(words) 
            elif count_type == "NoC": #Number of Character
                count += len(line)  
    return count

### Find the Line of Code/Charactor,Word and Function from Given File
def check_count(project_name, file_name, count_type):
    directory_path = get_directory_path(project_name, "input")
    count = 0
    if count_type == "LoC": #Line of Code
        count = getcount(directory_path, file_name, count_type)
    elif count_type == "NoW": #Number of Word
        count = getcount(directory_path, file_name, count_type)
    elif count_type == "NoC": #Number of Character
        count = getcount(directory_path, file_name, count_type)
    elif count_type == "NoF":
        count = 0

    return count


### REFERENCE PURPOSE ONLY --- Logic Validation Required ---
### FOR CODE GENERATION WORKING FINE
def get_promptValue(usecase_name):
    select_query = 'SELECT usecase_id, usecase_name, input_control, input_data, prompt_value, additional_info from public.usecases where usecase_name=%s'
    res = postgres_connection.execute_get_query(select_query, [usecase_name])
    for row in res["data"]:
        prompt_values = json.loads(row["prompt_value"].replace('\'','\"'))
        additional_info = json.loads(row["additional_info"].replace('\'','\"'))
        input_control = json.loads(row["input_control"].replace('\'','\"'))
        input_data = json.loads(row["input_data"].replace('\'','\"'))
        return prompt_values, additional_info, input_control, input_data


### Generating the Dynamic Prompt
def generatePrompt(form_data, prompt_values, additional_info, input_control, input_data):
    FinalPrompt = ""
    SystemRole = ""
    for (input_id, input_type) in input_control.items():
        system_role_id = additional_info['SYSTEM_ROLE'] if "SYSTEM_ROLE" in additional_info else 0
        if system_role_id == input_id:
            selected_option = form_data[input_id]  if input_id in form_data else ""
            selected_input_data = input_data[input_id]  if input_id in input_data else ""
            indexvalue = selected_input_data.index(selected_option)
            selected_prompt_value = prompt_values[input_id]  if input_id in prompt_values else ""
            SystemRole =  selected_prompt_value[indexvalue]
        else:
            if input_type == "text_area":
                FinalPrompt += prompt_values[input_id]  if input_id in prompt_values else ""
                FinalPrompt += "\n"
                FinalPrompt += form_data[input_id]  if input_id in form_data else ""
                FinalPrompt += "\n\n"
            else:
                selected_option = form_data[input_id]  if input_id in form_data else ""
                selected_input_data = input_data[input_id]  if input_id in input_data else ""
                indexvalue = selected_input_data.index(selected_option)
                selected_prompt_value = prompt_values[input_id]  if input_id in prompt_values else ""
                FinalPrompt += selected_prompt_value[indexvalue]+" "

    print("----------START-----------")
    print("SystemRole :>>", SystemRole)
    print("FinalPrompt :>>", FinalPrompt)
    print("----------END-----------")
    
    return SystemRole, FinalPrompt

### Generate Prompt Main Function
def GeneratePromptFromInput(usecase_name, form_data):
    updatelog(usecase_name, "Prompt Generating...", True)
    prompt_values, additional_info, input_control, input_data = get_promptValue(usecase_name)
    SystemRole, FinalPrompt = generatePrompt(form_data, prompt_values, additional_info, input_control, input_data)
    updatelog(usecase_name, "Prompt Generated Successfully!\n", True)
    return SystemRole, FinalPrompt


### Get the Directory Name From Path
def get_folder_path(content):
    last_index = content.rfind('/')
    if last_index != -1:  
        dir_name = content[:last_index]  
        return dir_name  

### Save the uploaded files into Local Folder
def handle_uploaded_file(root_dir_path, file_path, file):
    file_directory = get_folder_path(file_path)
    save_path = os.path.join(root_dir_path,file_directory)
    if not os.path.exists(save_path):
        os.makedirs(save_path) 
    with open(os.path.join(save_path, file.name), 'wb+') as destination:
        for chunk in file.chunks():
            destination.write(chunk)
        return os.path.join(save_path, file.name)

### Creating Output Directory as a Archieve(ZIP File) Format
def make_archive(source, destination):
    base = os.path.basename(destination)
    name = base.split('.')[0]
    format = base.split('.')[1]
    archive_from = os.path.dirname(source)
    archive_to = os.path.basename(source.strip(os.sep))
    shutil.make_archive(name, format, archive_from, archive_to)
    shutil.move('%s.%s' % (name, format), destination)
    return "OK"
   

### Delete the Directory/Sub Directory and Files
def delete_directory(dir_name, type):
    directory_path = get_directory_path(dir_name, type)
    if os.path.exists(directory_path):  
        try:  
            shutil.rmtree(directory_path)  
            return ("Directory and its contents have been deleted successfully.")  
        except Exception as e:  
            return (f"An error occurred while deleting the directory: {e}")  
    else:  
        return ("The specified directory does not exist.")  
    
### Create the LOG FILE IF NOT EXISTS
# DELETE the content IF EXISTS
def createLOGFile(log_name):
    log_name = log_name.replace(" ","_")
    logs_path = os.path.join(Logs_rootpath, log_name)
    with open(logs_path, "w") as file:  
        pass 

### Updating the LOGS
def updatelog(log_name, log_content, date_display):
    log_name = log_name.replace(" ","_")
    logs_path = os.path.join(Logs_rootpath, log_name)
    current_date_time = datetime.now()  
  
    formatted_date_time = current_date_time.strftime("%d-%m-%Y %H:%M:%S")
    
    if date_display == True:
        formatted_line = f"{formatted_date_time}   {log_content}"
    else:
        formatted_line = f"{log_content}"

    with open(logs_path, "r") as file:  
        content = file.read()  

    updated_content = content + formatted_line  +"\n" 
    with open(logs_path, "w") as file:  
        file.write(updated_content)






