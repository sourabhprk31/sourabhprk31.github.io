from Utility import utility
from Utility.openai import GPTConnector
import panda as pd

def summarization(usecase_name, project_name, form_data):
    log_name = usecase_name
    utility.createLOGFile(log_name)
    utility.updatelog(log_name, "***** ***** ***** ***** Started ***** ***** ***** *****", False)
    ################## GENERATE PROMPT ####################
    SystemRole, GeneratedPrompt = utility.GeneratePromptFromInput(usecase_name, form_data)

    userType = form_data['1']
    language = form_data['2']
    api_data = form_data['3']

    instruction = "Generate testscript in "
    if language == "python":
        file_type = ".py"
        instruction = instruction + language
    elif language == "java":
        file_type = ".java"
        instruction = instruction + language
    elif language == "powershell":
        file_type = ".ps1"
        instruction = instruction + language
    if SystemRole == "":
        SystemRole = "You are a senior software developer"
    try:
        file_list = utility.read_directory(project_name, "input")
        if len(file_list) != 0:
            outputroot_path = utility.check_create_directory(usecase_name, "output")

            prompt_tokens, total_tokens, prompt_cost, total_count = 0, 0, 0, 0 
            count_type = "LoC"
            file_count = len(file_list)
            input_file_details = []
            id = 0
            for file_relpath in  file_list:
                input_file = {}
                id = id+1
                file_size, file_name, col1_data, col2_data = utility.read_file(project_name, file_relpath, "input", id, file_count, log_name)
                input_file['id'] = id
                input_file['file_name'] = file_name
                input_file['file_size'] = file_size
                input_file['file_path'] = file_relpath
                input_file_details.append(input_file)
                for col1, col2 in zip(col1_data, col2_data):
                    messages = [
                        {"role": "user", "content": col1},
                        {"role": "user", "content": col2},
                        {"role": "user", "content": api_data}

                    ]

                    ################## CALL OPENAI ####################
                    generator = GPTConnector()
                    subscription_name = "dev-openai-usecases"
                    deployment_name = "chat-model"
                    response = generator.run_for_script(subscription_name, deployment_name, messages,
                                            role_msg="user", instruction=instruction, log_name=log_name)
                    i = 1
                    file = 'TestScript_'+i+file_type
                    use_project_file = True
                    utility.save_response(use_project_file, outputroot_path, file, response, file_type,
                                          log_name)
                    prompt_tokens += response["cost_token_info"]["prompt_tokens"]
                    total_tokens += response["cost_token_info"]["total_tokens"]
                    prompt_cost += response["cost_token_info"]["prompt_cost"]
                    total_count += utility.check_count(project_name, file_relpath, count_type)


            result_summary = {}
            result_summary['project_name'] = project_name
            result_summary['numof_files'] = file_count
            # result_summary['count_type'] = count_type
            # result_summary['total_count'] = total_count
            result_summary[count_type] = total_count
            result_summary['numof_prompts_executed'] = file_count
            result_summary['prompt_tokens'] = prompt_tokens
            result_summary['total_tokens'] = total_tokens
            result_summary['prompt_cost'] = prompt_cost
            result_summary['time_taken'] = 5

            final_response = {}
            final_response["status"] = "success"
            final_response["msg"] = ""
            final_response["result_summary"] = result_summary
            final_response["input_file_details"] = input_file_details
            final_response["output_file_type"] = file_type
            utility.updatelog(log_name, "\nResult Summary Generated Successfully!"+"\n\n***** ***** ***** ***** Completed ***** ***** ***** *****", False)
            return final_response
        else:
            msg = "Project Not Found / Empty Project"
            utility.updatelog(log_name, msg, True)
            final_response = {}
            final_response["status"] = "failed"
            final_response["msg"] = msg
            final_response["result_summary"] = {}
            final_response["input_file_details"] = []
            final_response["output_file_type"] = ""
           
            return final_response
    except Exception as e:
        utility.updatelog(log_name, str(e), True)
        final_response = {}
        final_response["status"] = "failed"
        final_response["msg"] = str(e)
        final_response["result_summary"] = {}
        final_response["input_file_details"] = []
        final_response["output_file_type"] = ""
        return final_response

