from Utility import utility
from Utility.openai import GPTConnector

def generation(usecase_name, project_name, form_data):
    log_name = usecase_name
    utility.createLOGFile(log_name)
    utility.updatelog(log_name, "***** ***** ***** ***** Started ***** ***** ***** *****", False)
     ################## GENERATE PROMPT ####################
    
    SystemRole, GeneratedPrompt = utility.GeneratePromptFromInput(usecase_name, form_data)
    print("======================================================"+form_data)
    try:
        prompt_tokens, total_tokens, prompt_cost, total_count = 0, 0, 0, 0
        count_type = "LoC"
        file_count = 0
        
        FinalPrompt = GeneratedPrompt
        
        outputdir_path = utility.check_create_directory(usecase_name, "output")
        ################## CALL OPENAI ####################
        generator = GPTConnector() 
        subscription_name = "dev-openai-usecases"
        deployment_name = "chat-model"
        response = generator.run(subscription_name, deployment_name, final_prompt= FinalPrompt, role_msg=SystemRole, log_name=log_name) 
        file_type = ".txt"
       
        file = "CodeGenerationResult.txt"
        use_project_file = False
        utility.save_response(use_project_file, outputdir_path, file, response, file_type, log_name)
        prompt_tokens = response["cost_token_info"]["prompt_tokens"]
        total_tokens = response["cost_token_info"]["total_tokens"]
        prompt_cost = response["cost_token_info"]["prompt_cost"]
        total_count = 0

        result_summary = {}
        result_summary['project_name'] = project_name
        result_summary['numof_files'] = file_count
        # result_summary['count_type'] = count_type
        # result_summary['total_count'] = total_count
        result_summary[count_type] = total_count
        result_summary['numof_prompts_executed'] = 1
        result_summary['prompt_tokens'] = prompt_tokens
        result_summary['total_tokens'] = total_tokens
        result_summary['prompt_cost'] = prompt_cost
        result_summary['time_taken'] = 5

        
        final_response = {}
        final_response["status"] = "success"
        final_response["msg"] = ""
        final_response["result_summary"] = result_summary
        final_response["input_file_details"] = []
        final_response["output_file_type"] = ".txt"
        utility.updatelog(log_name, "\nResult Summary Generated Successfully!"+"\n\n***** ***** ***** ***** Completed ***** ***** ***** *****", False)
        return final_response
        
    except Exception as e:
        utility.updatelog(log_name, str(e), True)
        final_response = {}
        final_response["status"] = "failed"
        final_response["msg"] = str(e)
        final_response["result_summary"] = {}
        final_response["input_file_details"] = []
        final_response["output_file_type"] = ""
        return final_response

