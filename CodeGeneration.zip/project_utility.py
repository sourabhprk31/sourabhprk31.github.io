"""
=============================================================================
COPYRIGHT NOTICE
=============================================================================
© Copyright HCL Technologies Ltd. 2021, 2022, 2023
Proprietary and confidential. All information contained herein is, and
remains the property of HCL Technologies Limited. Copying or reproducing the
contents of this file, via any medium is strictly prohibited unless prior
written permission is obtained from HCL Technologies Limited.
"""
from Utility import postgres_conn as postgres_connection
from Utility import utility
from datetime import datetime
import json
from datetime import datetime
import ast

def create_project_table():
    create_query = '''CREATE TABLE IF NOT EXISTS public.projects
    (
        id serial NOT NULL PRIMARY KEY,
        project_name character varying(50) NOT NULL,
        source_type character varying(25) NOT NULL,
        datasource character varying(50) NOT NULL
    )'''
    postgres_connection.execute_create_query(create_query)


def get_projects(request):
    create_project_table()
    query = '''select project_name from public.projects'''
    res = postgres_connection.execute_get_query(query,[])
    result = []
    for row in res["data"]:
        result.append(row["project_name"])
    return result

def check_project_exists(project_name):
    project_exists = False
    select_query = 'SELECT count(*) from public.projects where project_name=%s'
    res = postgres_connection.execute_get_query(select_query, [project_name])
    if res['message'] == "Success":
        if int(res['data'][0]['count']) != 0:
            project_exists = True
    print("Project Exists Status :>>", project_exists)
    return project_exists


def save_project(request):
    create_project_table()
    req_body = request.body.decode('utf-8')
    json_req = json.loads(req_body)['params']
    project_name =  json_req['project_name']
    source_type = json_req['source_type']
    source = json_req['source']
   
    project_exists = check_project_exists(project_name)
    if not project_exists:
        data_obj = (project_name, source_type, source)
        insert_query = 'INSERT INTO public.projects (project_name,source_type,datasource) VALUES (%s,%s,%s)'
        res = postgres_connection.execute_insert_query(insert_query, data_obj)
        print("Save Project :: Response :>>",res)
    else:
        res = "Exists"
        print("Save Project :: Response :>>",res)
    return res

    
def save_uploadedfiles(request):
    try:
        uploaded_files = request.FILES.getlist('uploaded_files')
        project_name = request.POST['project_name']
        root_directory_path = utility.check_create_directory(project_name, "input")
        print(root_directory_path)
        for file in uploaded_files:
            file_path = request.POST.get(f'path_{file.name}') 
            utility.handle_uploaded_file(root_directory_path, file_path, file=file)
        return "success"
    except:
        return "failed"
    

def get_projectsummary(request):
    create_project_table()
    query = '''select row_number() over (order by "id" DESC) as slno, id , project_name, source_type, datasource from public.projects'''
    res = postgres_connection.execute_get_query(query,[])
    return res


def delete_project(request):
    create_project_table()
    id = request.GET['id']
    project_name = request.GET['project_name']
    datasource = request.GET['datasource']
    utility.delete_directory(project_name, "input")
    query = '''DELETE from public.projects where id =%s'''
    ret = postgres_connection.execute_delete_query(query,[id])
    return ret